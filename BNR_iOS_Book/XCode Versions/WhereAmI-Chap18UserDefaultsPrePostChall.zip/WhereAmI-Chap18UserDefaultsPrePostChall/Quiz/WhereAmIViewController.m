//
//  QuizViewController.m
//  Quiz
//
//  Created by Jonathan Goldberger on 11/17/13.
//  Copyright (c) 2013 Jonathan Goldberger. All rights reserved.
//

#import "WhereAmIViewController.h"
#import "BNRMapPoint.h"

NSString * const WhereamiMapTypePrefKey = @"WhereamiMapTypePrefKey";
NSString * const WhereamiLastLocationPrefLatKey = @"WhereamiLastLocationLatPrefKey";
NSString * const WhereamiLastLocationPrefLongKey = @"WhereamiLastLocationLongPrefKey";

@implementation WhereAmIViewController

@synthesize gettingLocLabel;

+ (void)initialize
{
    NSMutableDictionary *defaults = [NSMutableDictionary dictionaryWithObject:[NSNumber numberWithInt:0] forKey:WhereamiMapTypePrefKey];
    [defaults setObject:[NSNumber numberWithFloat:21.3001] forKey:WhereamiLastLocationPrefLatKey];
    [defaults setObject:[NSNumber numberWithFloat:-157.8167] forKey:WhereamiLastLocationPrefLongKey];
    
    [[NSUserDefaults standardUserDefaults] registerDefaults:defaults];
}

- (id) initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Create Location Manager Object
        locationManager = [[CLLocationManager alloc] init];
        
        // There will be a warning here. Ignore it for now. Need to conform to protocol
        [locationManager setDelegate:self];
        
        // And we want it to be as accurate as possible
        // regardless of how much time/power it takes
        [locationManager setDesiredAccuracy:kCLLocationAccuracyBest];
        [locationManager setHeadingFilter:45];
         
        [locationManager setDistanceFilter:50];
        
        
        // Tell our manager to start looking for its location immediately
        //[locationManager startUpdatingLocation];
        [locationManager startUpdatingHeading];
    }
    
    // Return the address of the new object
    return self;
}

- (void)locationManager:(CLLocationManager *)manager
    didUpdateToLocation:(CLLocation *)newLocation
           fromLocation:(CLLocation *)oldLocation
{
    NSLog(@"%@", newLocation);
    
    // How many seconds ago was this new location created?
    NSTimeInterval t = [[newLocation timestamp] timeIntervalSinceNow];
    
    // CLLocationManagers will return the last found location of the
    // device first, you don't want this data in this case
    // If this location was made more than 3 minutes ago, ignore it.
    if (t < -180) {
        // This is cached data, yoiu don't want it, keep looking
        return;
    }
    
    [self foundLocation:newLocation];
}

- (void)locationManager:(CLLocationManager *)manager
    didFailWithError:(NSError *)error
{
    [activityIndicator startAnimating];
    [gettingLocLabel setHidden:NO];
    NSLog(@"Could not find location : %@", error);
}

- (void)locationManager:(CLLocationManager *)manager
       didUpdateHeading:(CLHeading *)newHeading
{
    NSLog(@"Heading: %@", newHeading);
}

- (void)viewDidLoad
{
    [worldView setShowsUserLocation:YES];
    
    NSInteger mapTypeValue = [[NSUserDefaults standardUserDefaults] integerForKey:WhereamiMapTypePrefKey];
    
    // Update the UI
    [mapSelectOutlet setSelectedSegmentIndex:mapTypeValue];
    
    // Update the map
    [self mapSelect:mapSelectOutlet];
    
    float lastLat = [[NSUserDefaults standardUserDefaults] floatForKey:WhereamiLastLocationPrefLatKey];
    float lastLong = [[NSUserDefaults standardUserDefaults] floatForKey:WhereamiLastLocationPrefLongKey];
    
    CLLocationCoordinate2D coord = CLLocationCoordinate2DMake(lastLat, lastLong);
    MKCoordinateRegion region = MKCoordinateRegionMakeWithDistance(coord, 1000, 1000);
    [worldView setRegion:region animated:YES];
    
    NSArray *documentDirectories = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    // Get one and only document directory from that list
    NSString * documentDirectory = [documentDirectories objectAtIndex:0];
    NSString *path = [documentDirectory stringByAppendingPathComponent:@"annotations.archive"];
    
    NSMutableArray *annotations = [NSKeyedUnarchiver unarchiveObjectWithFile:path];
    if (annotations) {
        [worldView addAnnotations:annotations];
    }
    
}

- (void)mapView:(MKMapView *)mapView
    didUpdateUserLocation:(MKUserLocation *)userLocation
{
    // Zoom code here
    CLLocationCoordinate2D loc = [userLocation coordinate];
    MKCoordinateRegion region = MKCoordinateRegionMakeWithDistance(loc, 1000, 1000);
    [worldView setRegion:region animated:YES];
    [activityIndicator stopAnimating];
    [gettingLocLabel setHidden:YES];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    // this method isn't imlemented yet
    [self findLocation];
    
    [textField resignFirstResponder];
    return YES;
}

- (void)findLocation
{
    [locationManager startUpdatingLocation];
    [activityIndicator startAnimating];
    [gettingLocLabel setHidden:NO];
}

- (void)foundLocation:(CLLocation *)loc
{
    CLLocationCoordinate2D coord = [loc coordinate];
    
    [[NSUserDefaults standardUserDefaults] setFloat:coord.latitude forKey:WhereamiLastLocationPrefLatKey];
    [[NSUserDefaults standardUserDefaults] setFloat:coord.longitude forKey:WhereamiLastLocationPrefLongKey];
    
    // Create an instance of BNRMapPoint with the current data
    BNRMapPoint *mp = [[BNRMapPoint alloc] initWithCoordinate:coord
                                                        title:[locationTitleField text]];
    // Addit to the mapView
    [worldView addAnnotation:mp];
    
    // Zoom to this locaton
    MKCoordinateRegion region = MKCoordinateRegionMakeWithDistance(coord, 250, 250);
    [worldView setRegion:region animated:YES];
    
    // Reset the UI
    [locationTitleField setText:@""];
    [activityIndicator stopAnimating];
    [gettingLocLabel setHidden:YES];
    [locationManager stopUpdatingLocation];
}

- (IBAction)mapSelect:(id)sender
    {
        [[NSUserDefaults standardUserDefaults] setInteger:[sender selectedSegmentIndex] forKey:WhereamiMapTypePrefKey];
        switch ([sender selectedSegmentIndex]) {
            case 0:
                [worldView setMapType:MKMapTypeStandard];
                break;
            case 1:
                [worldView setMapType:MKMapTypeSatellite];
                break;
            case 2:
                [worldView setMapType:MKMapTypeHybrid];
                break;
            default:
                break;
    }
}

- (void)dealloc
{
    // Tell the location manager to stop sending us messages
    [locationManager setDelegate:nil];
}

@end






















