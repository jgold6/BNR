//
//  main.m
//  Quiz
//
//  Created by Jonathan Goldberger on 11/17/13.
//  Copyright (c) 2013 Jonathan Goldberger. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "SingleViewApplicationiOSAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([SingleViewApplicationiOSAppDelegate class]));
    }
}
