//
//  QuizViewController.m
//  Quiz
//
//  Created by Jonathan Goldberger on 11/17/13.
//  Copyright (c) 2013 Jonathan Goldberger. All rights reserved.
//

#import "SingleViewApplicationiOSViewController.h"

@interface SingleViewApplicationiOSViewController ()

@end

@implementation SingleViewApplicationiOSViewController

- (id) initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        
    }
    
    // Return the address of the new object
    return self;
}


@end






















