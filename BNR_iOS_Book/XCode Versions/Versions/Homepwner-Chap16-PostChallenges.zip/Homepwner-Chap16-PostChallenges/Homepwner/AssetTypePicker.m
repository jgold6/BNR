//
//  AssetTypePicker.m
//  Homepwner
//
//  Created by Jonathan Goldberger on 1/6/14.
//  Copyright (c) 2014 Jonathan Goldberger. All rights reserved.
//

#import "AssetTypePicker.h"
#import "BNRItem.h"
#import "BNRItemStore.h"
#import "DetailViewController.h"

@implementation AssetTypePicker

@synthesize item, popoverController, controller;

- (id)init
{
    self = [super initWithStyle:UITableViewStylePlain];
    if (self) {
        UINavigationItem *n = [self navigationItem];
        [n setTitle:@"Asset Types"];
        
        // Create a new bar button item that will send
        // addNewItem: to AssetTypePicker
        UIBarButtonItem *bbi = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd
                                                                             target:self
                                                                             action:@selector(addNewItem:)];
        
        // Set this bar button item as the right item in the navgationItem
        [[self navigationItem] setRightBarButtonItem:bbi];
    }
    
    return self;
}

- (id)initWithStyle:(UITableViewStyle)style
{
    return [self init];
}

- (void)addNewItem:(id)sender
{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Create an Asset Type" message:@"Please enter a new asset type:" delegate:self cancelButtonTitle:@"Done" otherButtonTitles:nil];
    alert.alertViewStyle = UIAlertViewStylePlainTextInput;
    UITextField * alertTextField = [alert textFieldAtIndex:0];
    alertTextField.keyboardType = UIKeyboardTypeDefault;
    alertTextField.placeholder = @"Enter a new asset type";
    [alert show];
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    NSLog(@"Entered: %@",[[alertView textFieldAtIndex:0] text]);;
    [[BNRItemStore sharedStore] addAssetType:[[alertView textFieldAtIndex:0] text]];
    NSIndexPath *ip = [NSIndexPath indexPathForRow:[[[BNRItemStore sharedStore] allAssetTypes] count] -1 inSection:0];
    [self performSelector:@selector(tableView:didSelectRowAtIndexPath:) withObject:[self tableView] withObject:ip];
    
    [[self tableView] reloadData];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    NSInteger rows = 0;
    if (section == 0)
        rows = [[[BNRItemStore sharedStore] allAssetTypes] count];
    else {
        NSMutableArray *asseTypeItems = [self getAssetypeItems];
        rows = [asseTypeItems count];
    }
    return rows;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    if (section == 0)
        return @"Asset Types";
    else
        return @"Items with this asset type";
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)ip
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"UITableViewCell"];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"UITableViewCell"];
    }
    
    if ([ip section] == 0) {
        NSArray *allAssets = [[BNRItemStore sharedStore] allAssetTypes];
        NSManagedObject *assetType = [allAssets objectAtIndex:[ip row]];
        
        // Use key-value coding to get the asset type's label
        NSString *assetLabel = [assetType valueForKey:@"label"];
        [[cell textLabel] setText:assetLabel];
        
        // Checkmark the one that is currently selected
        if (assetType == [item assetType]) {
            [cell setAccessoryType:UITableViewCellAccessoryCheckmark];
        } else {
            [cell setAccessoryType:UITableViewCellAccessoryNone];
        }
    }
    
    if ([ip section] == 1) {
        NSMutableArray *asseTypeItems = [self getAssetypeItems];
        BNRItem *at = [asseTypeItems objectAtIndex:[ip row]];
        [[cell textLabel] setText:[at itemName]];
    }
    return cell;
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)ip
{
    if ([ip section] == 0) {
        NSLog(@"Testing selecting blank row");
        UITableViewCell *cell = [tableView cellForRowAtIndexPath:ip];
        for (UITableViewCell *cl in [tableView visibleCells]) {
            [cl setAccessoryType:UITableViewCellAccessoryNone];
        }
        
        [cell setAccessoryType:UITableViewCellAccessoryCheckmark];
        
        NSArray *allAssets = [[BNRItemStore sharedStore] allAssetTypes];
        NSManagedObject *assetType = [allAssets objectAtIndex:[ip row]];
        [item setAssetType:assetType];
//      if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad) {
//          [controller updateAssetType];
//          [popoverController dismissPopoverAnimated:YES];
//          popoverController = nil;
//      } else {
        [[self navigationController] popViewControllerAnimated:YES];
//      }
    }
}

- (NSMutableArray *)getAssetypeItems
{
    NSMutableArray *asseTypeItems = [[NSMutableArray alloc] init];
    NSArray *items = [[BNRItemStore sharedStore] allItems];
    for (BNRItem *i in items) {
        if ([i assetType] == [item assetType]) {
            [asseTypeItems addObject:i];
        }
    }
    return asseTypeItems;
}

@end


























