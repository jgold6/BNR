//
//  AssetTypePicker.h
//  Homepwner
//
//  Created by Jonathan Goldberger on 1/6/14.
//  Copyright (c) 2014 Jonathan Goldberger. All rights reserved.
//

#import <Foundation/Foundation.h>

@class BNRItem;
@class DetailViewController;

@interface AssetTypePicker : UITableViewController <UIAlertViewDelegate, UITableViewDataSource, UITableViewDelegate>

@property (nonatomic, strong) BNRItem *item;
@property (nonatomic, weak) UIPopoverController *popoverController;
@property (nonatomic, weak) DetailViewController *controller;

- (void)addNewItem:(id)sender;

@end
