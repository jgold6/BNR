//
//  HypnosisView.m
//  Hypnosister
//
//  Created by Jonathan Goldberger on 11/23/13.
//  Copyright (c) 2013 Jonathan Goldberger. All rights reserved.
//

#import "CrosshairView.h"

@implementation CrosshairView

@synthesize crosshairColor;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // All HypnosisViews start with a clear background color
        [self setBackgroundColor:[UIColor clearColor]];
    }
    return self;
}


- (void)drawRect:(CGRect)dirtyRect
{
    // Get Graphics context
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    
    // bounds equals position and size of CrosshairView
    CGRect bounds = [self bounds];
    
    // figure out the center of the bounds rectangle
    CGPoint center;
    center.x = bounds.origin.x + bounds.size.width / 2.0;
    center.y = bounds.origin.y + bounds.size.height / 2.0;
    
    // The thickness of the line should be 10 points wide
    CGContextSetLineWidth(ctx, 2);
    
     // Crosshairs
    [self setCrosshairColor:[UIColor greenColor]];
    [[self crosshairColor] setStroke];
    
    CGContextMoveToPoint(ctx, center.x - 20, center.y);
    CGContextAddLineToPoint(ctx, center.x + 20, center.y);
    CGContextStrokePath(ctx);
    CGContextMoveToPoint(ctx, center.x, center.y - 20);
    CGContextAddLineToPoint(ctx, center.x, center.y + 20);
    CGContextStrokePath(ctx);

}


@end




















