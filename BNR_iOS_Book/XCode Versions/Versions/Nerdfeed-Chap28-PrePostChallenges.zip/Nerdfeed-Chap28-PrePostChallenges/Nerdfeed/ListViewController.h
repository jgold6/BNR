//
//  ListViewController.h
//  Nerdfeed
//
//  Created by Jonathan Goldberger on 2/23/14.
//  Copyright (c) 2014 Jonathan Goldberger. All rights reserved.
//

#import <Foundation/Foundation.h>

// A forward declaration; we'll import the header in the .m file
@class RSSChannel;
@class WebViewController;

typedef enum {
    ListViewControllerRSSTypeBNR,
    ListViewControllerRSSTypeApple
} ListViewControllerRSSType;

@interface ListViewController : UITableViewController <UIAlertViewDelegate>
{
    RSSChannel *channel;
    ListViewControllerRSSType rssType;
    UISegmentedControl *rssTypeControl;
    int numberOfTopSongsToGet;
}
@property (nonatomic, strong) WebViewController *webViewController;

- (void)fetchEntries;

@end

// A new protocol named ListViewControllerDelegate
@protocol ListViewControllerDelegate

// Classes that conform to to this protocol must implement this method
- (void)listViewController:(ListViewController *)lvc handleObject:(id)object;

@end