//
//  JSONSerializable.h
//  Nerdfeed
//
//  Created by Jonathan Goldberger on 3/15/14.
//  Copyright (c) 2014 Jonathan Goldberger. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol JSONSerializable <NSObject>

- (void)readFromJSONDictionary:(NSDictionary *)d;

@end
