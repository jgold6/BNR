//
//  ChannelViewController.h
//  Nerdfeed
//
//  Created by Jonathan Goldberger on 3/2/14.
//  Copyright (c) 2014 Jonathan Goldberger. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ListViewController.h"

@class RSSChannel;
@class ListViewController;

@interface ChannelViewController : UITableViewController <ListViewControllerDelegate, UISplitViewControllerDelegate>
{
    RSSChannel *channel;
}

@end
