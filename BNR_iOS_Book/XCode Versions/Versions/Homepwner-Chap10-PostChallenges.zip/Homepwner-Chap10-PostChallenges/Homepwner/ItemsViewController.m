//
//  ItemsViewController.m
//  Homepwner
//
//  Created by Jonathan Goldberger on 12/28/13.
//  Copyright (c) 2013 Jonathan Goldberger. All rights reserved.
//

#import "ItemsViewController.h"
#import "BNRItemStore.h"
#import "BNRItem.h"

@implementation ItemsViewController

- (id)init
{
    // Call the superclass's designated inintitalizer
    self = [super initWithStyle:UITableViewStylePlain];
    if (self) {
        BNRItemStore *ps = [BNRItemStore sharedStore];
        [ps addItemWithName:@"No More Items!"
             valueInDollars:0
               serialNumber:@""];
        [ps addItemWithName:@"Brian Moore i9f"
             valueInDollars:350
               serialNumber:@"12345"];
        [ps addItemWithName:@"Brian Moore i2"
             valueInDollars:400
               serialNumber:@"67890"];
        [ps addItemWithName:@"Fender Acoustic"
             valueInDollars:450
               serialNumber:@"34567"];
    }
    return self;
}

- (id)initWithStyle:(UITableViewStyle)style
{
    return [self init];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    UIImage *image = [UIImage imageNamed:@"tvBgImage.png"];
    [[self tableView] setBackgroundView:[[UIImageView alloc] initWithImage:image]];
    
}

- (NSInteger)tableView:(UITableView *)tableView
numberOfRowsInSection:(NSInteger)section
{
    return [[[BNRItemStore sharedStore] allItems] count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView
         cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Create an instance of UITableViewCell, with default appearance
    // UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle
    //                                                   reuseIdentifier:@"UITableViewCell"];
    // Check for reusable cell first, use that if it exists
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"UITableViewCell"];
    
    // If there is no reusable cell of this type, create a new one
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle
                                      reuseIdentifier:@"UITaleViewCell"];
    }
    
    // Set teh text on the cell with the description of the item
    // that is at the nth index of items, where n = row this cell
    // will apear in on the tableView
    BNRItem *p = [[[BNRItemStore sharedStore] allItems] objectAtIndex:[indexPath row]];
    if ([indexPath row] == [[[BNRItemStore sharedStore] allItems] count] -1) {
        NSString *cellText = [[NSString alloc] initWithFormat:@"%@", [p itemName]];
        NSString *cellDetailText = @"";
        [[cell textLabel] setText:cellText];
        [[cell detailTextLabel] setText:cellDetailText];
        [[cell textLabel] setFont:[UIFont systemFontOfSize:12]];
        [cell setBackgroundColor:[UIColor colorWithRed:0.9f green:0.9f blue:1.0f alpha:0.75f]];
    } else {
        NSString *cellText = [[NSString alloc] initWithFormat:@"Item: %@, Value:  $%d", [p itemName], [p valueInDollars]];
        NSString *cellDetailText = [[NSString alloc] initWithFormat:@"SN: %@, Added:  %@", [p serialNumber], [p dateCreated]];
        [[cell textLabel] setText:cellText];
        [[cell detailTextLabel] setText:cellDetailText];
        [[cell textLabel] setFont:[UIFont systemFontOfSize:16]];
        [cell setBackgroundColor:[UIColor colorWithRed:1.0f green:1.0f blue:1.0f alpha:0.5f]];
    }
    
    return cell;
}

- (UIView *)headerView
{
    // If we haven't loaded the headerView yet...
    if (!headerView) {
        // Load HeaderView.xib
        [[NSBundle mainBundle] loadNibNamed:@"HeaderView" owner:self options:nil];
    }
    return headerView;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    // The height of the header View should be determined from the height of the
    // view in the XIB file
    return [[self headerView] bounds].size.height;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    return [self headerView];
}

- (IBAction)toggleEditingMode:(id)sender
{
    // If we are currently in editing mode...
    if ([self isEditing]) {
        // Change the text of the button to infomr the user of state
        [sender setTitle:@"Edit" forState:UIControlStateNormal];
        // Turn off editing mode
        [self setEditing:NO animated:YES];
        [[self btnAdd] setEnabled:YES];
    } else {
        // Change the text of the button to infomr the user of state
        [sender setTitle:@"Done" forState:UIControlStateNormal];
        // Enter editing mode
        [self setEditing:YES animated:YES];
        [[self btnAdd] setEnabled:NO];
    }
}

- (IBAction)addNewItem:(id)sender
{
    // Create  new BNRItem and add it to the store
    BNRItem *newItem = [[BNRItemStore sharedStore] createItem];
    
    // Figure out where that item is in the array
    int lastRow = [[[BNRItemStore sharedStore] allItems] indexOfObject:newItem];
    
    NSIndexPath *ip = [NSIndexPath indexPathForRow:lastRow inSection:0];
    
    [[self tableView]insertRowsAtIndexPaths:[NSArray arrayWithObject:ip]
                           withRowAnimation:UITableViewRowAnimationAutomatic];
    for (BNRItem *item in [[BNRItemStore sharedStore] allItems]) {
        NSLog(@"%@", [item description]);
    }
    NSLog(@"%@", @"----------------------");
    
}

- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([indexPath row] == [[[BNRItemStore sharedStore] allItems] count] - 1)
        return NO;
    else
        return YES;
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([indexPath row] == [[[BNRItemStore sharedStore] allItems] count] - 1)
        return NO;
    else
        return YES;
}

- (NSIndexPath *)tableView:(UITableView *)tableView targetIndexPathForMoveFromRowAtIndexPath:(NSIndexPath *)sourceIndexPath toProposedIndexPath:(NSIndexPath *)proposedDestinationIndexPath
{
    if (proposedDestinationIndexPath.row == [[[BNRItemStore sharedStore] allItems] count] -1) {
        return [NSIndexPath indexPathForRow:proposedDestinationIndexPath.row -1
                                   inSection:0];
    } else {
        return proposedDestinationIndexPath;
    }
}

- (void)tableView:(UITableView *)tableView
commitEditingStyle:(UITableViewCellEditingStyle)editingStyle
forRowAtIndexPath:(NSIndexPath *)indexPath
{
    // If the table view is asking to commit a delete command...
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        BNRItemStore *ps = [BNRItemStore sharedStore];
        NSArray *items = [ps allItems];
        BNRItem *p = [items objectAtIndex:[indexPath row]];
        [ps removeItem:p];
        
        // We also remove that row from the table view with an animation
        [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath]
                         withRowAnimation:UITableViewRowAnimationAutomatic];
    }
    for (BNRItem *item in [[BNRItemStore sharedStore] allItems]) {
        NSLog(@"%@", [item description]);
    }
    NSLog(@"%@", @"----------------------");
}

- (void)tableView:(UITableView *)tableView
moveRowAtIndexPath:(NSIndexPath *)sourceIndexPath
      toIndexPath:(NSIndexPath *)destinationIndexPath
{
    [[BNRItemStore sharedStore] moveItemAtIndex:[sourceIndexPath row]
                                        toIndex:[destinationIndexPath row]];
    for (BNRItem *item in [[BNRItemStore sharedStore] allItems]) {
        NSLog(@"%@", [item description]);
    }
    NSLog(@"%@", @"----------------------");
}

- (NSString *)tableView:(UITableView *)tableView titleForDeleteConfirmationButtonForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return @"Remove";
}

@end

















