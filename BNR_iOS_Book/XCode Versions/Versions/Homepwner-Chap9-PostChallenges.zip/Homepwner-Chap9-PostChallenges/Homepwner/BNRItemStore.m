//
//  BNRItemStore.m
//  Homepwner
//
//  Created by Jonathan Goldberger on 12/28/13.
//  Copyright (c) 2013 Jonathan Goldberger. All rights reserved.
//

#import "BNRItemStore.h"
#import "BNRItem.h"

@implementation BNRItemStore

+ (BNRItemStore *)sharedStore
{
    static BNRItemStore *sharedStore = nil;
    if (!sharedStore)
        sharedStore = [[super allocWithZone:nil] init];
    return sharedStore;
}

- (id)init
{
    self = [super init];
    if (self) {
        expensiveItems = [[NSMutableArray alloc] init];
        cheapItems = [[NSMutableArray alloc] init];
    }
    
    return self;
}

+ (id)allocWithZone:(struct _NSZone *)zone
{
    return [self sharedStore];
}

- (NSArray *)expensiveItems
{
    return expensiveItems;
}

- (NSArray *)cheapItems
{
    return cheapItems;
}

- (BNRItem *)createItem
{
    BNRItem *p = [BNRItem randomItem];
    
    if ([p valueInDollars] > 50) {
        [expensiveItems insertObject:p atIndex:0];
    } else {
        [cheapItems insertObject:p atIndex:0];
    }
    return p;
}

- (BNRItem *)addItemWithName:(NSString *)name
              valueInDollars:(int)value
                serialNumber:(NSString *)sn
{
    BNRItem *item = [self addItemWithName:name valueInDollars:value serialNumber:sn atIndex:0];
    return item;
}

- (BNRItem *)addItemWithName:(NSString *)name
              valueInDollars:(int)value
                serialNumber:(NSString *)sn
                     atIndex:(int)index
{
    BNRItem *item = [[BNRItem alloc] initWithItemName:name valueInDollars:value serialNumber:sn];
    if ([item valueInDollars] > 50) {
        [expensiveItems insertObject:item
                             atIndex:(index <= [expensiveItems count] && index >=0) ? index : 0];
    } else {
        [cheapItems insertObject:item
                             atIndex:(index < [cheapItems count] && index >=0) ? index : 0];
    }
    return item;
}

@end



































