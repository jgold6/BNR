//
//  ItemsViewController.m
//  Homepwner
//
//  Created by Jonathan Goldberger on 12/28/13.
//  Copyright (c) 2013 Jonathan Goldberger. All rights reserved.
//

#import "ItemsViewController.h"
#import "BNRItemStore.h"
#import "BNRItem.h"

@implementation ItemsViewController

- (id)init
{
    // Call the superclass's designated inintitalizer
    self = [super initWithStyle:UITableViewStyleGrouped];
    if (self) {
        [[BNRItemStore sharedStore] addItemWithName:@"No More Items!" valueInDollars:0 serialNumber:@""];
        for (int i = 0; i <12; i++) {
            [[BNRItemStore sharedStore] createItem];
        }
    }
    return self;
}

- (id)initWithStyle:(UITableViewStyle)style
{
    return [self init];
}

 - (void)viewDidLoad
{
    [super viewDidLoad];
    
    UIImageView *image = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"tvBgImage.png"]];
    [[self tableView] setBackgroundView:image];
    [[self tableView] setSectionHeaderHeight:60];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView
numberOfRowsInSection:(NSInteger)section
{
    if (section == 0)
        return [[[BNRItemStore sharedStore] expensiveItems] count];
    else
        return [[[BNRItemStore sharedStore] cheapItems] count];
}

- (NSString *)tableView:(UITableView *)tableView
titleForHeaderInSection:(NSInteger)section
{
    int totalValueExpensiveItems = 0;
    int totalValueCheapItems = 0;
    for (BNRItem *item in [[BNRItemStore sharedStore] expensiveItems]) {
        totalValueExpensiveItems += [item valueInDollars];
    }
    for (BNRItem *item in [[BNRItemStore sharedStore] cheapItems]) {
        totalValueCheapItems += [item valueInDollars];
    }
    if (section == 0) {
        return [[NSString alloc] initWithFormat:@"Expensive Items Total Value $%d", totalValueExpensiveItems];
    } else {
        return [[NSString alloc] initWithFormat:@"Cheap Items Total Value $%d", totalValueCheapItems];
    }
}

//- (NSString *)tableView:(UITableView *)tableView
//titleForFooterInSection:(NSInteger)section
//{
//    if (section == 0)
//        return @"";
//    else
//        return @"No More Items!";
//}

- (UITableViewCell *)tableView:(UITableView *)tableView
         cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Create an instance of UITableViewCell, with default appearance
    // UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle
    //                                                   reuseIdentifier:@"UITableViewCell"];
    // Check for reusable cell first, use that if it exists
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"UITableViewCell"];
    
    // If there is no reusable cell of this type, create a new one
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle
                                      reuseIdentifier:@"UITaleViewCell"];
    }
    
    // Set teh text on the cell with the description of the item
    // that is at the nth index of items, where n = row this cell
    // will apear in on the tableView
    BNRItem *p;
    if ([indexPath section] == 0) {
        p = [[[BNRItemStore sharedStore] expensiveItems] objectAtIndex:[indexPath row]];
    } else {
        p = [[[BNRItemStore sharedStore] cheapItems] objectAtIndex:[indexPath row]];
    }
    
    NSString *cellText = [[NSString alloc] initWithFormat:@"Item: %@, Value:  $%d", [p itemName], [p valueInDollars]];
    NSString *cellDetailText = [[NSString alloc] initWithFormat:@"SN: %@, Added:  %@", [p serialNumber], [p dateCreated]];
    [[cell textLabel] setText:cellText];
    [[cell detailTextLabel] setText:cellDetailText];
    [[cell textLabel] setFont:[UIFont systemFontOfSize:20]];
    [cell setBackgroundColor:[UIColor clearColor]];
    if ([indexPath section] == 1 && [indexPath row] == [[[BNRItemStore sharedStore] cheapItems] count] - 1) {
        NSString *cellText = [[NSString alloc] initWithFormat:@"%@", [p itemName]];
        NSString *cellDetailText = @"";
        [[cell textLabel] setText:cellText];
        [[cell detailTextLabel] setText:cellDetailText];
        [[cell textLabel] setFont:[UIFont systemFontOfSize:10]];
        [cell setBackgroundColor:[UIColor colorWithRed:1.0f green:0.9f blue:0.9f alpha:0.5f]];
    }
    
    return cell;
}

- (float)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([indexPath section] != 1 || [indexPath row] != [[[BNRItemStore sharedStore] cheapItems] count]-1) {
        return 60;
    } else {
        return 44;
    }
}

@end






















