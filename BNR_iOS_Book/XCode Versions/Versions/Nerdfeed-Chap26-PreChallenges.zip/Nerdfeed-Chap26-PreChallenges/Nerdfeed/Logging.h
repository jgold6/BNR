//
//  Logging.h
//  Nerdfeed
//
//  Created by Jonathan Goldberger on 2/23/14.
//  Copyright (c) 2014 Jonathan Goldberger. All rights reserved.
//

#ifndef Nerdfeed_Logging_h
#define Nerdfeed_Logging_h
#define WSLog(...) do {} while (0)//NSLog(__VA_ARGS__) //


#endif
