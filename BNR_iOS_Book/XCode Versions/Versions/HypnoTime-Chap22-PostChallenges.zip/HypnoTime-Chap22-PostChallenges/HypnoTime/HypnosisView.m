//
//  HypnosisView.m
//  Hypnosister
//
//  Created by Jonathan Goldberger on 11/23/13.
//  Copyright (c) 2013 Jonathan Goldberger. All rights reserved.
//

#import "HypnosisView.h"

@implementation HypnosisView

@synthesize circleColor;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // All HypnosisViews start with a clear background color
        [self setBackgroundColor:[UIColor clearColor]];
        // Sets the circle color
        [self setCircleColor:[UIColor lightGrayColor]];
        
        // set up segmented control
        NSArray *items = [NSArray arrayWithObjects:@"Gray", @"Red", @"Green", @"Blue", nil];
        segControl = [[UISegmentedControl alloc] initWithItems:items];
        CGRect segFrame = CGRectMake(0, 25, self.bounds.size.width, 25);
        segControl.frame = segFrame;
        segControl.backgroundColor = [UIColor whiteColor];
        [segControl setAutoresizingMask:(UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleBottomMargin)];
        
//        segControl.tintColor = [UIColor blackColor];
        [[segControl.subviews objectAtIndex:0] setTintColor:[UIColor grayColor]];
        [[segControl.subviews objectAtIndex:1] setTintColor:[UIColor redColor]];
        [[segControl.subviews objectAtIndex:2] setTintColor:[UIColor greenColor]];
        [[segControl.subviews objectAtIndex:3] setTintColor:[UIColor blueColor]];
        
        [segControl setSelectedSegmentIndex:0];
        
        [segControl addTarget:self
                       action:@selector(action:)
             forControlEvents:UIControlEventValueChanged];
        
        [self addSubview:segControl];
        
        // Create the new layer object
        boxLayer = [[CALayer alloc] init];
        
        // Give it a size
        [boxLayer setBounds:CGRectMake(0.0, 0.0, 85.0, 85.0)];
        
        // Give it a location
        [boxLayer setPosition:CGPointMake(160.0, 100.0)];
        
        // Round the corners
        [boxLayer setCornerRadius:20.0];
        
        // Set a shadow
        UIColor *shadowColor = [UIColor blueColor];
        [boxLayer setShadowColor:[shadowColor CGColor]];
        [boxLayer setShadowOffset:CGSizeMake(5.0, 5.0)];
        [boxLayer setShadowOpacity:1.0];
        
        // Make half transparent red the background color for the layer
        UIColor *reddish = [UIColor colorWithRed:1.0 green:0.0 blue:0.0 alpha:1.0];
        
        // Get a CGColor object with the same color values
        CGColorRef cgReddish = [reddish CGColor];
        [boxLayer setBackgroundColor:cgReddish];
        [boxLayer setOpacity:0.5];
        
        // Create a UIImage
        UIImage *layerImage = [UIImage imageNamed:@"Hypno.png"];
        
        // Get the underlying CGimage
        CGImageRef image = [layerImage CGImage];
        
        // Put the CGImage on the layer
        [boxLayer setContents:(__bridge id)image];
        
        // Inset the image a but on each side
        [boxLayer setContentsRect:CGRectMake(-0.1, -0.1, 1.2, 1.2)];
        
        // Let the image resize (without changing aspect ratio
        // to fill the contentRct
        [boxLayer setContentsGravity:kCAGravityResizeAspect];
        
        //
        // Boxlayers sublayer
        // Create the new layer object
        CALayer *boxSublayer = [[CALayer alloc] init];
        
        // Give it a size
        [boxSublayer setBounds:CGRectMake(0.0, 0.0, boxLayer.bounds.size.width/2, boxLayer.bounds.size.height/2)];
        
        // Give it a location
        [boxSublayer setPosition:CGPointMake(boxLayer.bounds.size.width/2, boxLayer.bounds.size.height/2)];
        
        // Round the corners
        [boxSublayer setCornerRadius:10.0];
        
        // Make half transparent red the background color for the layer
        UIColor *greenish = [UIColor colorWithRed:0.0 green:1.0 blue:0.0 alpha:0.5];
        
        // Get a CGColor object with the same color values
        CGColorRef cgGreenish = [greenish CGColor];
        [boxSublayer setBackgroundColor:cgGreenish];
        
        // Create a UIImage
        UIImage *subLayerImage = [UIImage imageNamed:@"Map.png"];
        
        // Get the underlying CGimage
        CGImageRef subImage = [subLayerImage CGImage];
        
        // Put the CGImage on the layer
        [boxSublayer setContents:(__bridge id)subImage];
        
        // Let the image resize (without changing aspect ratio
        // to fill the contentRct
        [boxSublayer setContentsGravity:kCAGravityResizeAspect];
        // end boxlayers sublayer
        //
        
        // Make it a sublayer of the view's layer
        [boxLayer addSublayer:boxSublayer];
        [[self layer] addSublayer:boxLayer];
                
    }
    return self;
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    UITouch *t = [touches anyObject];
    CGPoint p = [t locationInView:self];
    [boxLayer setPosition:p];
    
}

- (void) touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
    UITouch *t = [touches anyObject];
    CGPoint p = [t locationInView:self];
    [CATransaction begin];
    [CATransaction setDisableActions:YES];
    [boxLayer setPosition:p];
    [CATransaction commit];
}

- (void)setCircleColor:(UIColor *)clr
{
    circleColor = clr;
    [self setNeedsDisplay];
}

- (void)drawRect:(CGRect)dirtyRect
{
    // Get Graphics context
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    
    // bounds equals position and size of HypnosisView
    CGRect bounds = [self bounds];
    bounds.origin.y += 23;
    bounds.size.height -= 23;
    CGContextAddRect(ctx, bounds);
    CGContextClip(ctx);
    
    // figure out the center of the bounds rectangle
    CGPoint center;
    center.x = bounds.origin.x + bounds.size.width / 2.0;
    center.y = bounds.origin.y + bounds.size.height / 2.0;
    
    // The radius of the circle should be nearly as big as the view
    float maxRadius = hypot(bounds.size.width, bounds.size.height) / 2.0;
    
    // The thickness of the line should be 10 points wide
    CGContextSetLineWidth(ctx, 10);
    
    // Set stroke color
    [[self circleColor] setStroke];
    
    // The color of the line should be gray (rgb = 0.6, alpha = 1.0)
    //CGContextSetRGBStrokeColor(ctx, 0.6, 0.6, 0.6, 1.0);
    
    // Draw concentric circles from the outside in
    for (float currentRadius = maxRadius; currentRadius > 0; currentRadius -= 20) {
        // Add a path to the context
        CGContextAddArc(ctx, center.x, center.y, currentRadius, 0.0, M_PI * 2.0, YES);
        // Perfomr drawing instruction, removes path
        CGContextStrokePath(ctx);
//        if (currentRadius < maxRadius/2.0) {
//            [self setCircleColor:[UIColor redColor]];
//            [[self circleColor] setStroke];
//        }
        
    }
    
    // Create a string
    NSString *text = @"You are getting sleepy.";
    
    // Get a font to draw it in
    UIFont *font = [UIFont boldSystemFontOfSize:28];
    
    CGRect textRect;
    
    // How big is this string when drawn in the font?
    textRect.size = [text sizeWithFont:font];
    
    // Put that string  the center of the view
    textRect.origin.x = center.x - textRect.size.width / 2.0;
    textRect.origin.y = center.y - textRect.size.height / 2.0;
    
    // Set the fill color of the current context to white
    [[UIColor whiteColor] setFill];
    
    // The shadow will move 4 points to the right and 3 points down from the text
    CGSize offset = CGSizeMake(4,3);
    
    // The shadow will be dark gray in color
    CGColorRef color = [[UIColor blackColor] CGColor];
    
    // Set the shadow of the contezt with these parameters
    // all subsequent drawing will be shadowed
    CGContextSetShadowWithColor(ctx, offset, 2.0, color);
    
    // Draw the string
    [text drawInRect:textRect
            withFont:font];
    
    
}

- (BOOL)canBecomeFirstResponder
{
    return YES;
}

- (void)motionBegan:(UIEventSubtype)motion
          withEvent:(UIEvent *)event
{
    if (motion == UIEventSubtypeMotionShake)
    {
        NSLog(@"Device started shaking!");
        if ([self circleColor] != [UIColor orangeColor]) {
            lastSelectedColor = [self circleColor];
            lastSelectedSegmentIndex = segControl.selectedSegmentIndex;
            [self setCircleColor:[UIColor orangeColor]];
            [segControl setSelectedSegmentIndex:-1];
        }
        else {
            [self setCircleColor:lastSelectedColor];
            [segControl setSelectedSegmentIndex:lastSelectedSegmentIndex];
        }
        
    }
}

- (void)action:(id)sender
{
    switch (segControl.selectedSegmentIndex) {
        case 0:
            [self setCircleColor:[UIColor lightGrayColor]];
            break;
        case 1:
            [self setCircleColor:[UIColor redColor]];
            break;
        case 2:
            [self setCircleColor:[UIColor greenColor]];
            break;
        case 3:
            [self setCircleColor:[UIColor blueColor]];
        default:
            break;
    }
    
}

@end




















