//
//  ImageViewController.h
//  Homepwner
//
//  Created by Jonathan Goldberger on 1/4/14.
//  Copyright (c) 2014 Jonathan Goldberger. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ImageViewController : UIViewController <UIScrollViewDelegate>
{
    __weak IBOutlet UIImageView *imageView;
    __weak IBOutlet UIScrollView *scrollView;
}
@property (nonatomic, strong) UIImage *image;
@end
