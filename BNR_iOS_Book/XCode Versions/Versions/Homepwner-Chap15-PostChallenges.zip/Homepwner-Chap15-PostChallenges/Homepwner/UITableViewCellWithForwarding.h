//
//  UITableViewCellWithForwarding.h
//  Homepwner
//
//  Created by Jonathan Goldberger on 1/5/14.
//  Copyright (c) 2014 Jonathan Goldberger. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITableViewCellWithForwarding : UITableViewCell

- (void)forwardMessage:(UIViewController *)vc selector:(SEL)sel withObject:(NSObject *)obj1 withObject:(NSObject *)obj2;

@end
