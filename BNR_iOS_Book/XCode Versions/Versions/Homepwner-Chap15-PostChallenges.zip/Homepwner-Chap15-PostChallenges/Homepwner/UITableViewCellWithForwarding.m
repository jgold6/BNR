//
//  UITableViewCellWithForwarding.m
//  Homepwner
//
//  Created by Jonathan Goldberger on 1/5/14.
//  Copyright (c) 2014 Jonathan Goldberger. All rights reserved.
//

#import "UITableViewCellWithForwarding.h"

@implementation UITableViewCellWithForwarding

- (void)forwardMessage:(UIViewController *)vc selector:(SEL)sel withObject:(NSObject *)obj1 withObject:(NSObject *)obj2
{
    if ([vc respondsToSelector:sel]) {
        [vc performSelector:sel withObject:obj1 withObject:obj2];
    }
    
}

@end
