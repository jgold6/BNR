//
//  HomepwnerItemCell.h
//  Homepwner
//
//  Created by Jonathan Goldberger on 1/4/14.
//  Copyright (c) 2014 Jonathan Goldberger. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "UITableViewCellWithForwarding.h"

@interface HomepwnerItemCell : UITableViewCellWithForwarding

@property (weak, nonatomic) IBOutlet UIImageView *thumbnailView;
@property (weak, nonatomic) IBOutlet UILabel *nameLabel;
@property (weak, nonatomic) IBOutlet UILabel *serialNumberLabel;
@property (weak, nonatomic) IBOutlet UILabel *valueLabel;

@property (weak, nonatomic) id controller;
@property (weak, nonatomic) UITableView *tableView;

- (IBAction)showImage:(id)sender;

@end
