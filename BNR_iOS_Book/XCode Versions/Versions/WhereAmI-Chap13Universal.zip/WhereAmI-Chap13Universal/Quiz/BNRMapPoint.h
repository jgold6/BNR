//
//  BRMapPoint.h
//  WhereAmI
//
//  Created by Jonathan Goldberger on 11/23/13.
//  Copyright (c) 2013 Jonathan Goldberger. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreLocation/CoreLocation.h>
#import <Mapkit/MapKit.h>

@interface BNRMapPoint : NSObject <MKAnnotation>
{
    
}

// A new designated initializer for BNRMapPoint
- (id)initWithCoordinate:(CLLocationCoordinate2D)c title:(NSString *)t;

// This is a required property from MKAnnotation
@property (nonatomic, readonly) CLLocationCoordinate2D coordinate;

// THis is an optional property from MKAnnotation
@property (nonatomic, copy)NSString *title;
@property (nonatomic, copy)NSString *subtitle;

@end
