//
//  main.m
//  TestTouchUpINside
//
//  Created by Jonathan Goldberger on 2/1/14.
//  Copyright (c) 2014 Jonathan Goldberger. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "TTAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([TTAppDelegate class]));
    }
}
