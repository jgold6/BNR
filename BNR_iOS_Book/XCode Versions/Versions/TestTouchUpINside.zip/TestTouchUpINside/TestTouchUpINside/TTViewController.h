//
//  TTViewController.h
//  TestTouchUpINside
//
//  Created by Jonathan Goldberger on 2/1/14.
//  Copyright (c) 2014 Jonathan Goldberger. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TTViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIButton *buttonOutlet;
- (void)upInside:(id)sender;



@end
