//
//  TTViewController.m
//  TestTouchUpINside
//
//  Created by Jonathan Goldberger on 2/1/14.
//  Copyright (c) 2014 Jonathan Goldberger. All rights reserved.
//

#import "TTViewController.h"

@interface TTViewController ()

@end

@implementation TTViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    [[self buttonOutlet] addTarget:self action:@selector(upInside:) forControlEvents:UIControlEventTouchUpInside | UIControlEventTouchUpOutside];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)upInside:(id)sender {
    NSLog(@"TouchUpInside");
    [[self buttonOutlet] setTitle:@"TouchUpInside" forState:UIControlStateNormal];
}

@end
