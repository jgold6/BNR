//
//  TTAppDelegate.h
//  TestTouchUpINside
//
//  Created by Jonathan Goldberger on 2/1/14.
//  Copyright (c) 2014 Jonathan Goldberger. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TTAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
