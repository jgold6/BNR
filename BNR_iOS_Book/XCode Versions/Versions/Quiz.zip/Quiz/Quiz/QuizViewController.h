//
//  QuizViewController.h
//  Quiz
//
//  Created by Jonathan Goldberger on 11/17/13.
//  Copyright (c) 2013 Jonathan Goldberger. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QuizViewController : UIViewController
{
    int currentQuestionIndex;
    
    // The model Objects
    NSMutableArray *questions;
    NSMutableArray *answers;
    
    // The View objects
    IBOutlet UILabel *questionField;
    IBOutlet UILabel *answerField;
    
}

- (IBAction)showQuestion:(id)sender;
- (IBAction)showAnswer:(id)sender;

@end
