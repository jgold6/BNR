//
//  main.m
//  RandomPossessions
//
//  Created by Jonathan Goldberger on 11/17/13.
//  Copyright (c) 2013 Jonathan Goldberger. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BNRItem.h"
#import "BNRContainer.h"

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        // insert code here...
        BNRContainer *items = [[BNRContainer alloc] init];
        for (int i = 0; i < 10; i++) {
            BNRItem *p = [BNRItem randomItem];
            [items addBNRItem:p];
        }
        
        BNRContainer *items2 = [[BNRContainer alloc] init];
        for (int i = 0; i < 5; i++) {
            BNRItem *p = [BNRItem randomItem];
            [items2 addBNRItem:p];
        }
        
        BNRItem *iPod = [[BNRItem alloc] initWithItemName:@"iPod" valueInDollars:199 serialNumber:@"5K9G4"];
        BNRItem *mbpro = [[BNRItem alloc] initWithItemName:@"MacBook Pro" valueInDollars:1499 serialNumber:@"7G4G2"];
        [items2 addBNRItem:iPod];
        [items2 addBNRItem:mbpro];
        
        
        [items addBNRItem:items2];
        
        [items addBNRItem:[[BNRItem alloc] initWithItemName:@"Red Sofa"
                                             valueInDollars:100
                                               serialNumber:@"A1B2C"]];
        
        [items2 removeBNRItemAtIndex:5];
        [items2 removeBNRItemAtIndex:0];
        [items removeBNRItemAtIndex:6];
        
        NSLog(@"%@", [items description]);
        
        items = nil;
    }
    return 0;
}

