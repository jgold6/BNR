//
//  BNRContainer.h
//  RandomPossessions
//
//  Created by Jonathan Goldberger on 11/17/13.
//  Copyright (c) 2013 Jonathan Goldberger. All rights reserved.
//

#import "BNRItem.h"

@interface BNRContainer : BNRItem
{
    NSMutableArray *bnrItems;
}

- (void)addBNRItem:(BNRItem *)item;
- (void)removeBNRItemAtIndex:(int)index;


@end
