//
//  BNRContainer.m
//  RandomPossessions
//
//  Created by Jonathan Goldberger on 11/17/13.
//  Copyright (c) 2013 Jonathan Goldberger. All rights reserved.
//

#import "BNRContainer.h"

@implementation BNRContainer

- (id)init
{
    self = [super init];
    if (self)
    {
        bnrItems = [[NSMutableArray alloc] init];
        itemName = @"Container";
        valueInDollars = 0;
        serialNumber = @"";
    }
    
    return self;
}

- (void)addBNRItem:(BNRItem *)item
{
    valueInDollars += [item valueInDollars];
    [bnrItems addObject:item];
    [item setContainer:self];
}

- (void)removeBNRItemAtIndex:(int)index
{
    BNRItem *item = [bnrItems objectAtIndex:index];
    valueInDollars -= [item valueInDollars];
    //    NSLog(@"item container: %@", [item container]);
    if ([[item container] container])
    {
        BNRContainer *cont = [[BNRContainer alloc] init];
        cont = (BNRContainer *)[[item container] container];
        [cont setValueInDollars:[cont valueInDollars] - [item valueInDollars]];
    }
    
    [bnrItems removeObjectAtIndex:index];
    
}



- (NSString *)description
{
    NSMutableString *descriptionString =  [[NSMutableString alloc] initWithFormat:@"\n%@ (%@): Worth $%d, recorded on %@\n", itemName, serialNumber, valueInDollars, dateCreated];
    for(BNRItem *item in bnrItems){
        [descriptionString appendString:[item description]];
        [descriptionString appendString:@"\n"];
    }
    return descriptionString;
}


@end
