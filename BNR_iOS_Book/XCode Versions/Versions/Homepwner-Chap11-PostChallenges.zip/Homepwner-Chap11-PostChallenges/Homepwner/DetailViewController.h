//
//  DetailViewController.h
//  Homepwner
//
//  Created by Jonathan Goldberger on 12/29/13.
//  Copyright (c) 2013 Jonathan Goldberger. All rights reserved.
//

#import <UIKit/UIKit.h>

@class BNRItem;

@interface DetailViewController : UIViewController <UITextFieldDelegate, UIAlertViewDelegate>
{
    __weak IBOutlet UITextField *nameField;
    __weak IBOutlet UITextField *serialNumberField;
    __weak IBOutlet UITextField *valueField;
    __weak IBOutlet UILabel *dateLabel;
    
}
- (IBAction)backgroundTapped:(id)sender;
- (IBAction)changeDate:(id)sender;

@property (nonatomic, strong) BNRItem *item;
@property (nonatomic, strong) UIAlertView *av;
@property (nonatomic, strong) UIDatePicker *dp;
@property (nonatomic, strong) UIViewController *dpvc;

@end
