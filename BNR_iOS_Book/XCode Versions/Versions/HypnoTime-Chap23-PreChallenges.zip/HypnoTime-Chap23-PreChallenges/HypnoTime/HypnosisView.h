//
//  HypnosisView.h
//  Hypnosister
//
//  Created by Jonathan Goldberger on 11/23/13.
//  Copyright (c) 2013 Jonathan Goldberger. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <QuartzCore/QuartzCore.h>

@interface HypnosisView : UIView
{
    UISegmentedControl *segControl;
    int lastSelectedSegmentIndex;
    UIColor *lastSelectedColor;
    
    CALayer *boxLayer;
}

@property (nonatomic, strong) UIColor *circleColor;

@end
