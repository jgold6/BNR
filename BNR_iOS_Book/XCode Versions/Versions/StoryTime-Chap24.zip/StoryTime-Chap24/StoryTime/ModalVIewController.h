//
//  ModalVIewController.h
//  StoryTime
//
//  Created by Jonathan Goldberger on 2/23/14.
//  Copyright (c) 2014 Jonathan Goldberger. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ModalVIewController : UIViewController

- (IBAction)dismiss:(id)sender;

@end
