//
//  WebViewController.m
//  Nerdfeed
//
//  Created by Jonathan Goldberger on 2/23/14.
//  Copyright (c) 2014 Jonathan Goldberger. All rights reserved.
//

#import "WebViewController.h"

@implementation WebViewController

@synthesize bbiBack, bbiForward;

- (void)loadView
{
    // Create an instance of UIWebView as large as the screen
    CGRect screenFrame = [[UIScreen mainScreen] applicationFrame];
    UIWebView *wv = [[UIWebView alloc] initWithFrame:screenFrame];
    [wv setDelegate:self];
    // Tell webView to scalle web content to fit withing the bounds of webView
    [wv setScalesPageToFit:YES];
    
    bbiBack = [[UIBarButtonItem alloc] initWithTitle:@"Back" style:UIBarButtonItemStyleBordered target:self action:@selector(back)];
    bbiForward = [[UIBarButtonItem alloc] initWithTitle:@"Forward" style:UIBarButtonItemStyleBordered target:self action:@selector(forward)];
    [bbiBack setWidth:screenFrame.size.width/2];
    [bbiForward setWidth:screenFrame.size.width/2];
    NSArray *bbiArray = [[NSArray alloc] initWithObjects:bbiBack, bbiForward, nil];
    
    [self setToolbarItems:bbiArray];

    [self setView:wv];
}

- (void)viewWillAppear:(BOOL)animated
{
    [[self navigationController] setToolbarHidden:NO];
    }

- (void) viewWillDisappear:(BOOL)animated
{
    [[self navigationController] setToolbarHidden:YES];
}

- (void)webViewDidFinishLoad:(UIWebView *)wv
{
    if ([wv canGoBack])
        [bbiBack setEnabled:YES];
    else
        [bbiBack setEnabled:NO];
    if ([wv canGoForward])
        [bbiForward setEnabled:YES];
    else
        [bbiForward setEnabled:NO];
}

- (UIWebView *)webView
{
    return (UIWebView *)[self view];
}

- (void)back
{
    [[self webView] goBack];
}

- (void)forward
{
    [[self webView] goForward];
}

@end















