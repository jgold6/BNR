//
//  RSSItemCell.m
//  Nerdfeed
//
//  Created by Jonathan Goldberger on 3/1/14.
//  Copyright (c) 2014 Jonathan Goldberger. All rights reserved.
//

#import "RSSItemCell.h"

@implementation RSSItemCell

@synthesize titleLabel, authorLabel, categoryLabel;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        //[[self textLabel] removeFromSuperview];
        CGRect msBounds = [[UIScreen mainScreen] bounds];
        
        titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, msBounds.size.width/3-5, 50)];
        authorLabel = [[UILabel alloc] initWithFrame:CGRectMake(msBounds.size.width/3+5, 0, msBounds.size.width/3-5, 50)];
        categoryLabel = [[UILabel alloc] initWithFrame:CGRectMake(2*msBounds.size.width/3+10, 0, msBounds.size.width/3-5, 50)];
        
        [titleLabel setBackgroundColor:[UIColor redColor]];
        [authorLabel setBackgroundColor:[UIColor grayColor]];
        [categoryLabel setBackgroundColor:[UIColor blueColor]];

        [categoryLabel setAutoresizingMask: (UIViewAutoresizingFlexibleWidth)];

        [self addSubview:titleLabel];
        [self addSubview:authorLabel];
        [self addSubview:categoryLabel];
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
