//
//  RSSItemCell.h
//  Nerdfeed
//
//  Created by Jonathan Goldberger on 3/1/14.
//  Copyright (c) 2014 Jonathan Goldberger. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RSSItemCell : UITableViewCell

@property (strong, nonatomic) UILabel *titleLabel;
@property (strong, nonatomic) UILabel *authorLabel;
@property (strong, nonatomic) UILabel *categoryLabel;

@end
