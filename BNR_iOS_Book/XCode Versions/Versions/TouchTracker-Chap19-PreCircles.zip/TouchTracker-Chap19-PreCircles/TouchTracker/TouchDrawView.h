//
//  TouchDrawView.h
//  TouchTracker
//
//  Created by Jonathan Goldberger on 1/26/14.
//  Copyright (c) 2014 Jonathan Goldberger. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TouchDrawView : UIView
{
    NSMutableDictionary *linesInProcess;
}
- (void)clearAll;
- (void)endTouches:(NSSet *)touches;

@end
