//
//  TouchViewController.m
//  TouchTracker
//
//  Created by Jonathan Goldberger on 1/26/14.
//  Copyright (c) 2014 Jonathan Goldberger. All rights reserved.
//

#import "TouchViewController.h"
#import "TouchDrawView.h"

@implementation TouchViewController

- (void)loadView
{
    TouchDrawView *drawView = [[TouchDrawView alloc] initWithFrame:CGRectZero];
    [self setView:drawView];
}


@end
