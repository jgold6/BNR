//
//  LineStore.h
//  TouchTracker
//
//  Created by Jonathan Goldberger on 1/26/14.
//  Copyright (c) 2014 Jonathan Goldberger. All rights reserved.
//

#import <Foundation/Foundation.h>

@class Line;

@interface LineStore : NSObject
{
    NSMutableArray *completeLines;
}

+ (LineStore *)sharedStore;

- (NSArray *)completeLines;

- (void)addCompletedLine:(Line *)line;
- (void)clearShapes;

- (NSString *)lineArchivePath;
- (BOOL)saveLines;

@end
