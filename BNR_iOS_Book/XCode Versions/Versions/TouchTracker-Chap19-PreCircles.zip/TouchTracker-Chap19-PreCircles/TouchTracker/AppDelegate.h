//
//  AppDelegate.h
//  TouchTracker
//
//  Created by Jonathan Goldberger on 1/26/14.
//  Copyright (c) 2014 Jonathan Goldberger. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TouchViewController.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) TouchViewController *tvc;

@end
