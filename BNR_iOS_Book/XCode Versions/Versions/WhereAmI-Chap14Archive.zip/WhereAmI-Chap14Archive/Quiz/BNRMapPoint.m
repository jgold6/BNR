//
//  BRMapPoint.m
//  WhereAmI
//
//  Created by Jonathan Goldberger on 11/23/13.
//  Copyright (c) 2013 Jonathan Goldberger. All rights reserved.
//

#import "BNRMapPoint.h"

@implementation BNRMapPoint

@synthesize coordinate, title, subtitle;

- (id)initWithCoordinate:(CLLocationCoordinate2D)c title:(NSString *)t
{
    self = [super init];
    if (self) {
        coordinate = c;
        
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        [dateFormatter setDateStyle:NSDateFormatterMediumStyle];
        [dateFormatter setTimeStyle:NSDateFormatterShortStyle];
        NSMutableString *concat = [[NSMutableString alloc] init];
        [concat appendString:@"Created: "];
        [concat appendString:[dateFormatter stringFromDate:[NSDate date]]];
        
        [self setTitle:t];
        [self setSubtitle:concat];
    }
    return self;;
}

- (id)init
{
    return [self initWithCoordinate:CLLocationCoordinate2DMake(43.07, -89.32)
                              title:@"Hometown"];
}

- (void)encodeWithCoder:(NSCoder *)aCoder
{
    [aCoder encodeObject:title forKey:@"title"];
    [aCoder encodeObject:subtitle forKey:@"subtitle"];
    [aCoder encodeDouble:coordinate.latitude forKey:@"lat"];
    [aCoder encodeDouble:coordinate.longitude forKey:@"lon"];
}

- (id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super init];
    if (self) {
        [self setTitle:[aDecoder decodeObjectForKey:@"title"]];
        [self setSubtitle:[aDecoder decodeObjectForKey:@"subtitle"]];
        [self setCoordinate:CLLocationCoordinate2DMake([aDecoder decodeDoubleForKey:@"lat"], [aDecoder decodeDoubleForKey:@"lon"])];
    }
    return self;
}



@end
