//
//  RSSChannel.m
//  Nerdfeed
//
//  Created by Jonathan Goldberger on 2/23/14.
//  Copyright (c) 2014 Jonathan Goldberger. All rights reserved.
//

#import "RSSChannel.h"
#import "RSSItem.h"

@implementation RSSChannel

@synthesize parentParserDelegate, title, infoString, items;

// Gold Challenge
@synthesize hiddenItems;
// End Gold Challenge

- (id)init
{
    self = [super init];
    
    if (self) {
        // Create the container for the RSSItems this channel has;
        // We'll create the RSSItem class shortly
        items = [[NSMutableArray alloc] init];
        hiddenItems = [[NSMutableArray alloc] init]; // gold challenge ch26
    }
    
    return self;
}

- (void)parser:(NSXMLParser *)parser
didStartElement:(NSString *)elementName
  namespaceURI:(NSString *)namespaceURI
 qualifiedName:(NSString *)qName
    attributes:(NSDictionary *)attributeDict
{
    WSLog(@"\t%@ found a %@ element", self, elementName);
    if ([elementName isEqual:@"title"]) {
        currentString = [[NSMutableString alloc] init];
        [self setTitle:currentString];
    }
    else if ([elementName isEqual:@"description"]) {
        currentString =[[NSMutableString alloc] init];
        [self setInfoString:currentString];
    }
    else if ([elementName isEqual:@"item"]) {
        // When we find an item, create an instance of RSSItem
        RSSItem *entry = [[RSSItem alloc] init];
        
        // Set up its parent as ourselves so we can regain control of the parser
        [entry setParentParserDelegate:self];
        
        // Turn the parser over to the RSSItem
        [parser setDelegate:entry];
        
        // Add the item to our array and release our hold on it
        [items addObject:entry];
    }
}

- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)str
{
    [currentString appendString:str];
}

- (void)parser:(NSXMLParser *)parser
 didEndElement:(NSString *)elementName
  namespaceURI:(NSString *)namespaceURI
 qualifiedName:(NSString *)qName
{
    // If we are in an element that we were collecting the string for,
    // this appropriately releases our hold on it and the permanent ivar keeps
    // ownership of it. If we weren't parsing such an element, currentString
    // is nil already
    currentString = nil;
    
    // if the element that ended was the channel, give up control to
    // who gave us control in the first place
    if ([elementName isEqual:@"channel"]) {
        [parser setDelegate:parentParserDelegate];
        [self trimItemTitles];
        [self collapseAllChildPosts]; // gold challenge ch26
    }
}

- (void)trimItemTitles
{
    // Create a regular expression with the pattern: Author
    NSRegularExpression *reg = [[NSRegularExpression alloc] initWithPattern:@"(.*) :: (?:Re: )?(.*) :: .*" options:0 error:nil];
    
    NSRegularExpression *shortReg = [[NSRegularExpression alloc] initWithPattern:@"(.*) :: (?:Re: )?(.*)" options:0 error:nil];
    
    for (RSSItem *i in items) {
        NSString *itemTitle = [i title];
        NSLog(@"Item %@", itemTitle);
        //Find the matches in the title string. the range
        // argument specifies how much of the title to search;
        // in this case, all of it
        NSArray *matches = [reg matchesInString:itemTitle options:0 range:NSMakeRange(0, [itemTitle length])];
        
        // find matches using truncated title
        if ([matches count] == 0) {
            matches = [shortReg matchesInString:itemTitle options:0 range:NSMakeRange(0, [itemTitle length])];
        }
        
        // If there was a match...
        if ([matches count] >0) {
            // Print the location of the match in the string and the string
            NSTextCheckingResult *result = [matches objectAtIndex:0];
            NSRange r = [result range];
            NSLog(@"Match at {%d, %d} for %@!", r.location, r.length, itemTitle);
            
            // One capture group, so two ranges, let's verify
            if ([result numberOfRanges] == 3) {
                // Pull out the 3rd range, which will be the 2nd capture group, the title
                NSRange r = [result rangeAtIndex:2];
                
                // Set the title of the item to the string within the capture group
                [i setTitle:[itemTitle substringWithRange:r]];
                
                // Pull out the 2nd range, which will be the 1st capture group, the subforum
                r = [result rangeAtIndex:1];
                
                // Set the title of the item to the string within the capture group
                [i setSubForum:[itemTitle substringWithRange:r]];
            }
            
            // gold challenge ch26 begin
            int currentIndex = [items indexOfObject:i];
            if (currentIndex > 0) {                 // skip the first object
                
                // previous item
                RSSItem *pi = [items objectAtIndex:currentIndex - 1];
                
                if ([[i title] isEqual:[pi title]]) {  // we found a child post
                    if ([pi isChild]) {             // the previous item is another child
                        [i setParentPostItem:[pi parentPostItem]];
                    } else {                        // the previous item is parent
                        [i setParentPostItem:pi];
                        [pi setParent:YES];         // set parent flag
                        [pi setChildrenVisible:YES];
                    }
                }
            }
            // gold challenge ch26 end
        }
    }
}

// Gold Challenge
- (void)showChildPosts:(RSSItem *)parent // gold challenge ch26
{
    NSLog(@"incoming parent:%@", parent);
    
    // get index to insert child posts
    int insertIndex = [items indexOfObject:parent] + 1;
    
    NSLog(@"checking hidden array (insert index set to:%d)", insertIndex);
    [parent setChildrenCount:0];
    for (int i = 0; i < [hiddenItems count];) {  // do not increment
        RSSItem *item = [hiddenItems objectAtIndex:i];
        NSLog(@"checking: %@", item);
        if ([item parentPostItem] == parent) {
            NSLog(@"\tfound a child! toggle to SHOW");
            [items insertObject:item atIndex:insertIndex];
            [hiddenItems removeObject:item];
            [parent setChildrenCount:[parent childrenCount] + 1];
            insertIndex++;
            NSLog(@"\tinsert index is:%d", insertIndex);
        } else {
            NSLog(@"not a child. next...");
            i++; // increment if not a child
        }
    }
    NSLog(@"finished");
    [parent setChildrenVisible:YES];
}
- (void)hideChildPosts:(RSSItem *)parent // gold challenge ch26
{
    NSLog(@"incoming parent:%@", parent);
    
    // get first child post index
    int childIndex = [items indexOfObject:parent] + 1;
    
    NSLog(@"checking items array starting at: %d", childIndex);
    [parent setChildrenCount:0];
    for (int i = childIndex; i < [items count];) { // do not increment
        RSSItem *child = [items objectAtIndex:i];
        NSLog(@"checking: %@", child);
        if ([child parentPostItem] == parent) {
            NSLog(@"\tfound a child! toggle to HIDE");
            [hiddenItems addObject:child];
            [items removeObject:child];
            [parent setChildrenCount:[parent childrenCount] + 1];
        } else {
            NSLog(@"no child. end search!");
            break; // stop searching
        }
    }
    NSLog(@"finished");
    [parent setChildrenVisible:NO];
}
- (void)collapseAllChildPosts // gold challenge ch26
{
    NSMutableArray *parents = [[NSMutableArray alloc] init];
    for (RSSItem *i in items) {
        NSLog(@"building parents array... checking: %@", i);
        if ([i isParent]) { // is a parent
            NSLog(@"\tis a parent!");
            [parents addObject:i];
        }
    }
    for (RSSItem *i in parents) {
        NSLog(@"collapsing parent: %@", i);
        [self hideChildPosts:i];
    }
}
// End Gold Challenge
@end






















