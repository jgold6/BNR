//
//  RSSItem.h
//  Nerdfeed
//
//  Created by Jonathan Goldberger on 2/23/14.
//  Copyright (c) 2014 Jonathan Goldberger. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface RSSItem : NSObject <NSXMLParserDelegate>
{
    NSMutableString *currentString;
}

@property (nonatomic, weak) id parentParserDelegate;

@property (nonatomic, strong) NSString *title;
@property (nonatomic, strong) NSString *link;
@property (nonatomic, strong) NSString *subForum;

// Gold Challene
@property (nonatomic, weak) id parentPostItem;
@property (nonatomic, getter = isParent) BOOL parent;
@property (nonatomic) BOOL childrenVisible;
@property (nonatomic) int childrenCount;
- (BOOL)isChild;
// End Gold challenge

@end
