//
//  Line.m
//  TouchTracker
//
//  Created by Jonathan Goldberger on 1/26/14.
//  Copyright (c) 2014 Jonathan Goldberger. All rights reserved.
//

#import "Line.h"

@implementation Line


@synthesize begin, end, color;

- (void)encodeWithCoder:(NSCoder *)aCoder
{
    [aCoder encodeFloat:begin.x forKey:@"beginx"];
    [aCoder encodeFloat:begin.y forKey:@"beginy"];
    [aCoder encodeFloat:end.x forKey:@"endx"];
    [aCoder encodeFloat:end.y forKey:@"endy"];
    [aCoder encodeObject:color forKey:@"color"];
}

- (id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super init];
    if (self) {
        [self setBegin:CGPointMake([aDecoder decodeFloatForKey:@"beginx"], [aDecoder decodeFloatForKey:@"beginy"])];
        [self setEnd:CGPointMake([aDecoder decodeFloatForKey:@"endx"], [aDecoder decodeFloatForKey:@"endy"])];
        [self setColor:[aDecoder decodeObjectForKey:@"color"]];
    }
    
    return self;
}

- (void)draw:(CGContextRef)context
{
    CGContextMoveToPoint(context, [self begin].x, [self begin].y);
    CGContextAddLineToPoint(context, [self end].x, [self end].y);
    
    [color set];
    
    CGContextStrokePath(context);
}

- (void)setColor
{
    float xDiff = self.end.x - self.begin.x;
    float yDiff = self.end.y - self.begin.y;
    float angle = atan2f(yDiff, xDiff) * (180 / M_PI);
    float red = ABS(angle)/180;
    float green = 1 - ABS(angle)/180;
    float blue = 0;
    if (ABS(angle) > 90)
        blue = (ABS(angle)-180)/-90;
    else
        blue = ABS(angle)/90;
    color = [UIColor colorWithRed:red green:green blue:blue alpha:1.0f];
}

- (void)setColor:(UIColor *)clr
{
    color = clr;
}

@end
