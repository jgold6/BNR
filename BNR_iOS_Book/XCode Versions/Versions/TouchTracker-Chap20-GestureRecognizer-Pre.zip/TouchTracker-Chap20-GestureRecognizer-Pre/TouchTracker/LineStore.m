//
//  LineStore.m
//  TouchTracker
//
//  Created by Jonathan Goldberger on 1/26/14.
//  Copyright (c) 2014 Jonathan Goldberger. All rights reserved.
//

#import "LineStore.h"
#import "Line.h"

@implementation LineStore

+ (LineStore *)sharedStore
{
    static LineStore *sharedStore = nil;
    if (!sharedStore)
        sharedStore = [[super allocWithZone:nil] init];
    return sharedStore;
}

- (id)init
{
    self = [super init];
    if (self) {
        NSString *path = [self lineArchivePath];
        completeLines = [NSKeyedUnarchiver unarchiveObjectWithFile:path];
        
        // If the array hadn't been saved previously, create a new empty one
        if (!completeLines) {
            completeLines = [[NSMutableArray alloc] init];
        }
    }
    return self;
}

+ (id)allocWithZone:(struct _NSZone *)zone
{
    return [self sharedStore];
}

- (NSArray *)completeLines
{
    return completeLines;
}

- (void)addCompletedLine:(Line *)line
{
    [completeLines addObject:line];
    int count = 0;
    for (Line *l in completeLines) {
        NSLog(@"Line %d: %@", ++count , l);
    }
}

- (void)removeCompletedLine:(Line *)line
{
    [completeLines removeObject:line];
}

- (void)clearShapes
{
    [completeLines removeAllObjects];
}

- (NSString *)lineArchivePath
{
    NSArray *documentDirectories = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    
    // Get one and only document directory from that list
    NSString *documentDirectory = [documentDirectories objectAtIndex:0];
    
    return [documentDirectory stringByAppendingPathComponent:@"lines.archive"];
}

- (BOOL)saveLines
{
    // Returns success or failure
    NSString *path = [self lineArchivePath];
    
    return [NSKeyedArchiver archiveRootObject:completeLines
                                       toFile:path];
}

@end
