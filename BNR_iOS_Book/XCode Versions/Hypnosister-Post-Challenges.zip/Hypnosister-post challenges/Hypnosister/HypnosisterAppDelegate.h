//
//  HypnosisterAppDelegate.h
//  Hypnosister
//
//  Created by Jonathan Goldberger on 11/23/13.
//  Copyright (c) 2013 Jonathan Goldberger. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HypnosisView.h"
#import "BNRLogo.h"

@interface HypnosisterAppDelegate : UIResponder <UIApplicationDelegate, UIScrollViewDelegate>
{
    HypnosisView *hView;
}

@property (strong, nonatomic) UIWindow *window;

@end
