//
//  BNRLogo.h
//  Hypnosister
//
//  Created by Jonathan Goldberger on 11/24/13.
//  Copyright (c) 2013 Jonathan Goldberger. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface BNRLogo : UIView

@property (nonatomic, strong) UIColor *circleColor;

@end
