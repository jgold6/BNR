//
//  BNRLogo.m
//  Hypnosister
//
//  Created by Jonathan Goldberger on 11/24/13.
//  Copyright (c) 2013 Jonathan Goldberger. All rights reserved.
//

#import "BNRLogo.h"

@implementation BNRLogo

@synthesize circleColor;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        [self setBackgroundColor:[UIColor clearColor]];
        // Sets the circle color
        //[self setCircleColor:[UIColor blackColor]];
    }
    return self;
}

- (void)setCircleColor:(UIColor *)clr
{
    circleColor = clr;
    [self setNeedsDisplay];
}

// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Set Image
    UIImage *image = [UIImage imageNamed:@"logo.png"];
    // Drawing code
    CGContextRef ctx = UIGraphicsGetCurrentContext(); //Context
    // bounds equals position and size of HypnosisView
    CGRect bounds = [self bounds]; // View Bounds
    // figure out the center of the bounds rectangle
    CGPoint center;
    center.x = bounds.origin.x + bounds.size.width / 2.0;
    center.y = bounds.origin.y + bounds.size.height / 2.0;
    // The radius of the circle should be nearly as big as the view
    float maxRadius = hypot(bounds.size.width, bounds.size.height) / 3.0;
    
    CGContextSaveGState(ctx);
    // Outline
    // The thickness of the line should be 1 points wide
    //CGContextSetLineWidth(ctx, 1); // Outline
    // Set stroke color - Outline
    //[[UIColor blackColor] setStroke]; // Outline
    // Add a path to the context - Outline
    CGContextAddArc(ctx, center.x, center.y, maxRadius, 0.0, M_PI * 2.0, YES); // Outline
    // Shadow
    // The shadow will move 0 points to the right and 3 points down from the text
    CGSize offset = CGSizeMake(0,1); // Shadow
    // The shadow will be dark gray in color
    CGColorRef shadowColor = [[UIColor blackColor] CGColor]; // Shadow
    // Set the shadow of the contezt with these parameters
    // all subsequent drawing will be shadowed
    CGContextSetShadowWithColor(ctx, offset, 2.0, shadowColor); // Shadow
    // Performs draw, removes path
    CGContextStrokePath(ctx); // Draw Outline and Shadow
    CGContextRestoreGState(ctx); // clears the shadow
    
    // Clip
    // Add a path to the context - clip
    CGContextAddArc(ctx, center.x, center.y, maxRadius, 0.0, M_PI * 2.0, YES); // Clip
    // Performs clip, removes path
    CGContextClip(ctx); // Clip
    
    // CLear Shadow
    //shadowColor = [[UIColor clearColor] CGColor]; // ClearShadow
    //CGContextSetShadowWithColor(ctx, CGSizeMake(0, 0), 0.0, shadowColor); // Clear Shadow
    
    [image drawInRect:bounds];
    CGColorSpaceRef colorSpaceRef = CGColorSpaceCreateDeviceRGB();
    CGFloat components[8] = {0.8, 0.8, 1, 1, 0.8, 0.8, 1, 0};
    CGFloat locations[2] = { 0.0, 1.0};
    CGGradientRef gradientRef = CGGradientCreateWithColorComponents(colorSpaceRef, components, locations, 2);
    CGContextDrawLinearGradient(ctx, gradientRef, CGPointMake(bounds.size.width / 2, 0), CGPointMake(bounds.size.width / 2, bounds.size.height / 2), 0);
    
    CGColorSpaceRelease(colorSpaceRef);
    CGGradientRelease(gradientRef);
    
    // Gradient
    // Add the path, rectangle of view
    //CGColorSpaceRef colorSpaceRef = CGColorSpaceCreateDeviceRGB();
    //CGFloat locations[] = { 0.0, 0.45, .75, 1.0};
    //CGColorRef startColor = [[UIColor colorWithRed:0.4 green:0.4 blue:1.0 alpha:1.0] CGColor];
    //CGColorRef midColor = [[UIColor whiteColor] CGColor];
    //CGColorRef midColor2 = [[UIColor whiteColor] CGColor];
    //CGColorRef endColor = [[UIColor magentaColor] CGColor];
    //NSArray *colors = @[(__bridge id)startColor, (__bridge id)midColor, (__bridge id)midColor2, (__bridge id)endColor];
    
    //CGGradientRef gradientRef = CGGradientCreateWithColors(colorSpaceRef, (__bridge CFArrayRef)colors, locations);
    //CGContextDrawLinearGradient(ctx, gradientRef, CGPointMake(50, 0), CGPointMake(50, 100), 0);
    
    // Draw Image
    //[image drawInRect:bounds blendMode:kCGBlendModeNormal alpha:0.5];
    
}


@end
