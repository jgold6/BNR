//
//  HypnosisView.m
//  Hypnosister
//
//  Created by Jonathan Goldberger on 11/23/13.
//  Copyright (c) 2013 Jonathan Goldberger. All rights reserved.
//

#import "HypnosisView.h"
#import "BNRLogo.h"

@implementation HypnosisView

@synthesize circleColor, crosshairColor;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // All HypnosisViews start with a clear background color
        [self setBackgroundColor:[UIColor clearColor]];
        // Sets the circle color
        [self setCircleColor:[UIColor lightGrayColor]];
    }
    return self;
}

- (void)setCircleColor:(UIColor *)clr
{
    circleColor = clr;
    [self setNeedsDisplay];
}

- (void)drawRect:(CGRect)dirtyRect
{
    // Get Graphics context
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    
    // bounds equals position and size of HypnosisView
    CGRect bounds = [self bounds];
    
    // figure out the center of the bounds rectangle
    CGPoint center;
    center.x = bounds.origin.x + bounds.size.width / 2.0;
    center.y = bounds.origin.y + bounds.size.height / 2.0;
    
    // The radius of the circle should be nearly as big as the view
    float maxRadius = hypot(bounds.size.width, bounds.size.height) / 2.0;
    
    // The thickness of the line should be 10 points wide
    CGContextSetLineWidth(ctx, 10);
    
    // Set stroke color
    [[self circleColor] setStroke];
    
    // The color of the line should be gray (rgb = 0.6, alpha = 1.0)
    //CGContextSetRGBStrokeColor(ctx, 0.6, 0.6, 0.6, 1.0);
    
    // Draw concentric circles from the outside in
    for (float currentRadius = maxRadius; currentRadius > 0; currentRadius -= 11) {
        // Add a path to the context
        CGContextAddArc(ctx, center.x, center.y, currentRadius, 0.0, M_PI * 2.0, YES);
        // Perfomr drawing instruction, removes path
        CGContextStrokePath(ctx);
//        if (currentRadius < maxRadius/2.0) {
//            [self setCircleColor:[UIColor redColor]];
//            [[self circleColor] setStroke];
//        }
        
    }
    
    // Create a string
    NSString *text = @"You are getting sleepy.";
    
    // Get a font to draw it in
    UIFont *font = [UIFont boldSystemFontOfSize:28];
    
    CGRect textRect;
    
    // How big is this string when drawn in the font?
    textRect.size = [text sizeWithFont:font];
    
    // Put that string  the center of the view
    textRect.origin.x = center.x - textRect.size.width / 2.0;
    textRect.origin.y = center.y - textRect.size.height / 2.0;
    
    // Set the fill color of the current context to white
    [[UIColor whiteColor] setFill];
    
    // The shadow will move 4 points to the right and 3 points down from the text
    CGSize offset = CGSizeMake(4,3);
    
    // The shadow will be dark gray in color
    CGColorRef color = [[UIColor blackColor] CGColor];
    
    // Set the shadow of the contezt with these parameters
    // all subsequent drawing will be shadowed
    CGContextSetShadowWithColor(ctx, offset, 2.0, color);
    
    // Draw the string
    [text drawInRect:textRect
            withFont:font];
    // Crosshairs
    CGContextSaveGState(ctx);
    CGSize offset2 = CGSizeMake(0, 0);
    CGColorRef color2 = [[UIColor clearColor] CGColor];
    [self setCrosshairColor:[UIColor greenColor]];
    [[self crosshairColor] setStroke];
    
    CGContextSetShadowWithColor(ctx, offset2, 0.0,color2);
    CGContextSetLineWidth(ctx, 7);
    CGContextMoveToPoint(ctx, center.x - 20, center.y);
    CGContextAddLineToPoint(ctx, center.x + 20, center.y);
    CGContextStrokePath(ctx);
    CGContextMoveToPoint(ctx, center.x, center.y - 20);
    CGContextAddLineToPoint(ctx, center.x, center.y + 20);
    CGContextStrokePath(ctx);
    CGContextRestoreGState(ctx);
}

- (BOOL)canBecomeFirstResponder
{
    return YES;
}

- (void)motionBegan:(UIEventSubtype)motion
          withEvent:(UIEvent *)event
{
    if (motion == UIEventSubtypeMotionShake)
    {
        NSLog(@"Device started shaking!");
        if ([self circleColor] == [UIColor lightGrayColor])
            [self setCircleColor:[UIColor redColor]];
        else
            [self setCircleColor:[UIColor lightGrayColor]];
    }
}

@end




















