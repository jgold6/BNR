//
//  HeavyViewController.m
//  HeavyRotation
//
//  Created by Jonathan Goldberger on 12/1/13.
//  Copyright (c) 2013 Jonathan Goldberger. All rights reserved.
//

#import "HeavyViewController.h"

@implementation HeavyViewController

- (void)viewDidLoad
{
    [slider setAutoresizingMask:(UIViewAutoresizingFlexibleBottomMargin | UIViewAutoresizingFlexibleWidth)];
    [imageView setAutoresizingMask:(UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth)];
    [btn1 setAutoresizingMask:(UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleTopMargin)];
    [btn2 setAutoresizingMask:(UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleTopMargin)];
    [btn3 setAutoresizingMask:(UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleBottomMargin | UIViewAutoresizingFlexibleRightMargin)];
}

- (void)willAnimateRotationToInterfaceOrientation:(UIInterfaceOrientation)x
                                         duration:(NSTimeInterval)duration
{
    CGRect bounds = [[self view] bounds];
    // If the orientation is rotating to Portrait Mode...
    if (UIInterfaceOrientationIsPortrait(x)) {
        // Put the button 3 on the left
        [btn3 setCenter:CGPointMake(30, bounds.size.height / 2)];
    }
    else {
        // Put the button 3 on the right
        [btn3 setCenter:CGPointMake(bounds.size.width-30, bounds.size.height / 2)];
    }
}

- (BOOL)shouldAutorotate
{
    return YES;
}

- (NSUInteger)supportedInterfaceOrientations
{
    NSUInteger ret = 0;
    NSString *curDeviceModel = [[UIDevice currentDevice] model];
    
    if ([curDeviceModel isEqualToString:@"iPhone Simulator"] || [curDeviceModel isEqualToString:@"iPhone"])
        ret =(UIInterfaceOrientationMaskLandscape | UIInterfaceOrientationMaskPortrait);
    else
        ret = (UIInterfaceOrientationMaskAll);
    return ret;
}

@end
