//
//  HeavyViewController.h
//  HeavyRotation
//
//  Created by Jonathan Goldberger on 12/1/13.
//  Copyright (c) 2013 Jonathan Goldberger. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HeavyViewController : UIViewController
{
    __weak IBOutlet UISlider *slider;
    __weak IBOutlet UIImageView *imageView;
    __weak IBOutlet UIButton *btn1;
    __weak IBOutlet UIButton *btn2;
    __weak IBOutlet UIButton *btn3;
}

@end
