//
//  Circle.h
//  TouchTracker
//
//  Created by Jonathan Goldberger on 2/1/14.
//  Copyright (c) 2014 Jonathan Goldberger. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Circle : NSObject <NSCoding>

@property (nonatomic) CGPoint circCenter;
@property (nonatomic) CGPoint point2;
@property (nonatomic) UIColor *color;

- (void)draw:(CGContextRef)context;
- (void)setColor;
- (void)setColor:(UIColor *)clr;

@end
