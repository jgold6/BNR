//
//  LineStore.h
//  TouchTracker
//
//  Created by Jonathan Goldberger on 1/26/14.
//  Copyright (c) 2014 Jonathan Goldberger. All rights reserved.
//

#import <Foundation/Foundation.h>

@class Line, Circle;

@interface LineStore : NSObject
{
    NSMutableArray *completeLines;
    NSMutableArray *completeCircles;
}

+ (LineStore *)sharedStore;

- (NSArray *)completeLines;
- (NSArray *)completeCircles;

- (void)addCompletedLine:(Line *)line;
- (void)addCompletedCircle:(Circle *)circle;
- (void)clearShapes;

- (NSString *)lineArchivePath;
- (BOOL)saveLines;

- (NSString *)circleArchivePath;
- (BOOL)saveCircles;

@end
