//
//  TouchDrawView.m
//  TouchTracker
//
//  Created by Jonathan Goldberger on 1/26/14.
//  Copyright (c) 2014 Jonathan Goldberger. All rights reserved.
//

#import "TouchDrawView.h"
#import "LineStore.h"
#import "Line.h"
#import "Circle.h"

@implementation TouchDrawView

- (id)initWithFrame:(CGRect)r
{
    self = [super initWithFrame:r];
    
    if (self) {
        linesInProcess = [[NSMutableDictionary alloc] init];
        circlesInProcess = [[NSMutableDictionary alloc] init];
        
        [self setBackgroundColor:[UIColor whiteColor]];
        
        [self setMultipleTouchEnabled:YES];
    }
    
    return self;
}

- (void)touchesBegan:(NSSet *)touches
           withEvent:(UIEvent *)event
{
    if ([[event touchesForView:self] count] == 2 && [linesInProcess count] < 1) {
        bool firstTouch = YES;
        Circle *newCircle = [[Circle alloc] init];
        NSValue *key;
        for (UITouch *t in touches) {
            // Is this a double tap?
            if ([t tapCount] > 1) {
                [self clearAll];
                return;
            }
            
            //Create a circle for the value
            CGPoint loc = [t locationInView:self];
            
            if (firstTouch) {
                // Use the touch object (packed in an NSValue) as the key
                key = [NSValue valueWithNonretainedObject:t];
                [newCircle setCircCenter:loc];
                firstTouch = NO;
            } else {
                [newCircle setPoint2:loc];
            }
        }
        // Put pair in dictionary
        [newCircle setColor];
        [circlesInProcess setObject:newCircle forKey:key];
    } else {
        for (UITouch *t in touches) {
            // Is this a double tap?
            if ([t tapCount] > 1) {
                [self clearAll];
                return;
            }
            
            // Use the touch object (packed in an NSValue) as the key
            NSValue *key = [NSValue valueWithNonretainedObject:t];
            
            //Create a line for the value
            CGPoint loc = [t locationInView:self];
            Line *newLine = [[Line alloc] init];
            [newLine setBegin:loc];
            [newLine setEnd:loc];
            [newLine setColor];
            
            // Put pair in dictionary
            [linesInProcess setObject:newLine forKey:key];
        }
    }
    // Redraw
    [self setNeedsDisplay];
}

- (void)touchesMoved:(NSSet *)touches
           withEvent:(UIEvent *)event
{
    if ([[event touchesForView:self] count] == 2 && [linesInProcess count] < 1) {
        bool firstTouch = YES;
        Circle *circle;
        NSValue *key;
        // Update circlesInProcess with moved touches
        for (UITouch *t in touches) {
            CGPoint loc = [t locationInView:self];
            if (firstTouch) {
                key = [NSValue valueWithNonretainedObject:t];
                // Find the circle for this touch
                circle = [circlesInProcess objectForKey:key];
                // Update the circle Center
                [circle setCircCenter:loc];
                firstTouch = NO;
            } else {
            // Update the circle outside
                [circle setPoint2:loc];
            }
        }
        [circle setColor];
        NSLog(@"x1 = %f, x2 = %f, y1 = %f, y2 = %f", circle.circCenter.x, circle.point2.x, circle.circCenter.y, circle.point2.y);
    } else {
        // Update linesInProcess with moved touches
        for (UITouch *t in touches) {
            NSValue *key = [NSValue valueWithNonretainedObject:t];
            
            // Find the line for this touch
            Line *line = [linesInProcess objectForKey:key];
            [line setColor];
            // Update the line
            CGPoint loc = [t locationInView:self];
            [line setEnd:loc];
            NSLog(@"x1 = %f, x2 = %f, y1 = %f, y2 = %f", line.begin.x, line.end.x, line.begin.y, line.end.y);
        }
    }
    // Redraw
    [self setNeedsDisplay];
}

- (void)touchesEnded:(NSSet *)touches
           withEvent:(UIEvent *)event
{
    [self endTouches:touches withEvent:event];
}

- (void)touchesCancelled:(NSSet *)touches
               withEvent:(UIEvent *)event
{
    [self endTouches:touches withEvent:event];
}

- (void)endTouches:(NSSet *)touches withEvent:(UIEvent *)event
{
    if ([linesInProcess count] < 1) {
        bool firstTouch = YES;
        Circle *circle;
        NSValue *key;
        // Remove ending touches from dictionary
        for (UITouch *t in touches) {
            if (firstTouch) {
                key = [NSValue valueWithNonretainedObject:t];
                // Find the circle for this touch
                circle = [circlesInProcess objectForKey:key];
                firstTouch = NO;
            }
        }
        if (circle) {
            [[LineStore sharedStore] addCompletedCircle:circle];
            [circlesInProcess removeObjectForKey:key ];
            NSLog(@"x1 = %f, x2 = %f, y1 = %f, y2 = %f", circle.circCenter.x, circle.point2.x, circle.circCenter.y, circle.point2.y);
        }
    } else {
        // Remove ending touches from dictionary
        for (UITouch *t in touches) {
            NSValue *key = [NSValue valueWithNonretainedObject:t];
            Line *line = [linesInProcess objectForKey:key];
            
            // If this is a double tap, "line" will be nil
            // so make sure not to add it to the array
            if (line) {
                [[LineStore sharedStore] addCompletedLine:line];
                [linesInProcess removeObjectForKey:key];
            }
        }
    }
    // Redraw
    [self setNeedsDisplay];
}

- (void)drawRect:(CGRect)rect
{
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetLineWidth(context, 10.0);
    CGContextSetLineCap(context, kCGLineCapRound);
    
    for (Line *line in [[LineStore sharedStore] completeLines]) {
        [line draw:context];
    }
    
    for (Circle *circle in [[LineStore sharedStore] completeCircles]) {
        [circle draw:context];
    }
    
    for (NSValue *v in linesInProcess) {
        Line *line = [linesInProcess objectForKey:v];
        [line draw:context];
    }
    
    for (NSValue *v in circlesInProcess) {
        Circle *circle = [circlesInProcess objectForKey:v];
        [circle draw:context];
    }

}

- (void)clearAll
{
    // Clear the collections
    [linesInProcess removeAllObjects];
    [circlesInProcess removeAllObjects];
    
    [[LineStore sharedStore] clearShapes];
    
    // Redraw
    [self setNeedsDisplay];
}

@end
































