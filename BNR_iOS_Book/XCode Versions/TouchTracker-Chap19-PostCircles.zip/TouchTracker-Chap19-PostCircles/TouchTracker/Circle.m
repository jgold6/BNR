//
//  Circle.m
//  TouchTracker
//
//  Created by Jonathan Goldberger on 2/1/14.
//  Copyright (c) 2014 Jonathan Goldberger. All rights reserved.
//

#import "Circle.h"

@implementation Circle

@synthesize circCenter, point2, color;

- (void)encodeWithCoder:(NSCoder *)aCoder
{
    [aCoder encodeFloat:circCenter.x forKey:@"centerx"];
    [aCoder encodeFloat:circCenter.y forKey:@"centery"];
    [aCoder encodeFloat:point2.x forKey:@"point2x"];
    [aCoder encodeFloat:point2.y forKey:@"point2y"];
    [aCoder encodeObject:color forKey:@"color"];
}

- (id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super init];
    if (self) {
        [self setCircCenter:CGPointMake([aDecoder decodeFloatForKey:@"centerx"], [aDecoder decodeFloatForKey:@"centery"])];
        [self setPoint2:CGPointMake([aDecoder decodeFloatForKey:@"point2x"], [aDecoder decodeFloatForKey:@"point2y"])];
        [self setColor:[aDecoder decodeObjectForKey:@"color"]];
    }
    
    return self;
}

- (void)draw:(CGContextRef)context
{
    float radius = hypotf(ABS(self.circCenter.x - self.point2.x)/2, ABS(self.circCenter.y - self.point2.y)/2);
    
    CGContextAddArc(context, self.circCenter.x, self.circCenter.y, radius, 0.0, M_PI * 2.0, YES);
    
    [color set];
    
    CGContextStrokePath(context);
}

- (void)setColor
{
    float xDiff = self.point2.x - self.circCenter.x;
    float yDiff = self.point2.y - self.circCenter.y;
    float angle = atan2f(yDiff, xDiff) * (180 / M_PI);
    NSLog(@"Angle = %f", angle);
    float red = ABS(angle)/180;
    float green = 1 - ABS(angle)/180;
    float blue = 0;
    if (ABS(angle) > 90)
        blue = (ABS(angle)-180)/-90;
    else
        blue = ABS(angle)/90;
    color = [UIColor colorWithRed:red green:green blue:blue alpha:1.0f];
}

- (void)setColor:(UIColor *)clr
{
    color = clr;
}

@end
