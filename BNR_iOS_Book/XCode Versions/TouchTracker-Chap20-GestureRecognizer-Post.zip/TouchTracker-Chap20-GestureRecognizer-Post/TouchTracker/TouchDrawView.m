//
//  TouchDrawView.m
//  TouchTracker
//
//  Created by Jonathan Goldberger on 1/26/14.
//  Copyright (c) 2014 Jonathan Goldberger. All rights reserved.
//

#import "TouchDrawView.h"
#import "LineStore.h"
#import "Line.h"

@implementation TouchDrawView

@synthesize selectedLine;

- (id)initWithFrame:(CGRect)r
{
    self = [super initWithFrame:r];
    
    if (self) {
        linesInProcess = [[NSMutableDictionary alloc] init];
        
        [self setBackgroundColor:[UIColor whiteColor]];
        
        [self setMultipleTouchEnabled:YES];
        
        UITapGestureRecognizer *tapRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tap:)];
        [self addGestureRecognizer:tapRecognizer];
        
        UITapGestureRecognizer *dblTapRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dblTap:)];
        [dblTapRecognizer setNumberOfTapsRequired:2];
        [self addGestureRecognizer:dblTapRecognizer];
        
        UILongPressGestureRecognizer *pressRecognizer = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(longPress:)];
        [self addGestureRecognizer:pressRecognizer];
        
        moveRecognizer = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(moveLine:)];
        [moveRecognizer setDelegate:self];
        [moveRecognizer setCancelsTouchesInView:NO];
        [self addGestureRecognizer:moveRecognizer];
        
        UISwipeGestureRecognizer *swipeRecognizer = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(swipe:)];
        [swipeRecognizer setDirection:UISwipeGestureRecognizerDirectionUp];
        [swipeRecognizer setNumberOfTouchesRequired:3];
        [self addGestureRecognizer:swipeRecognizer];
        
        selectedColor = [UIColor redColor];
    }
    return self;
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)other
{
    if (gestureRecognizer == moveRecognizer)
        return YES;
    return NO;
}

- (void)tap:(UIGestureRecognizer *)gr
{
    NSLog(@"Recognized tap");
    
    CGPoint point = [gr locationInView:self];
    [self setSelectedLine:[self lineAtPoint:point]];
    
    // If we just tapped, remove all lines in process so that a tap doesn't result in a new line
    [linesInProcess removeAllObjects];
    
    if ([self selectedLine]) {
        [self becomeFirstResponder];
        
        // Grab the menu controller
        UIMenuController *menu = [UIMenuController sharedMenuController];
        
        // Create a new "Delete" UIMienuItem
        UIMenuItem *deleteItem = [[UIMenuItem alloc] initWithTitle:@"Delete" action:@selector(deleteLine:)];
        [menu setMenuItems:[NSArray arrayWithObject:deleteItem]];
        
        // Tell the menu where it should come from and show it
        [menu setTargetRect:CGRectMake(point.x, point.y, 2, 2) inView:self];
        [menu setMenuVisible:YES animated:YES];
        NSArray *grs = [self gestureRecognizers];
        for (UIGestureRecognizer *gr in grs) {
            if ([gr class] != [UITapGestureRecognizer class]){
//                NSLog(@"GR Description: %@", [gr class]);
                gr.enabled = NO;
            }
        }
     } else {
        // Hide the menu if no line is selected
        [[UIMenuController sharedMenuController] setMenuVisible:NO animated:YES];
         NSArray *grs = [self gestureRecognizers];
         for (UIGestureRecognizer *gr in grs) {
             if ([gr class] != [UITapGestureRecognizer class]){
//                 NSLog(@"GR Description: %@", [gr class]);
                 gr.enabled = YES;
             }
         }
    }
    
    [self setNeedsDisplay];
}

- (void)dblTap:(UIGestureRecognizer *)gr
{
    [self clearAll];
    // Hide the menu
    [[UIMenuController sharedMenuController] setMenuVisible:NO animated:YES];
}

- (void)longPress:(UIGestureRecognizer *)gr
{
    if ([gr state] == UIGestureRecognizerStateBegan) {
        CGPoint point = [gr locationInView:self];
        [self setSelectedLine:[self lineAtPoint:point]];
        
        if ([self selectedLine]) {
            [linesInProcess removeAllObjects];
        }
    } else if ([gr state] == UIGestureRecognizerStateEnded) {
        [self setSelectedLine:nil];
    }
    [self setNeedsDisplay];
}

- (void)moveLine:(UIPanGestureRecognizer *)gr
{
    // If we haven't selected a line, we don't do anything here
    if (![self selectedLine]) {
        //NSLog(@"Velocity: %f, %f", [gr velocityInView:self].x, [gr velocityInView:self].y);
        return;
    }

    // When the pan recognizer changes its position...
    if ([gr state] == UIGestureRecognizerStateChanged) {
        // How far has the pan moved?
        CGPoint translation = [gr translationInView:self];
        
        // Add the translation to the current begin and end points of the line
        CGPoint begin = [[self selectedLine] begin];
        CGPoint end = [[self selectedLine] end];
        begin.x += translation.x;
        begin.y += translation.y;
        end.x += translation.x;
        end.y += translation.y;
        
        // Set the new beginning and end points of the line
        [[self selectedLine] setBegin:begin];
        [[self selectedLine] setEnd:end];
        
        [self setNeedsDisplay];
        
        [gr setTranslation:CGPointZero inView:self];
    } else if ([gr state] == UIGestureRecognizerStateEnded) {
        [self setSelectedLine:nil];
    }
}

- (void)swipe:(UIGestureRecognizer *)gr
{
    [linesInProcess removeAllObjects];
    NSLog(@"Three finger swipe sensed");
    [self becomeFirstResponder];
    // Grab the menu controller
    UIMenuController *menu = [UIMenuController sharedMenuController];
    
    // Create buttons
    UIMenuItem *red = [[UIMenuItem alloc] initWithTitle:@"Red" action:@selector(red:)];
    UIMenuItem *green = [[UIMenuItem alloc] initWithTitle:@"Green" action:@selector(green:)];
    UIMenuItem *blue = [[UIMenuItem alloc] initWithTitle:@"Blue" action:@selector(blue:)];

    NSArray *menuItems = [NSArray arrayWithObjects:red, green, blue, nil];
    
    [menu setMenuItems:menuItems];
    
    // Tell the menu where it should come from and show it
    [menu setTargetRect:CGRectMake(0, 0, [[UIScreen mainScreen] bounds].size.width, [[UIScreen mainScreen] bounds].size.height) inView:self];
    [menu setMenuVisible:YES animated:YES];
    
}

- (void)red:(id)sender
{
    selectedColor = [UIColor redColor];
}

- (void)green:(id)sender
{
    selectedColor = [UIColor greenColor];
}

- (void)blue:(id)sender
{
    selectedColor = [UIColor blueColor];
}

- (Line *)lineAtPoint:(CGPoint)p
{
    // Find a line close to p
    for (Line *l in [[LineStore sharedStore] completeLines]) {
        CGPoint start = [l begin];
        CGPoint end = [l end];
        
        // Check a few points on the line
        for (float t = 0.0; t <= 1.0; t += 0.05) {
            float x = start.x + t * (end.x - start.x);
            float y = start.y + t * (end.y - start.y);
            
            // if the tapped point is within 20 points, let's return this line
            if (hypot(x - p.x, y - p.y) < 20.0) {
                return l;
            }
        }
    }
    // If nothing is close enough, return nil
    return nil;
}

- (void)touchesBegan:(NSSet *)touches
           withEvent:(UIEvent *)event
{
    for (UITouch *t in touches) {
        // Use the touch object (packed in an NSValue) as the key
        NSValue *key = [NSValue valueWithNonretainedObject:t];
        
        //Create a line for the value
        CGPoint loc = [t locationInView:self];
        Line *newLine = [[Line alloc] init];
        [newLine setBegin:loc];
        [newLine setEnd:loc];
        //[newLine setColor]; // set color based on angle of line
        [newLine setColor:selectedColor];
        [newLine setLineWidth:30.0];
        [newLine setFastest:0.0];
        
        // Put pair in dictionary
        [linesInProcess setObject:newLine forKey:key];
    }
}

- (void)touchesMoved:(NSSet *)touches
           withEvent:(UIEvent *)event
{
    // Update linesInProcess with moved touches
    for (UITouch *t in touches) {
        NSValue *key = [NSValue valueWithNonretainedObject:t];
        
        // Find the line for this touch
        Line *line = [linesInProcess objectForKey:key];
        
        // Update the line
        CGPoint loc = [t locationInView:self];
        // but before we do se how much distance has changed since last update
        // and use to set the line width
        
        // Using velocity from moverecognizer
//        CGPoint drawVelocity = [moveRecognizer velocityInView:self];
//        drawVelocity.x = fabsf(drawVelocity.x);
//        drawVelocity.y = fabsf(drawVelocity.y);
//        
//        CGFloat drawSpeed = hypotf(drawVelocity.x, drawVelocity.y);
//        if (drawSpeed > line.fastest) {
//            line.fastest = (drawSpeed + line.fastest)/2;
//        }
//        
//        [line setLineWidth: MIN(1200/line.fastest, 30)];
        
        // Using the difference betseen the length of the line as an indicator of velocity - I like this better
        float oldLength = hypotf(line.begin.x - line.end.x, line.begin.y - line.end.y);
        float newLength = hypotf(line.begin.x - loc.x, line.begin.y - loc.y);
        //NSLog(@"length diff: %f", newLength - oldLength);
        if (ABS(newLength - oldLength) > line.fastest) {
            line.fastest = (ABS(newLength - oldLength) + line.fastest)/2;
        }
        [line setLineWidth: MIN(30/line.fastest, 20)];
        // OK back to our regularly scheduled programming
        [line setEnd:loc];
        //[line setColor]; // set color based on angle of line
    }
    // Redraw
    [self setNeedsDisplay];
}

- (void)touchesEnded:(NSSet *)touches
           withEvent:(UIEvent *)event
{
    [self endTouches:touches];
}

- (void)touchesCancelled:(NSSet *)touches
               withEvent:(UIEvent *)event
{
    [self endTouches:touches];
}

- (void)endTouches:(NSSet *)touches
{
    // Remove ending touches from dictionary
    for (UITouch *t in touches) {
        NSValue *key = [NSValue valueWithNonretainedObject:t];
        Line *line = [linesInProcess objectForKey:key];
        
        // If this is a double tap, "line" will be nil
        // so make sure not to add it to the array
        if (line) {
            [[LineStore sharedStore] addCompletedLine:line];
            [linesInProcess removeObjectForKey:key];
        }
    }
    // Redraw
    [self setNeedsDisplay];
}

- (void)drawRect:(CGRect)rect
{
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetLineCap(context, kCGLineCapRound);
    
    for (Line *line in [[LineStore sharedStore] completeLines]) {
        [line draw:context];
    }
    
    for (NSValue *v in linesInProcess) {
        Line *line = [linesInProcess objectForKey:v];
        [line draw:context];
    }
    
    // If there is a selected line, draw it
    if ([self selectedLine]) {
        [selectedLine draw:context withColor:[UIColor grayColor]];
    }
}

- (void)deleteLine:(id)sender
{
    // Remove the selected line from the list of completeLines
    [[LineStore sharedStore] removeCompletedLine:[self selectedLine]]; // because it is a weak reference, selectedLine is automatically set to nil
    
    NSArray *grs = [self gestureRecognizers];
    for (UIGestureRecognizer *gr in grs) {
        if ([gr class] != [UITapGestureRecognizer class]){
            //                 NSLog(@"GR Description: %@", [gr class]);
            gr.enabled = YES;
        }
    }
    
    [self setNeedsDisplay];
     
}

- (void)clearAll
{
    // Clear the collections
    [linesInProcess removeAllObjects];
    
    [[LineStore sharedStore] clearShapes];
    
    // Redraw
    [self setNeedsDisplay];
}

- (BOOL)canBecomeFirstResponder
{
    return YES;
}

@end

































