//
//  Line.h
//  TouchTracker
//
//  Created by Jonathan Goldberger on 1/26/14.
//  Copyright (c) 2014 Jonathan Goldberger. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Line : NSObject

@property (nonatomic) CGPoint begin;
@property (nonatomic) CGPoint end;
@property (nonatomic) UIColor *color;
@property (nonatomic) float lineWidth;
@property (nonatomic) float fastest;

- (void)draw:(CGContextRef)context;
- (void)draw:(CGContextRef)context withColor:(UIColor *)clr;
- (void)setColor;
- (void)setColor:(UIColor *)clr;

@end
