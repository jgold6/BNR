//
//  main.m
//  HypnoTime
//
//  Created by Jonathan Goldberger on 12/1/13.
//  Copyright (c) 2013 Jonathan Goldberger. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "HypnoAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([HypnoAppDelegate class]));
    }
}
