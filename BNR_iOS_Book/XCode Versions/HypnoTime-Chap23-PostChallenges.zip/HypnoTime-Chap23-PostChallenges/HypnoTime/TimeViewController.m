//
//  TimeViewController.m
//  HypnoTime
//
//  Created by Jonathan Goldberger on 12/1/13.
//  Copyright (c) 2013 Jonathan Goldberger. All rights reserved.
//

#import "TimeViewController.h"
#import <QuartzCore/QuartzCore.h>

@implementation TimeViewController

@synthesize showTimeButton;

- (id)initWithNibName:(NSString *)nibName bundle:(NSBundle *)bundle
{
    //self = [super initWithNibName:nil
    //                       bundle:nil];
    
    // Get a pointer to the application bundle object
    NSBundle *appBundle = [NSBundle mainBundle];
    
    self = [super initWithNibName:@"TimeViewController"
                           bundle:appBundle];
    
    if (self) {
        // Get the tab bar item
        UITabBarItem *tbi = [self tabBarItem];
        
        // Give it a label
        [tbi setTitle:@"Time"];
        
        // Create a UIImage from a file
        // this will use Hypno@2x.png on retina display devices
        UIImage *i = [UIImage imageNamed:@"Time.png"];
        
        // Put that image on the tab bar item
        [tbi setImage:i];
        
    }
    
    return self;
}

- (void)viewDidLoad
{
    // Always call the super implementation of viewDidLoad
    [super viewDidLoad];
    
    NSLog(@"TimeViewController loaded its view.");
}

- (void)viewWillAppear:(BOOL)animated
{
    NSLog(@"CurrentTimeViewController will appear");
    [super viewWillAppear:animated];
    [self showCurrentTime:nil];
}

- (void)viewDidAppear:(BOOL)animated
{
    [self slideButtonIn];
}

- (void)viewWillDisappear:(BOOL)animated
{
    NSLog(@"CurrentTimeViewController will DISappear");
    [super viewWillDisappear:animated];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    if([self isViewLoaded] && ![[self view] window]) {
        [self setView:nil];
    }
}

- (IBAction)showCurrentTime:(id)sender
{
    NSDate *now = [NSDate date];
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setTimeStyle:NSDateFormatterMediumStyle];
    
    [timeLabel setText:[formatter stringFromDate:now]];
    
    //[self spinTimeLabel];
    [self bounceTimeLabel];
}

- (void)spinTimeLabel
{
    // Create a basic animation
    CABasicAnimation *spin = [CABasicAnimation animationWithKeyPath:@"transform.rotation"];
    
    [spin setDelegate:self];
    
    // from value is implied
    [spin setToValue:[NSNumber numberWithFloat:M_PI * 2.0]];
    [spin setDuration:1.0];
    
    // Set the timing function
    CAMediaTimingFunction *tf = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    [spin setTimingFunction:tf];
    
    // Kick off the animation by adding it to the layer
    [[timeLabel layer] addAnimation:spin forKey:@"spinAnimation"];
}

- (void)bounceTimeLabel
{
    // Create a key frame animation
    CAKeyframeAnimation *bounce = [CAKeyframeAnimation animationWithKeyPath:@"transform"];
    CAKeyframeAnimation *fade = [CAKeyframeAnimation animationWithKeyPath:@"opacity"];
    
    [bounce setDelegate:self];
    [fade setDelegate:self];
    
    // Create the values it will pass through
    CATransform3D forward = CATransform3DMakeScale(1.3, 1.3, 1.0);
    CATransform3D back = CATransform3DMakeScale(0.7, 0.7, 1.0);
    CATransform3D forward2 = CATransform3DMakeScale(1.2, 1.2, 1.0);
    CATransform3D back2 = CATransform3DMakeScale(0.9, 0.9, 1.0);
    
    NSNumber *opacity0 = [NSNumber numberWithFloat:0.0];
    NSNumber *opacity1 = [NSNumber numberWithFloat:1.0];
    
    [bounce setValues:[NSArray arrayWithObjects:
                       [NSValue valueWithCATransform3D:CATransform3DIdentity],
                       [NSValue valueWithCATransform3D:forward],
                       [NSValue valueWithCATransform3D:back],
                       [NSValue valueWithCATransform3D:forward2],
                       [NSValue valueWithCATransform3D:back2],
                       [NSValue valueWithCATransform3D:CATransform3DIdentity],
                       nil]];
    
    [fade setValues:[NSArray arrayWithObjects:
                     [NSNumber numberWithFloat:[[timeLabel layer] opacity]],
                     opacity1,
                     opacity0,
                     opacity1,
                     opacity0,
                     [NSNumber numberWithFloat:[[timeLabel layer] opacity]],
                     nil]];

                     
    // Set the duration
    [bounce setDuration:5.0];
    [fade setDuration:5.0];
    
    // Animate the layer
    [[timeLabel layer] addAnimation:bounce forKey:@"bounceAnimation"];
    [[timeLabel layer] addAnimation:fade forKey:@"fadeAnimation"];
}

- (void)slideButtonIn
{
    CABasicAnimation *slide = [CABasicAnimation animationWithKeyPath:@"position"];
    
    [slide setDelegate:self];
    
    [slide setFromValue:[NSValue valueWithCGPoint:CGPointMake(-100.0, [[showTimeButton layer] position].y)]];
    [slide setToValue:[NSValue valueWithCGPoint:[[showTimeButton layer] position]]];
    [slide setDuration:1.0];
    
    // Set the timing function
    CAMediaTimingFunction *tf = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    [slide setTimingFunction:tf];
    [slide setValue:@"slideAnimation" forKey:@"animationId"]; // Used for check when animationDidStop is called, not need with completion block
    
    // Uncomment the following to use a completion block instead
//    [CATransaction begin]; {
//        [CATransaction setCompletionBlock:^{
//            CAKeyframeAnimation *fade = [CAKeyframeAnimation animationWithKeyPath:@"opacity"];
//            
//            NSNumber *opacity0 = [NSNumber numberWithFloat:0.0];
//            NSNumber *opacity1 = [NSNumber numberWithFloat:1.0];
//            [fade setValues:[NSArray arrayWithObjects:
//                             opacity1,
//                             opacity0,
//                             opacity1,
//                             nil]];
//            
//            [fade setDuration:1.0];
//            [fade setRepeatDuration:1000.0];
//            [fade setDelegate:self];
//            [[showTimeButton layer] addAnimation:fade forKey:@"fadeInOut"];
//        }];
        // Kick off the animation by adding it to the layer
        [[showTimeButton layer] addAnimation:slide forKey:@"slideAnimation"];
//    }
//    [CATransaction commit];
}

- (void)animationDidStop:(CAAnimation *)anim finished:(BOOL)flag
{
    NSLog(@"%@ finished: %d", anim, flag);
    if ([[anim valueForKey:@"animationId"] isEqual:@"slideAnimation"]) {
        CAKeyframeAnimation *fade = [CAKeyframeAnimation animationWithKeyPath:@"opacity"];
        
        NSNumber *opacity0 = [NSNumber numberWithFloat:0.0];
        NSNumber *opacity1 = [NSNumber numberWithFloat:1.0];
        [fade setValues:[NSArray arrayWithObjects:
                         opacity1,
                         opacity0,
                         opacity1,
                         nil]];
        
        [fade setDuration:1.0];
        [fade setRepeatDuration:1000.0];
        [fade setDelegate:self];
        [[showTimeButton layer] addAnimation:fade forKey:@"fadeInOut"];
    }
}

@end






























