//
//  main.m
//  Blocky
//
//  Created by Jonathan Goldberger on 3/9/14.
//  Copyright (c) 2014 Jonathan Goldberger. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "BlockyAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([BlockyAppDelegate class]));
    }
}
