//
//  BlockyAppDelegate.h
//  Blocky
//
//  Created by Jonathan Goldberger on 3/9/14.
//  Copyright (c) 2014 Jonathan Goldberger. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BlockyAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
