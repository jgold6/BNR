using System;
using System.Drawing;
using MonoTouch.Foundation;
using MonoTouch.UIKit;
using MonoTouch.CoreAnimation;
using System.Diagnostics;

namespace HypnoTime
{
	public partial class TimeViewController : UIViewController
	{
		public TimeViewController() : base("TimeViewController", null)
		{
			UITabBarItem tbi = this.TabBarItem;
			tbi.Title = "Time";

			UIImage i = UIImage.FromFile("Time.png");
			tbi.Image = i;
		}

		public override void DidReceiveMemoryWarning()
		{
			// Releases the view if it doesn't have a superview.
			base.DidReceiveMemoryWarning();
			// Release any cached data, images, etc that aren't in use.
		}

		public override void ViewDidLoad()
		{
			base.ViewDidLoad();
			// Perform any additional setup after loading the view, typically from a nib.

			btnShowTime.TouchUpInside += (sender, e) => {
				setCurrentTime();
			};


		}

		public override void ViewWillAppear(bool animated)
		{
			base.ViewWillAppear(animated);
			setCurrentTime();
		}

		public override void ViewWillDisappear(bool animated)
		{
			base.ViewWillDisappear(animated);
		}

		public void setCurrentTime()
		{
			NSDate now = DateTime.Now;
			NSDateFormatter dateFormat = new NSDateFormatter();
			dateFormat.TimeStyle = NSDateFormatterStyle.Medium;

			lblTime.Text = dateFormat.StringFor(now);

			//SpinTimeLabel();
			BounceTimeLabel();
		}

		public void SpinTimeLabel()
		{
			// Create a basic animation
			CABasicAnimation spin = CABasicAnimation.FromKeyPath("transform.rotation");

			spin.AnimationStopped += (object sender, CAAnimationStateEventArgs e) => {
				Debug.WriteLine("{0} finished {1}", sender, e.Finished);
			};

			// from value is implied
			spin.To = NSNumber.FromDouble(Math.PI * 2);
			spin.Duration = 0.6;

			//Set the timing function
			CAMediaTimingFunction tf = CAMediaTimingFunction.FromName(CAMediaTimingFunction.EaseInEaseOut);
			spin.TimingFunction = tf;

			// Kick off the animation by adding it to the layer
			lblTime.Layer.AddAnimation(spin, "spinAnimation");

		}

		public void BounceTimeLabel()
		{
			// Create a key frame animation
			CAKeyFrameAnimation bounce = CAKeyFrameAnimation.GetFromKeyPath("transform");

			bounce.AnimationStopped += (object sender, CAAnimationStateEventArgs e) => {
				Debug.WriteLine("{0} finished {1}", sender, e.Finished);
			};

			// Create the values it will pass through
			CATransform3D forward = CATransform3D.MakeScale(1.3f, 1.3f, 1.0f);
			CATransform3D back = CATransform3D.MakeScale(0.7f, 0.7f, 1.0f);
			CATransform3D forward2 = CATransform3D.MakeScale(1.2f, 1.2f, 1.0f);
			CATransform3D back2 = CATransform3D.MakeScale(0.9f, 0.9f, 1.0f);

			bounce.Values = new NSObject[] {
				NSValue.FromCATransform3D(CATransform3D.Identity), 
				NSValue.FromCATransform3D(forward), 
				NSValue.FromCATransform3D(back), 
				NSValue.FromCATransform3D(forward2), 
				NSValue.FromCATransform3D(back2), 
				NSValue.FromCATransform3D(CATransform3D.Identity)};

			// Set the duration
			bounce.Duration = 0.6f;

			// Animate the layer
			lblTime.Layer.AddAnimation(bounce, "bounceAnimation");
		}
	}
}



























