// WARNING
//
// This file has been generated automatically by Xamarin Studio to store outlets and
// actions made in the UI designer. If it is removed, they will be lost.
// Manual changes to this file may not be handled correctly.
//
using MonoTouch.Foundation;
using System.CodeDom.Compiler;

namespace Quiz
{
	[Register ("QuizViewController")]
	partial class QuizViewController
	{
		[Outlet]
		MonoTouch.UIKit.UILabel answerField { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel questionField { get; set; }

		[Action ("showAnswer:")]
		partial void showAnswer (MonoTouch.Foundation.NSObject sender);

		[Action ("showQuestion:")]
		partial void showQuestion (MonoTouch.Foundation.NSObject sender);
		
		void ReleaseDesignerOutlets ()
		{
			if (answerField != null) {
				answerField.Dispose ();
				answerField = null;
			}

			if (questionField != null) {
				questionField.Dispose ();
				questionField = null;
			}
		}
	}
}
