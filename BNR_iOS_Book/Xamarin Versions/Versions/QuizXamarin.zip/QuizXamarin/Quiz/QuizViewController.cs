using System;
using System.Drawing;
using MonoTouch.Foundation;
using MonoTouch.UIKit;
using System.Collections.Generic;

namespace Quiz
{
	public partial class QuizViewController : UIViewController
	{
		int currentQuestionIndex;

		// Model Objects
		List<string> questions;
		List<string> answers;

		public QuizViewController() : base("QuizViewController", null)
		{
			questions = new List<string>();
			answers = new List<string>();

			questions.Add("What is 7 + 7?");
			answers.Add("14");

			questions.Add("What is the capital of Vermont?");
			answers.Add("Montpelier");

			questions.Add("From what is cognac made?");
			answers.Add("Grapes");

		}

		partial void showQuestion(NSObject sender)
		{
			currentQuestionIndex++;

			if (currentQuestionIndex == questions.Count)
				currentQuestionIndex = 0;

			var question = questions[currentQuestionIndex];
			questionField.Text = question;
			answerField.Text = "???";
		}


		partial void showAnswer(NSObject sender)
		{
			var answer = answers[currentQuestionIndex];
			if (questionField.Text != "")
				answerField.Text = answer;
		}

		public override void DidReceiveMemoryWarning()
		{
			// Releases the view if it doesn't have a superview.
			base.DidReceiveMemoryWarning();
			
			// Release any cached data, images, etc that aren't in use.
		}

		public override void ViewDidLoad()
		{
			base.ViewDidLoad();
			
			// Perform any additional setup after loading the view, typically from a nib.
		}
	}
}

