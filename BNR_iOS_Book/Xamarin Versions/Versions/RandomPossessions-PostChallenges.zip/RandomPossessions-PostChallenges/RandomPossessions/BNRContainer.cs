using System;
using System.Collections.Generic;

namespace RandomPossessions
{
	public class BNRContainer : BNRItem
	{
		List<BNRItem> bnrItems;

		public BNRContainer()
		{
			bnrItems = new List<BNRItem>();
			itemName = "Container";
			valueInDollars = 0;
			serialNumber  = "";
		}

		public void addBNRItem(BNRItem item)
		{
			valueInDollars += item.valueInDollars;
			bnrItems.Add(item);
			item.container = this;

			if (item.container.container != null)
			{
				BNRContainer cont = new BNRContainer();
				cont = item.container.container as BNRContainer;
				cont.valueInDollars = cont.valueInDollars + item.valueInDollars;
			}
		}

		public void removeBNRItemAtIndex(int index)
		{
			var item = bnrItems[index];
			valueInDollars -= item.valueInDollars;

			if (item.container.container != null)
			{
				BNRContainer cont = new BNRContainer();
				cont = item.container.container as BNRContainer;
				cont.valueInDollars = cont.valueInDollars - item.valueInDollars;
			}

			bnrItems.RemoveAt(index);
		}

		public override string ToString()
		{
			string description = String.Format("\n{0} ({1}): Worth ${2}, recorded on {3}\n", itemName, serialNumber, valueInDollars, dateCreated);

			foreach (BNRItem item in bnrItems)
			{
				description += item.ToString();
				description += "\n";
			}

			return description;
		}
	}
}

