﻿using System;
using MonoTouch.UIKit;

namespace StoryTime
{
	[MonoTouch.Foundation.Register ("ModalViewController")]
	public partial class ModalViewController : UIViewController
	{
		public ModalViewController() : base()
		{
		}

		public ModalViewController(IntPtr ip) : base(ip)
		{
		}

		public override void ViewDidLoad()
		{
			base.ViewDidLoad();

			btnDismiss.TouchUpInside += (object sender, EventArgs e) => {
				this.PresentingViewController.DismissViewController(true, null);
			};
		}
	}
}

