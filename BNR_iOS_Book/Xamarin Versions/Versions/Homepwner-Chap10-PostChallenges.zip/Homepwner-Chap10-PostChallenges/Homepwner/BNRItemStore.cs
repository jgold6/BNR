using System;
using System.Drawing;
using MonoTouch.Foundation;
using System.Collections.Generic;

namespace Homepwner
{
	public static class BNRItemStore : object
	{
		public static List<BNRItem> allItems = new List<BNRItem>();

		public static BNRItem CreateItem()
		{
			BNRItem item = BNRItem.RandomBNRItem();
			allItems.Insert(0, item);
			return item;
		}

		public static void RemoveItem(BNRItem p)
		{
			allItems.Remove(p);
		}

		public static void moveItem(int fromIndex, int toIndex)
		{
			if (fromIndex == toIndex)
				return;
			BNRItem p = allItems[fromIndex];
			allItems.Remove(p);
			allItems.Insert(toIndex, p);
		}

		public static BNRItem AddItem(string name, int value, string sn)
		{
			BNRItem item;
			item = BNRItemStore.AddItemAtIndex(name, value, sn, 0);
			return item;
		}

		public static BNRItem AddItemAtIndex(string name, int value, string sn, int index)
		{
			BNRItem item = new BNRItem(name, value, sn);
			allItems.Insert((index < allItems.Count && index >= 0) ? index : 0, item);

			return item;
		}
	}
}

