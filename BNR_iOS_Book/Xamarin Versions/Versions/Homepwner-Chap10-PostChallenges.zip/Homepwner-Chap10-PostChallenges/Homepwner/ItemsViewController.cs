using System;
using System.Drawing;
using MonoTouch.Foundation;
using MonoTouch.UIKit;
using MonoTouch.ObjCRuntime;

namespace Homepwner
{
	public partial class ItemsViewController : UITableViewController, IUITableViewDataSource, IUITableViewDelegate
	{
		HeaderCell headerCell {get; set;}
//		UILabel footerCell {get; set;}

		public ItemsViewController() : base(null, null)
		{
			BNRItemStore.AddItem("No More Items!", 0, "");
			BNRItemStore.AddItem("Brian Moore i9f", 350, "");
			BNRItemStore.AddItem("Brian Moore i2", 400, "");
			BNRItemStore.AddItem("Fender Acoustic", 450, "");
		}

		public override void DidReceiveMemoryWarning()
		{
			// Releases the view if it doesn't have a superview.
			base.DidReceiveMemoryWarning();
			
			// Release any cached data, images, etc that aren't in use.
		}

		public override void ViewDidLoad()
		{
			base.ViewDidLoad();
			
			// Perform any additional setup after loading the view, typically from a nib.
			UIImage image = UIImage.FromBundle("tvBgImage.png");
			TableView.BackgroundView = new UIImageView(image);
		}

		public override string TitleForDeleteConfirmation(UITableView tableView, NSIndexPath indexPath)
		{
			return "Remove";
		}

		public override int RowsInSection(UITableView tableView, int section)
		{
			return BNRItemStore.allItems.Count;
		}

		public override UITableViewCell GetCell(UITableView tableView, NSIndexPath indexPath)
		{
			// Check for a reusable cell first, use that if it exists
			UITableViewCell cell = tableView.DequeueReusableCell("UITableViewCell");

			if (cell == null)
				// Create an instance of UITableViewCell, with default appearance
				cell = new UITableViewCell(UITableViewCellStyle.Subtitle,"UITableViewCell");

			// Set the text on the cell with the description of the item
			// that is the nth index of items, where n = row this cell
			// will appear in on the tableView
			BNRItem p = BNRItemStore.allItems[indexPath.Row];
			if (indexPath.Row == BNRItemStore.allItems.Count - 1) {
				cell.TextLabel.Text = String.Format("{0}", p.itemName);
				cell.DetailTextLabel.Text = "";
				cell.TextLabel.Font = UIFont.SystemFontOfSize(14);
				cell.BackgroundColor = UIColor.FromRGBA(0.9f, 0.9f, 1.0f, 0.75f);

			} else {
				cell.TextLabel.Text = String.Format("Item: {0}, ${1}", p.itemName, p.valueInDollars);
				cell.DetailTextLabel.Text = String.Format("SN: {0}, Added: {1}", p.serialNumber, p.dateCreated);
				cell.TextLabel.Font = UIFont.SystemFontOfSize(20);
				cell.BackgroundColor = UIColor.FromRGBA(1.0f, 1.0f, 1.0f, 0.5f);
			}

			return cell;
		}

		public override float GetHeightForHeader(UITableView tableView, int section)
		{
			if (headerCell == null)
			{
				headerCell = new HeaderCell();
				var views = NSBundle.MainBundle.LoadNib("HeaderView", headerCell, null);
				headerCell = Runtime.GetNSObject(views.ValueAt(0)) as HeaderCell;
			}
			return headerCell.Bounds.Size.Height;
		}

		public override UIView GetViewForHeader (UITableView tableView, int section)
		{
			headerCell.btnEdit.TouchUpInside += (sender, e) => {
				Console.WriteLine("BtnEdit pressed");
				var btn = sender as UIButton;
				if (this.Editing == true) {
					headerCell.btnAdd.Enabled = true;
					btn.SetTitle("Edit", UIControlState.Normal);
					this.SetEditing(false, true);
				} else {
					headerCell.btnAdd.Enabled = false;
					btn.SetTitle("Done", UIControlState.Normal);
					this.SetEditing(true, true);
				}
			};
			headerCell.btnAdd.TouchUpInside += (sender, e) => {
				Console.WriteLine("BtnAdd pressed");

				BNRItem newItem = BNRItemStore.CreateItem();

				int lastRow = BNRItemStore.allItems.IndexOf(newItem);

				NSIndexPath ip = NSIndexPath.FromRowSection(lastRow, 0);

				NSIndexPath[] indexPaths = new NSIndexPath[] {ip};
				TableView.InsertRows(indexPaths, UITableViewRowAnimation.Automatic);

				Console.WriteLine("allItems: {0}, tableViewRows: {1}", BNRItemStore.allItems.Count, tableView.NumberOfRowsInSection(section));

			};

			return headerCell;
		}

//		public override float GetHeightForFooter(UITableView tableView, int section)
//		{
//			if (footerCell == null)
//			{
//				footerCell = new UILabel();
//				footerCell.Bounds = new RectangleF(0, 0, footerCell.Bounds.Size.Width, 30);
//				footerCell.Text = "No More Items!";
//				footerCell.Font = UIFont.SystemFontOfSize(14);
//				footerCell.TextAlignment = UITextAlignment.Center;
//				footerCell.BackgroundColor = UIColor.FromRGBA(0.9f, 0.9f, 1.0f, 0.75f);
//			}
//			return footerCell.Bounds.Size.Height;
//		}
//
//		public override UIView GetViewForFooter (UITableView tableView, int section)
//		{
//			return footerCell;
//		}

		public override bool CanMoveRow(UITableView tableView, NSIndexPath indexPath)
		{
			if (indexPath.Row == BNRItemStore.allItems.Count - 1)
				return false;
			else
				return true;
		}

		public override bool CanEditRow(UITableView tableView, NSIndexPath indexPath)
		{
			if (indexPath.Row == BNRItemStore.allItems.Count - 1)
				return false;
			else
				return true;
		}

		public override NSIndexPath CustomizeMoveTarget(UITableView tableView, NSIndexPath sourceIndexPath, NSIndexPath proposedIndexPath)
		{
			if (proposedIndexPath.Row == BNRItemStore.allItems.Count -1) {
				return NSIndexPath.FromRowSection(proposedIndexPath.Row - 1, 0);
			}
			else
				return proposedIndexPath;
		}


		public override void MoveRow(UITableView tableView, NSIndexPath fromIndexPath, NSIndexPath toIndexPath)
		{
			Console.WriteLine("Item replaced: {0}", BNRItemStore.allItems[toIndexPath.Row].ToString());
			Console.WriteLine("Item Moved: {0}", BNRItemStore.allItems[fromIndexPath.Row].ToString());
			BNRItemStore.moveItem(fromIndexPath.Row, toIndexPath.Row);
			Console.WriteLine("Item Moved: {0}", BNRItemStore.allItems[toIndexPath.Row].ToString());
			Console.WriteLine("Item in Orginal spot: {0}", BNRItemStore.allItems[fromIndexPath.Row].ToString());
		}

		public override void CommitEditingStyle(UITableView tableView, UITableViewCellEditingStyle editingStyle, NSIndexPath indexPath)
		{
			if (editingStyle == UITableViewCellEditingStyle.Delete) {
				BNRItem itemToRemove = BNRItemStore.allItems[indexPath.Row];
				BNRItemStore.RemoveItem(itemToRemove);
				NSIndexPath[] indexPaths = new NSIndexPath[] {indexPath};
				TableView.DeleteRows(indexPaths, UITableViewRowAnimation.Automatic);
				Console.WriteLine("allItems: {0}, tableViewRows: {1}", BNRItemStore.allItems.Count, tableView.NumberOfRowsInSection(0));
			}
		}
	}
}



























