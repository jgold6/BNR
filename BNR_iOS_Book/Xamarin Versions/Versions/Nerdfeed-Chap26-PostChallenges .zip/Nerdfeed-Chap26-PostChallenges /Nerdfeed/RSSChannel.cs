﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Xml.Linq;
using System.Linq;
using MonoTouch.UIKit;
using System.Text.RegularExpressions;

namespace Nerdfeed
{
	public class RSSChannel
	{

		public string title {get; set;}
		public string description {get; set;}
		public string link {get; set;}
		public string lastBuildDate {get; set;}
		public string generator {get; set;}

		public List<RSSItem> items {get; set;}

		// Gold Challenge
		public List<RSSItem> hiddenItems {get; set;}
		// End Gold Challenge

		public RSSChannel()
		{
			items = new List<RSSItem>();
			hiddenItems = new List<RSSItem>(); // Gold Challenge
		}

		public async void FetchEntries(UITableView tableView)
		{
			using (var wc = new WebClient()) {
				string url = "http://forums.bignerdranch.com/smartfeed.php?limit=7_DAY&count_limit=100&sort_by=standard&feed_type=RSS2.0&feed_style=COMPACT"; //count_limit=100&
				try {
					string xmlData = await wc.DownloadStringTaskAsync(new Uri(url));
					//Console.WriteLine(xmlData);

					XDocument doc = XDocument.Parse(xmlData);

					var xChannel = doc.Descendants("channel");
					title = xChannel.ElementAt(0).Element("title").Value;
					description = xChannel.ElementAt(0).Element("description").Value;
					link = xChannel.ElementAt(0).Element("link").Value;
					lastBuildDate = xChannel.ElementAt(0).Element("lastBuildDate").Value;
					generator = xChannel.ElementAt(0).Element("generator").Value;

//					Console.WriteLine("\nChannel Title: {0}\nChannel Description: {1}\nChannel Link: {2}\nChannel BuildDate: {3}\nChannel Generator: {4}", 
//						title, 
//						description,
//						link,
//						lastBuildDate,
//						generator
//					);

					var allItems = doc.Descendants("item");

					int i = 0;
					foreach (XElement current in allItems) {
						RSSItem item = new RSSItem();

						Regex regex = new Regex("(.*) :: (?:Re: )?(.*) :: .*");
						var matches = regex.Split(current.Element("title").Value);
						if (matches.Length == 4) {
							item.title = matches[2];
							item.subForum = matches[1];
						} 
						else {
							regex = new Regex("(.*) :: R?e?:? ?(.*)");
							matches = regex.Split(current.Element("title").Value);
							item.title = matches[2];
							item.subForum = matches[1];
						}
						item.link = current.Element("link").Value;
						item.description = current.Element("description").Value;
						item.author = current.Element("author").Value;
						item.category = current.Element("category").Value;
						item.comments = current.Element("comments").Value;
						item.pubDate = current.Element("pubDate").Value;

						items.Add(item);

						int currentIndex = items.IndexOf(item);
						if (currentIndex > 0) { // Skip the first object

							// Previous item
							RSSItem pi = items[currentIndex - 1];

							if (item.title == pi.title) { // Found a child post
								if (pi.isChild()) { // Previoud item is a child, get its parent
									item.parentPostItem = pi.parentPostItem;
								} else {
									item.parentPostItem = pi;
									pi.isParent = true;
									pi.childrenVisible = true;
								}
							}
						}
//						Console.WriteLine("\n\tItem {0} Title: {1}\n\tDescription: {2}\n\tLink: {3}\n\tAuthor: {4}\n\tCategory: {5}\n\tComments: {6}\n\tPub Date: {7}", 
//							i,
//							items[i].title,
//							items[i].description,
//							items[i].link,
//							items[i].author,
//							items[i].category,
//							items[i].comments,
//							items[i].pubDate
//						);
						i++;
					}
					collapsedAllChildPosts(); // Gold Challenge

					tableView.ReloadData();
					// Version 1 of parsing XML document - can't seem to get array of nodes
					//					XmlReaderSettings set = new XmlReaderSettings();
					//					set.ConformanceLevel = ConformanceLevel.Fragment;
					//
					//					XPathDocument doc = new XPathDocument(XmlReader.Create(new StringReader(xmlData), set));
					//					XPathNavigator nav = doc.CreateNavigator();
					//
					//					channel.title = nav.SelectSingleNode("/rss/channel/title");
					//					channel.infoString = nav.SelectSingleNode("/rss/channel/description");
				}
				catch (WebException ex) {
					Console.WriteLine("Exception: {0}", ex.Message);
				}
			}

			// Alternate method - try/catch does not work
			//			string url = "http://forums.bignerdranch.com/smartfeed.php?limit=1_DAY&sort_by=standard&feed_type=RSS2.0&feed_style=COMPACT";
			//			try {
			//				client = new WebClient();
			//				client.DownloadStringCompleted += (object sender, DownloadStringCompletedEventArgs e) => {
			//					xmlData = e.Result;
			//					Console.WriteLine("Downloaded data: {0}", e.Result);
			//				};
			//				client.DownloadStringAsync(new Uri(url));
			//			}
			//			catch (WebException ex) {
			//				Console.WriteLine("Error: {0}", ex.Message);
			//			}
		}

		// Gold Challenge
		public void showChildPosts(RSSItem parent)
		{
			int insertIndex = items.IndexOf(parent) + 1;
			parent.childrenCount = 0;
			for (int i = 0; i < hiddenItems.Count;) { // Do not increment 
				RSSItem item = hiddenItems[i];
				if (item.parentPostItem == parent) {
					items.Insert(insertIndex,item);
					hiddenItems.Remove(item);
					parent.childrenCount++;
					insertIndex++;
				} else {
					i++;
				}
			}
			parent.childrenVisible = true;
		}

		public void hideChildPosts(RSSItem parent)
		{
			// get first child post index
			int childIndex = items.IndexOf(parent) + 1;
			parent.childrenCount = 0;
			for (int i = childIndex; i < items.Count;) {
				RSSItem child = items[i];
				if (child.parentPostItem == parent) {
					hiddenItems.Add(child);
					items.Remove(child);
					parent.childrenCount++;
				} else {
					break;
				}
			}
			parent.childrenVisible = false;
		}

		public void collapsedAllChildPosts()
		{
			List<RSSItem> parents = new List<RSSItem>();
			foreach (RSSItem i in items) {
				if (i.isParent) {
					parents.Add(i);
				}
			}
			foreach (RSSItem i in parents) {
				hideChildPosts(i);
			}
		}
		// End Gold Challenge
	}
}

