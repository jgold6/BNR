﻿using System;

namespace Nerdfeed
{
	public class RSSItem
	{
		public string title {get; set;}
		public string link {get; set;}
		public string description {get; set;}
		public string author {get; set;}
		public string category {get; set;}
		public string comments {get; set;}
		public string pubDate {get; set;}
		public string subForum {get; set;}

		public RSSItem()
		{
		}

		// Gold Challenge
		public RSSItem parentPostItem {get; set;}
		public bool isParent {get; set;}
		public bool childrenVisible {get; set;}
		public int childrenCount {get; set;}

		public bool isChild()
		{
			if (this.parentPostItem != null) {
				return true;
			} else {
				return false;
			}
		}
		// End Gold Challenge

	}
}

