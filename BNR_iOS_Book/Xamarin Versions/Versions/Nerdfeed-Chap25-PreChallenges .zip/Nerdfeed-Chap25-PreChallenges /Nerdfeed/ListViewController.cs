﻿using System;
using MonoTouch.UIKit;
using MonoTouch.Foundation;
using System.Net;
using System.IO;
using System.Xml;
using System.Xml.XPath;
using System.Xml.Linq;
using System.Linq;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace Nerdfeed
{
	public class ListViewController : UITableViewController
	{
		RSSChannel channel;
		//List<RSSItem> items;
		public WebViewController webViewController {get; set;}

		public ListViewController() : base(UITableViewStyle.Plain)
		{
		}

		public ListViewController(UITableViewStyle style) : base(style)
		{
			channel = new RSSChannel();
			//items = new List<RSSItem>();
			channel.FetchEntries(this.TableView);
		}

		public override int RowsInSection(UITableView tableView, int section)
		{
			if (channel.items.Count == 0)
				return 1;
			return channel.items.Count;
		}

		public override UITableViewCell GetCell(UITableView tableView, NSIndexPath indexPath )
		{
			UITableViewCell cell = tableView.DequeueReusableCell("UITableViewCell");
			if (cell == null) {
				cell = new UITableViewCell(UITableViewCellStyle.Default, "UITableViewCell");
			}
			if (channel.items.Count == 0) {
				cell.TextLabel.Text = "Loading last 20 posts from Big Nerd Ranch Forums...";
				cell.UserInteractionEnabled = false;
			}
			else {
				RSSItem item = channel.items[indexPath.Row];
				cell.TextLabel.Text = "Item #" + indexPath.Row +": " + item.title;
				cell.UserInteractionEnabled = true;
			}

			return cell;
		}

		public override void RowSelected(UITableView tableView, NSIndexPath indexPath)
		{
			// Push the web view controller onto the navigation stack
			// this implicitly creates the web view controller's view the first time through
			this.NavigationController.PushViewController(webViewController, true);

			// grab the selected item
			RSSItem entry = channel.items[indexPath.Row];

			// Load the webview with the entry link
			webViewController.webView.LoadRequest(new NSUrlRequest(new NSUrl(entry.link)));

			// Set the title of the web view controller's navigation item
			webViewController.NavigationItem.Title = entry.title;

		}

	}
}

