﻿using System;
using MonoTouch.UIKit;
using System.Drawing;

namespace Nerdfeed
{
	public class WebViewController : UIViewController
	{
		public UIWebView webView {get {return this.View as UIWebView;}}

		public WebViewController()
		{
		}

		public override void LoadView()
		{
			// Create an instance of UIWebview as large as the screen
			RectangleF screenFrame = UIScreen.MainScreen.ApplicationFrame;
			UIWebView wv = new UIWebView(screenFrame);
			wv.ScalesPageToFit = true;

			this.View = wv;
		}
	}
}

