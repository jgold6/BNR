using System;
using System.Collections.Generic;

namespace Homepwner
{
	public class BNRItem
	{
		public string itemName {get; set;}
		public string serialNumber {get; set;}
		public int valueInDollars {get; set;}
		public DateTime dateCreated {get; set;}
		public BNRItem container {get; set;}

		static Random random = new Random(0);

		public BNRItem(string name, int value, string serial)
		{
			itemName = name;
			serialNumber = serial;
			valueInDollars = value;
			dateCreated = DateTime.Now;
			container = null;

		}

		public BNRItem(string name, string serial) : this(name, 0, serial)
		{
		}

		public BNRItem(string name) : this(name, 0, "")
		{
		}

		public BNRItem() : this("Item", 0, "")
		{
		}

		public static BNRItem RandomBNRItem()
		{
			List<string> randAdjList = new List<string>();
			randAdjList.Add("Fluffy");
			randAdjList.Add("Rusty");
			randAdjList.Add("Shiny");

			List<string> randNounList = new List<string>();
			randNounList.Add("Bear");
			randNounList.Add("Spork");
			randNounList.Add("Mac");

			int adjIndex = random.Next(0, 3);
			int nounIndex = random.Next(0, 3);

			string randomName = String.Format("{0} {1}", randAdjList[adjIndex], randNounList[nounIndex]);

			int randomValue = random.Next(0, 100);

			string randomSerialNumber = String.Format("{0}{1}{2}{3}{4}", (char)('0' + random.Next(0,10)), (char)('A' + random.Next(0,10)), (char)('0' + random.Next(0,10)), (char)('A' + random.Next(0,10)), (char)('0' + random.Next(0,10)));

			return new BNRItem(randomName, randomValue, randomSerialNumber);
		}

		public override string ToString()
		{
			return String.Format("{0} ({1}): Worth ${2}, recorded on {3} {4}", itemName, serialNumber, valueInDollars, dateCreated.ToLongDateString(), dateCreated.ToLongTimeString());
		}
	}












}

