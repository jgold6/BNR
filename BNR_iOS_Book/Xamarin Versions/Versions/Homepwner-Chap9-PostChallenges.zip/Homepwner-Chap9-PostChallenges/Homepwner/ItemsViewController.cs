using System;
using System.Drawing;
using MonoTouch.Foundation;
using MonoTouch.UIKit;


namespace Homepwner
{
	public partial class ItemsViewController : UITableViewController, IUITableViewDataSource, IUITableViewDelegate
	{
		public ItemsViewController(UITableViewStyle style) : base(null, null)
		{
			BNRItemStore.AddItem("No More Items!", 0, "");
			for (int i = 0; i < 20; i++) {
				BNRItemStore.CreateItem();
			}
			BNRItemStore.AddItemAtIndex("MacBook Pro", 2000, "C02JC0SMDKQ2", 1);
		}

		public override void DidReceiveMemoryWarning()
		{
			// Releases the view if it doesn't have a superview.
			base.DidReceiveMemoryWarning();
			
			// Release any cached data, images, etc that aren't in use.
		}

		public override void ViewDidLoad()
		{
			base.ViewDidLoad();

			// Perform any additional setup after loading the view, typically from a nib.
			UIImageView imageView = new UIImageView(UIImage.FromFile("tvBgImage.png"));
			TableView.BackgroundView = imageView;
			TableView.SectionHeaderHeight = 60;


		}

		public override int NumberOfSections (UITableView tableView)
		{
			return 2;
		}

		public override int RowsInSection(UITableView tableView, int section)
		{
			if (section == 0)
				return BNRItemStore.expensiveItems.Count;
			else
				return BNRItemStore.cheapItems.Count;
		}

		public override string TitleForHeader(UITableView tableView, int section)
		{
			float totalValueExpensiveItems = 0;
			float totalValueCheapItems = 0;
			foreach (BNRItem item in BNRItemStore.expensiveItems)
				totalValueExpensiveItems += item.valueInDollars;
			foreach (BNRItem item in BNRItemStore.cheapItems)
				totalValueCheapItems += item.valueInDollars;
			if (section == 0)
				return String.Format("Expensive Items Total Value ${0}", totalValueExpensiveItems);
			else
				return String.Format("Cheap Items Total Value ${0}", totalValueCheapItems);
		}

//		public override string TitleForFooter(UITableView tableView, int section)
//		{
//			if (section == 0)
//				return "";
//			else
//				return "No More Items!";
//		}

		public override UITableViewCell GetCell(UITableView tableView, NSIndexPath indexPath)
		{

			// Check for a reusable cell first, use that if it exists
			UITableViewCell cell = tableView.DequeueReusableCell("UITableViewCell");

			if (cell == null)
				// Create an instance of UITableViewCell, with default appearance
				cell = new UITableViewCell(UITableViewCellStyle.Subtitle,"UITableViewCell");

			// Set the text on the cell with the description of the item
			// that is the nth index of items, where n = row this cell
			// will appear in on the tableView
			// check for section first
			BNRItem p;
			if (indexPath.Section == 0) {
				p = BNRItemStore.expensiveItems[indexPath.Row];
			} else {
				p = BNRItemStore.cheapItems[indexPath.Row];
			}

			cell.TextLabel.Text = String.Format("Item: {0}, ${1}", p.itemName, p.valueInDollars);
			cell.DetailTextLabel.Text = String.Format("SN: {0}, Added: {1}", p.serialNumber, p.dateCreated);
			cell.TextLabel.Font = UIFont.SystemFontOfSize(20);
			cell.BackgroundColor = UIColor.Clear;
			if (indexPath.Section == 1 && indexPath.Row == BNRItemStore.cheapItems.Count-1) {
				cell.TextLabel.Text = String.Format("{0}", p.itemName);
				cell.DetailTextLabel.Text = "";
				cell.TextLabel.Font = UIFont.SystemFontOfSize(10);
				cell.BackgroundColor = UIColor.FromRGBA(1.0f, 0.9f, 0.9f, 0.5f);
			}

			return cell;
		}
		public override float GetHeightForRow(UITableView tableView, NSIndexPath indexPath)
		{
			if (indexPath.Section != 1 || indexPath.Row != BNRItemStore.cheapItems.Count-1)
				return 60;
			else
				return 30;
		}
	}
}






































