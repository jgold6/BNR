using System;
using System.Drawing;
using MonoTouch.Foundation;
using System.Collections.Generic;

namespace Homepwner
{
	public static class BNRItemStore : object
	{
		public static List<BNRItem> expensiveItems = new List<BNRItem>();
		public static List<BNRItem> cheapItems = new List<BNRItem>();

		public static BNRItem CreateItem()
		{
			BNRItem p = BNRItem.RandomBNRItem();
			BNRItem item = BNRItemStore.AddItemAtIndex(p.itemName, p.valueInDollars, p.serialNumber, 0);
			return item;
		}

		public static BNRItem AddItem(string name, int value, string sn)
		{
			BNRItem item;
			item = BNRItemStore.AddItemAtIndex(name, value, sn, 0);
			return item;
		}

		public static BNRItem AddItemAtIndex(string name, int value, string sn, int index)
		{
			BNRItem item = new BNRItem(name, value, sn);
			if (item.valueInDollars > 50) {
				expensiveItems.Insert(((index <= expensiveItems.Count && index >= 0) ? index : 0), item);
			}
			else {
				cheapItems.Insert(((index < cheapItems.Count && index >= 0) ? index : 0), item);
			}
			return item;
		}
	}
}

