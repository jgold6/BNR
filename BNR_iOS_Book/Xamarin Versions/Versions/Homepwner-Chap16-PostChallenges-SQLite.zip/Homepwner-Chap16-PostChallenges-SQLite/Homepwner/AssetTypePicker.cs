using System;
using MonoTouch.UIKit;
using MonoTouch.Foundation;
using MonoTouch.ObjCRuntime;
using System.Collections.Generic;

namespace Homepwner
{
	public class AssetTypePicker : UITableViewController, IUITableViewDelegate, IUITableViewDataSource
	{
		public BNRItem item {get; set;}
		public UIPopoverController popoverController {get; set;}
		public DetailViewController controller {get; set;}
		public HeaderCell headerCell {get; set;}

		public AssetTypePicker() : base(UITableViewStyle.Plain)
		{
			UINavigationItem n = this.NavigationItem;
			n.Title = "Asset Types";

			// Create a new bar button item that will send
			// addNewItem to AssetTypePicker
			UIBarButtonItem bbi = new UIBarButtonItem(UIBarButtonSystemItem.Add, addNewItem);

			// Set this bar button item as the right item in the navigationItem
			n.RightBarButtonItem = bbi;
		}

		public override void ViewDidLoad()
		{
			base.ViewDidLoad();

			UIImage image = UIImage.FromBundle("tvBgImage.png");
			TableView.BackgroundView = new UIImageView(image);

		}

		void addNewItem(object sender, EventArgs e)
		{
			UIAlertView alert = new UIAlertView("Create an Asset Type", "Please enter a new asset type", null, "Done", null);
			alert.AlertViewStyle = UIAlertViewStyle.PlainTextInput;
			UITextField alerttextField = alert.GetTextField(0);
			alerttextField.KeyboardType = UIKeyboardType.Default;
			alerttextField.Placeholder = "Enter a new asset type";
			alert.Show();
			alert.Clicked += (object avSender, UIButtonEventArgs ave) => {
				Console.WriteLine("Entered: {0}", alert.GetTextField(0).Text);
				BNRItemStore.addAssetType(alert.GetTextField(0).Text);
				TableView.ReloadData();
				NSIndexPath ip = NSIndexPath.FromRowSection(BNRItemStore.allAssetTypes.Count-1, 0);
				this.RowSelected(TableView, ip);

			};
		}

		public override int NumberOfSections(UITableView tableView)
		{
			return 2;
		}

		public override int RowsInSection(UITableView tableView, int section)
		{
			int rows;
			if (section == 0)
				rows = BNRItemStore.allAssetTypes.Count;
			else {
				var assetTypeItems = getAssetTypeItems();
				rows = assetTypeItems.Count;
			}
			return rows;
		}

//		public override string TitleForHeader(UITableView tableView, int section)
//		{
//			if (section == 0)
//				return "Asset Types";
//			else
//				return String.Format("{0} items", item.assetType);
//		}

		public override float GetHeightForHeader(UITableView tableView, int section)
		{
			return 28.0f;
		}

		public override UIView GetViewForHeader(UITableView tableView, int section)
		{
				headerCell = new HeaderCell();
				var views = NSBundle.MainBundle.LoadNib("HeaderCell", headerCell, null);
				headerCell = Runtime.GetNSObject(views.ValueAt(0)) as HeaderCell;
				headerCell.BackgroundColor = UIColor.Clear;
			if (section == 0)
				headerCell.headerLabel.Text = String.Format("Asset type for {0}: {1}", item.itemName, item.assetType);
			else
				headerCell.headerLabel.Text = String.Format("All {0} items", item.assetType);
			return headerCell;
		}

		public override UITableViewCell GetCell(UITableView tableView, NSIndexPath indexPath)
		{
			UITableViewCell cell = TableView.DequeueReusableCell("UITableViewCell");
			if (cell == null) {
				cell = new UITableViewCell(UITableViewCellStyle.Default, "UITableViewCell");
			}

			if (indexPath.Section == 0) {
				var at = BNRItemStore.allAssetTypes[indexPath.Row];
				cell.TextLabel.Text = at.assetType;

				if (at.assetType == item.assetType)
					cell.Accessory = UITableViewCellAccessory.Checkmark;
				else
					cell.Accessory = UITableViewCellAccessory.None;
			}
			if (indexPath.Section == 1) {
				var assetTypeItems = getAssetTypeItems();
				var at = assetTypeItems[indexPath.Row];
				cell.TextLabel.Text = at.itemName;
				cell.Accessory = UITableViewCellAccessory.None;
				cell.SelectionStyle = UITableViewCellSelectionStyle.None;
			}
			return cell;
		}

		public override void RowSelected(UITableView tableView, NSIndexPath indexPath)
		{
			if (indexPath.Section == 0) {
				foreach (UITableViewCell c in tableView.VisibleCells)
					c.Accessory = UITableViewCellAccessory.None;

				UITableViewCell cell = TableView.CellAt(indexPath);

				cell.Accessory = UITableViewCellAccessory.Checkmark;

				var at = BNRItemStore.allAssetTypes[indexPath.Row];
				item.assetType = at.assetType;
				BNRItemStore.updateDBItem(item);
//				if (UIDevice.CurrentDevice.UserInterfaceIdiom == UIUserInterfaceIdiom.Pad) { // Bronze
//					controller.updateAssetType(); // Bronze
//					popoverController.Dismiss(true); // Bronze
//					popoverController = null; // Bronze
//				} else { // Bronze
				this.NavigationController.PopViewControllerAnimated(true);
//				} // Bronze
			}
		}

		public List<BNRItem> getAssetTypeItems()
		{
			List<BNRItem> assetTypeItems = new List<BNRItem>();
			var items = BNRItemStore.allItems;

			foreach (BNRItem i in items) {
				if (i.assetType == item.assetType) {
					assetTypeItems.Add(i);
				}
			}
			return assetTypeItems;
		}
	}
}

