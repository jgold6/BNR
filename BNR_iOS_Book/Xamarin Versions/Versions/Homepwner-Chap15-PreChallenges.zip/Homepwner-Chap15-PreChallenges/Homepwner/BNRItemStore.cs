using System;
using System.Drawing;
using MonoTouch.Foundation;
using System.Collections.Generic;
using System.IO;

namespace Homepwner
{
	public static class BNRItemStore : object
	{
		public static List<BNRItem> allItems = new List<BNRItem>();



		public static BNRItem CreateItem()
		{
			BNRItem p = BNRItem.RandomBNRItem();
			allItems.Insert(0, p);
			return p;
		}

		public static void loadItemsFromArchive()
		{
			string path = itemArchivePath();
			var unarchiver = (NSMutableArray)NSKeyedUnarchiver.UnarchiveFile(path);
			if (unarchiver != null) {
				for (int i = 0; i < unarchiver.Count; i++) {
					allItems.Add(unarchiver.GetItem<BNRItem>(i));
				}
			}
		}

		public static void RemoveItem(BNRItem p)
		{
			string key = p.imageKey;
			if (key != null)
				BNRImageStore.deleteImageForKey(key);

			allItems.Remove(p);
		}

		public static void moveItem(int fromIndex, int toIndex)
		{
			if (fromIndex == toIndex)
				return;
			BNRItem p = allItems[fromIndex];
			allItems.Remove(p);
			allItems.Insert(toIndex, p);
		}

		public static string itemArchivePath()
		{
			string[] documentDirectories = NSSearchPath.GetDirectories(NSSearchPathDirectory.DocumentDirectory, NSSearchPathDomain.User, true);

			// Get one and only document directory from that list
			string documentDirectory = documentDirectories[0];
			return Path.Combine(documentDirectory, "items.archive");
		}

		public static bool saveChanges()
		{
			// returns success or failure
			string path = itemArchivePath();
			NSMutableArray newArray = new NSMutableArray();
			foreach (BNRItem item in allItems) {
				newArray.Add(item);
			}
			return NSKeyedArchiver.ArchiveRootObjectToFile(newArray, path);
		}
	}
}

