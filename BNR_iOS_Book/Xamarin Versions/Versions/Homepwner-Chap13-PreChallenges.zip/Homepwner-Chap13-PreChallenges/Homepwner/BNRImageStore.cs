using System;
using System.Drawing;
using MonoTouch.Foundation;
using MonoTouch.UIKit;
using System.Collections.Generic;

namespace Homepwner
{
	public static class BNRImageStore : object
	{
		public static Dictionary<string, UIImage> dictionary = new Dictionary<string, UIImage>();

		public static void setImage(UIImage i, string s)
		{
			dictionary.Add(s, i);
		}

		public static UIImage imageForKey(string s)
		{
			UIImage image;
			if (dictionary.TryGetValue(s, out image)) {
				return image;
			} else {
				return null;
			}
		}

		public static void deleteImageForKey(string s)
		{
			if (s == "") {
				return;
			}
			dictionary.Remove(s);
		}
	}
}

