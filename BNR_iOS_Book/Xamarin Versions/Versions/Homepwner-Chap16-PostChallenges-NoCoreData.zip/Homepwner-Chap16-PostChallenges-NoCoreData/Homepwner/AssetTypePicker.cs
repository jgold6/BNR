using System;
using MonoTouch.UIKit;
using MonoTouch.Foundation;
using MonoTouch.ObjCRuntime;
using System.Collections.Generic;

namespace Homepwner
{
	public class AssetTypePicker : UITableViewController, IUITableViewDelegate, IUITableViewDataSource
	{
		public BNRItem item {get; set;}
		public UIPopoverController popoverController {get; set;}
		public DetailViewController controller {get; set;}

		public AssetTypePicker() : base(UITableViewStyle.Plain)
		{
			UINavigationItem n = this.NavigationItem;
			n.Title = "Asset Types";

			// Create a new bar button item that will send
			// addNewItem to AssetTypePicker
			UIBarButtonItem bbi = new UIBarButtonItem(UIBarButtonSystemItem.Add, addNewItem);

			// Set this bar button item as the right item in the navigationItem
			n.RightBarButtonItem = bbi;
		}

		void addNewItem(object sender, EventArgs e)
		{
			UIAlertView alert = new UIAlertView("Create an Asset Type", "Please enter a new asset type", null, "Done", null);
			alert.AlertViewStyle = UIAlertViewStyle.PlainTextInput;
			UITextField alerttextField = alert.GetTextField(0);
			alerttextField.KeyboardType = UIKeyboardType.Default;
			alerttextField.Placeholder = "Enter a new asset type";
			alert.Show();
			alert.Clicked += (object avSender, UIButtonEventArgs ave) => {
				Console.WriteLine("Entered: {0}", alert.GetTextField(0).Text);
				BNRItemStore.addAssetType(alert.GetTextField(0).Text);
				TableView.ReloadData();
				NSIndexPath ip = NSIndexPath.FromRowSection(BNRItemStore.allAssetTypes.Count-1, 0);
				this.RowSelected(TableView, ip);

			};
		}

		public override int NumberOfSections(UITableView tableView)
		{
			return 2;
		}

		public override int RowsInSection(UITableView tableView, int section)
		{
			int rows;
			if (section == 0)
				rows = BNRItemStore.allAssetTypes.Count;
			else {
				var assetTypeItems = getAssetTypeItems();
				rows = assetTypeItems.Count;
			}
			return rows;
		}

		public override string TitleForHeader(UITableView tableView, int section)
		{
			if (section == 0)
				return "Asset Types";
			else
				return "Items with this asset Type";
		}

		public override UITableViewCell GetCell(UITableView tableView, NSIndexPath indexPath)
		{
			UITableViewCell cell = TableView.DequeueReusableCell("UITableViewCell");
			if (cell == null) {
				cell = new UITableViewCell(UITableViewCellStyle.Default, "UITableViewCell");
			}

			if (indexPath.Section == 0) {
				var at = BNRItemStore.allAssetTypes[indexPath.Row];
				cell.TextLabel.Text = at.assetType;

				if (at.assetType == item.assetType)
					cell.Accessory = UITableViewCellAccessory.Checkmark;
				else
					cell.Accessory = UITableViewCellAccessory.None;
			}
			if (indexPath.Section == 1) {
				var assetTypeItems = getAssetTypeItems();
				var at = assetTypeItems[indexPath.Row];
				cell.TextLabel.Text = at.itemName;
			}
			return cell;
		}

		public override void RowSelected(UITableView tableView, NSIndexPath indexPath)
		{
			if (indexPath.Section == 0) {
				foreach (UITableViewCell c in tableView.VisibleCells)
					c.Accessory = UITableViewCellAccessory.None;

				UITableViewCell cell = TableView.CellAt(indexPath);

				cell.Accessory = UITableViewCellAccessory.Checkmark;

				var at = BNRItemStore.allAssetTypes[indexPath.Row];
				item.assetType = at.assetType;
//				if (UIDevice.CurrentDevice.UserInterfaceIdiom == UIUserInterfaceIdiom.Pad) {
//					controller.updateAssetType();
//					popoverController.Dismiss(true);
//					popoverController = null;
//				} else {
				this.NavigationController.PopViewControllerAnimated(true);
//				}
			}
		}

		public List<BNRItem> getAssetTypeItems()
		{
			List<BNRItem> assetTypeItems = new List<BNRItem>();
			var items = BNRItemStore.allItems;

			foreach (BNRItem i in items) {
				if (i.assetType == item.assetType) {
					assetTypeItems.Add(i);
				}
			}
			return assetTypeItems;
		}
	}
}

