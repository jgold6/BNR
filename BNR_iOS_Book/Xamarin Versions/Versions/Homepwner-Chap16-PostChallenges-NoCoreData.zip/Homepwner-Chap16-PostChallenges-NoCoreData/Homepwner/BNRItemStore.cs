using System;
using System.Drawing;
using MonoTouch.Foundation;
using System.Collections.Generic;
using System.IO;
using SQLite;

namespace Homepwner
{
	public static class BNRItemStore : object
	{
		public static List<BNRItem> allItems = new List<BNRItem>();
		public static List<BNRAssetType> allAssetTypes = new List<BNRAssetType>();


		public static BNRItem CreateItem()
		{
			BNRItem p = BNRItem.RandomBNRItem();
			allItems.Add(p);
			return p;
		}

		public static void loadItemsFromArchive()
		{
			string path = itemArchivePath();
			var unarchiver = (NSMutableArray)NSKeyedUnarchiver.UnarchiveFile(path);
			if (unarchiver != null) {
				for (int i = 0; i < unarchiver.Count; i++) {
					allItems.Add(unarchiver.GetItem<BNRItem>(i));
				}
			}

			string dbPath = GetDBPath();
			SQLiteConnection db;
			if (!File.Exists(dbPath)) {
				db = new SQLiteConnection(dbPath);
				db.CreateTable<BNRAssetType>();
				db.BeginTransaction();
				var at = new BNRAssetType();
				at.assetType = "Furniture";
				db.Insert(at);
				at.assetType = "Jewelry";
				db.Insert(at);
				at.assetType = "Electronics";
				db.Insert(at);
				db.Commit();
				db.Close();
				db = null;
			} 
			db = new SQLiteConnection(dbPath);
			allAssetTypes = db.Query<BNRAssetType>("SELECT * FROM BNRAssetTypes");
			foreach (BNRAssetType i in allAssetTypes)
				Console.WriteLine("AssetType: {0}", i.assetType);


//			string dbPath = itemArchivePath();
//			SQLiteConnection db;
//			if (!File.Exists(dbPath)) {
//				db = new SQLiteConnection(dbPath);
//				db.CreateTable<BNRItem>();
//				db.CreateTable<BNRAssetType>();
//				db.BeginTransaction();
//				db.Commit();
//			} else {
//				db = new SQLiteConnection(dbPath);
//				if (db.GetTableInfo("BNRItems") == null)
//					db.CreateTable<BNRItem>();
//				if (db.GetTableInfo("BNRAssetTypes") == null)
//					db.CreateTable<BNRAssetType>();
//				allItems = db.Query<BNRItem>("SELECT * FROM BNRItems ORDER BY orderingValue");
//				allAssetTypes = db.Query<BNRAssetType>("SELECT * FROM BNRAssetTypes");
//			}
//			db.Close();
		}

		public static void RemoveItem(BNRItem p)
		{
			string key = p.imageKey;
			if (key != null)
				BNRImageStore.deleteImageForKey(key);

			allItems.Remove(p);
		}

		public static void moveItem(int fromIndex, int toIndex)
		{
			if (fromIndex == toIndex)
				return;
			BNRItem p = allItems[fromIndex];
			allItems.Remove(p);
			allItems.Insert(toIndex, p);
		}

		public static string itemArchivePath()
		{
			string[] documentDirectories = NSSearchPath.GetDirectories(NSSearchPathDirectory.DocumentDirectory, NSSearchPathDomain.User, true);

			// Get one and only document directory from that list
			string documentDirectory = documentDirectories[0];
			return Path.Combine(documentDirectory, "items.archive");
		}

		public static string GetDBPath()
		{
			string[] documentDirectories = NSSearchPath.GetDirectories(NSSearchPathDirectory.DocumentDirectory, NSSearchPathDomain.User, true);

			// Get one and only document directory from that list
			string documentDirectory = documentDirectories[0];
			return Path.Combine(documentDirectory, "items.db");
		}

		public static bool saveChanges()
		{
			// Save to db
//			string dbPath = itemArchivePath();
//			var db = new SQLiteConnection(dbPath);
//			db.DeleteAll<BNRItem>();
//			db.DeleteAll<BNRAssetType>();
//			db.BeginTransaction();
//			db.InsertAll(allItems);
//			db.InsertAll(allAssetTypes);
//			db.Commit();
//			db.Close();
//			return true;

			// Archive method of saving
			// returns success or failure
			string path = itemArchivePath();
			NSMutableArray newArray = new NSMutableArray();
			foreach (BNRItem item in allItems) {
				newArray.Add(item);
			}
			return NSKeyedArchiver.ArchiveRootObjectToFile(newArray, path);
		}

		public static void addAssetType(string assetType)
		{
			string dbPath = GetDBPath();
			SQLiteConnection db;
			if (File.Exists(dbPath)) {
				db = new SQLiteConnection(dbPath);
				db.BeginTransaction();
				var at = new BNRAssetType();
				at.assetType = assetType;
				allAssetTypes.Add(at);
				db.Insert(at);
				db.Commit();
				db.Close();
				db = null;
			}
		}
	}
}

