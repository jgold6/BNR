using System;
using System.Collections.Generic;
using MonoTouch.Foundation;
using MonoTouch.UIKit;
using MonoTouch.CoreGraphics;
using System.Drawing;
using SQLite;

namespace Homepwner
{
	public class BNRItem : NSObject
	{
		public int ID {get; set;}
		public string imageKey {get; set;}
		public string itemName {get; set;}
		public string serialNumber {get; set;}
		public int valueInDollars {get; set;}
		public DateTime dateCreated {get; set;} // no sql
		UIImage thumbnail; // no sql move to image store
		public NSData thumbnailData {get; set;} // no sql move to image store
		//public double orderingValue {get; set;}
		public string assetType {get; set;}

		public UIImage Thumbnail()
		{
			// if there is no thumbnailData, then I have no thumbnail to return
			if (thumbnailData == null) {
				return null;
			}

			// If I have not yet created my thumbnail image from my data, do so now
			if (thumbnail == null) {
				// create the image form the data
				thumbnail = UIImage.LoadFromData(thumbnailData);
			}
			return thumbnail;
		}

		public void SetThumbnail(UIImage image)
		{
			thumbnail = image;
		}

		static Random random = new Random(0);

		public BNRItem(string name, int value, string serial)
		{
			itemName = name;
			serialNumber = serial;
			valueInDollars = value;
			dateCreated = DateTime.Now;
		}

		public BNRItem(string name, string serial) : this(name, 0, serial)
		{
		}

		public BNRItem(string name) : this(name, 0, "")
		{
		}

		public BNRItem() : this("Item", 0, "")
		{
		}

		public void setThumbnailDataFromImage(UIImage image)
		{
			SizeF origImageSize = image.Size;

			// The Rectangle of the thumbnail
			RectangleF newRect = new RectangleF(0, 0, 40, 40);

			// Figure out a scaling ration to make sure we maintain the same aspect ratio
			float ratio = Math.Max(newRect.Size.Width / origImageSize.Width, newRect.Size.Height / origImageSize.Height);

			// Create a transparent bitmap context with a scaling factor equal to that of the screen
			UIGraphics.BeginImageContextWithOptions(newRect.Size, false, 0.0f);

			// Create a path that is a rounded rectangle
			UIBezierPath path = UIBezierPath.FromRoundedRect(newRect, 5.0f);
			// Make all subsequent drawing clip to this rounded rectangle
			path.AddClip();

			// Center the image in the thumbnail rectangle
			RectangleF projectRect = new RectangleF();
			projectRect.Width = ratio * origImageSize.Width;
			projectRect.Height = ratio * origImageSize.Height;
			projectRect.X = (newRect.Size.Width - projectRect.Size.Width) / 2.0f;
			projectRect.Y = (newRect.Size.Height - projectRect.Size.Height) / 2.0f;

			// Draw the image to the context
			image.Draw(projectRect);

			// Get the image from the image context, keep it as our thumbnail
			UIImage smallImage = UIGraphics.GetImageFromCurrentImageContext();
			thumbnail = smallImage;

			// Get the PNG representation of the image and set it as our archivable data
			NSData data = smallImage.AsPNG();
			thumbnailData = data;

			// Clean up image context resources, we're done
			UIGraphics.EndImageContext();
		}

		//Archive method of saving data
		[Export("initWithCoder:")]
		public BNRItem(NSCoder decoder)
		{
			NSString str = (NSString)decoder.DecodeObject(@"itemName");
			if (str != null)
				this.itemName = str.ToString();
			str = (NSString)decoder.DecodeObject(@"serialNumber");
			if (str != null)
				this.serialNumber = str.ToString();
			str = (NSString)decoder.DecodeObject(@"imageKey");
			if (str != null)
				this.imageKey = str.ToString();
			this.valueInDollars = decoder.DecodeInt(@"valueInDollars");

			NSDate storedDate = (NSDate)decoder.DecodeObject(@"dateCreated");
			dateCreated = (DateTime)storedDate;

			thumbnailData = (NSData)decoder.DecodeObject("thumbnailData");
			str = (NSString)decoder.DecodeObject(@"assetType");
			if (str != null)
				this.assetType = str.ToString();
		}

		public override void EncodeTo (NSCoder coder)
		{
			if (this.itemName != null)
				coder.Encode(new NSString(this.itemName), "itemName");
			if (this.serialNumber != null)
				coder.Encode(new NSString(this.serialNumber), "serialNumber");
			coder.Encode(this.valueInDollars, "valueInDollars");
			NSDate date = new NSDate();
			date = dateCreated;
			coder.Encode(date, "dateCreated");
			if (this.imageKey != null)
				coder.Encode(new NSString(this.imageKey), "imageKey");
			if (thumbnailData != null)
				coder.Encode(thumbnailData, "thumbnailData");
			if (this.assetType != null)
				coder.Encode(new NSString(this.assetType), "assetType");
		}

		public static BNRItem RandomBNRItem()
		{
			List<string> randAdjList = new List<string>();
			randAdjList.Add("Fluffy");
			randAdjList.Add("Rusty");
			randAdjList.Add("Shiny");

			List<string> randNounList = new List<string>();
			randNounList.Add("Bear");
			randNounList.Add("Spork");
			randNounList.Add("Mac");

			int adjIndex = random.Next(0, 3);
			int nounIndex = random.Next(0, 3);

			string randomName = String.Format("{0} {1}", randAdjList[adjIndex], randNounList[nounIndex]);

			int randomValue = random.Next(0, 100);

			string randomSerialNumber = String.Format("{0}{1}{2}{3}{4}", (char)('0' + random.Next(0,10)), (char)('A' + random.Next(0,10)), (char)('0' + random.Next(0,10)), (char)('A' + random.Next(0,10)), (char)('0' + random.Next(0,10)));

			return new BNRItem(randomName, randomValue, randomSerialNumber);
		}

		public override string ToString()
		{
			return String.Format("{0} ({1}): Worth ${2}, recorded on {3} {4}", itemName, serialNumber, valueInDollars, dateCreated.ToLongDateString(), dateCreated.ToLongTimeString());
		}
	}
}



















