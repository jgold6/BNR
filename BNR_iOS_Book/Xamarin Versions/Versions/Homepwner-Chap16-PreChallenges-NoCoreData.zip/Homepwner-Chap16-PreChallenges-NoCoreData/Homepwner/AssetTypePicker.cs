using System;
using MonoTouch.UIKit;
using MonoTouch.Foundation;

namespace Homepwner
{
	public class AssetTypePicker : UITableViewController
	{
		public BNRItem item {get; set;}
		public UIPopoverController popoverController {get; set;}

		public AssetTypePicker() : base(UITableViewStyle.Grouped)
		{
			UINavigationItem n = this.NavigationItem;
			n.Title = "Asset Types";
		}

		public override int RowsInSection(UITableView tableView, int section)
		{
			return BNRItemStore.allAssetTypes.Count;
		}

		public override UITableViewCell GetCell(UITableView tableView, NSIndexPath indexPath)
		{
			UITableViewCell cell = TableView.DequeueReusableCell("UITableViewCell");
			if (cell == null) {
				cell = new UITableViewCell(UITableViewCellStyle.Default, "UITableViewCell");
			}

			var at = BNRItemStore.allAssetTypes[indexPath.Row];
			cell.TextLabel.Text = at.assetType;

			if (at.assetType == item.assetType)
				cell.Accessory = UITableViewCellAccessory.Checkmark;
			else
				cell.Accessory = UITableViewCellAccessory.None;

			return cell;
		}

		public override void RowSelected(UITableView tableView, NSIndexPath indexPath)
		{
			foreach (UITableViewCell c in tableView.VisibleCells)
				c.Accessory = UITableViewCellAccessory.None;

			UITableViewCell cell = TableView.CellAt(indexPath);

			cell.Accessory = UITableViewCellAccessory.Checkmark;

			var at = BNRItemStore.allAssetTypes[indexPath.Row];
			item.assetType = at.assetType;

				this.DismissViewController(true, null);

		}
	}
}

