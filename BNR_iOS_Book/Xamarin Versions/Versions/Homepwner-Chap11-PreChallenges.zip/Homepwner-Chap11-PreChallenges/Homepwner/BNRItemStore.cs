using System;
using System.Drawing;
using MonoTouch.Foundation;
using System.Collections.Generic;

namespace Homepwner
{
	public static class BNRItemStore : object
	{
		public static List<BNRItem> allItems = new List<BNRItem>();

		public static BNRItem CreateItem()
		{
			BNRItem p = BNRItem.RandomBNRItem();
			allItems.Insert(0, p);
			return p;
		}

		public static void RemoveItem(BNRItem p)
		{
			allItems.Remove(p);
		}

		public static void moveItem(int fromIndex, int toIndex)
		{
			if (fromIndex == toIndex)
				return;
			BNRItem p = allItems[fromIndex];
			allItems.Remove(p);
			allItems.Insert(toIndex, p);
		}
	}
}

