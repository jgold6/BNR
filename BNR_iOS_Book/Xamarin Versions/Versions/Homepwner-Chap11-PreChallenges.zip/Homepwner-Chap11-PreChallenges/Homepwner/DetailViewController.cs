using System;
using System.Drawing;
using MonoTouch.Foundation;
using MonoTouch.UIKit;

namespace Homepwner
{
	public partial class DetailViewController : UIViewController
	{
		BNRItem item;
		public BNRItem Item {
			get {
				return item;
			} 
			set {
				item = value;
				this.NavigationItem.Title = item.itemName;
			}
		}

		public DetailViewController() : base("DetailViewController", null)
		{
		}

		public override void DidReceiveMemoryWarning()
		{
			// Releases the view if it doesn't have a superview.
			base.DidReceiveMemoryWarning();
			
			// Release any cached data, images, etc that aren't in use.
		}

		public override void ViewDidLoad()
		{
			base.ViewDidLoad();

			// Perform any additional setup after loading the view, typically from a nib.
			this.View.BackgroundColor = UIColor.GroupTableViewBackgroundColor;
		}

		public override void ViewWillAppear(bool animated)
		{
			base.ViewWillAppear(animated);

			nameField.Text = item.itemName;
			serialNumberField.Text = item.serialNumber;
			valueField.Text = item.valueInDollars.ToString();
			dateLabel.Text = item.dateCreated.ToString();
		}

		public override void ViewWillDisappear(bool animated)
		{
			base.ViewWillDisappear(animated);

			// Clear first responder
			this.View.EndEditing(true);

			// "Save" changes to item
			item.itemName = nameField.Text;
			item.serialNumber = serialNumberField.Text;
			item.valueInDollars = Convert.ToInt32(valueField.Text);
		}
	}
}

