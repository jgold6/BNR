using System;
using System.Drawing;
using MonoTouch.Foundation;
using MonoTouch.UIKit;

namespace Homepwner
{
	public partial class ItemsViewController : UITableViewController, IUITableViewDataSource, IUITableViewDelegate
	{
		public ItemsViewController() : base(null, null)
		{
			for (int i = 0; i < 50; i++) {
				BNRItemStore.CreateItem();
			}
		}

		public override void DidReceiveMemoryWarning()
		{
			// Releases the view if it doesn't have a superview.
			base.DidReceiveMemoryWarning();
			
			// Release any cached data, images, etc that aren't in use.
		}

		public override void ViewDidLoad()
		{
			base.ViewDidLoad();
			
			// Perform any additional setup after loading the view, typically from a nib.
		}

		public override int RowsInSection(UITableView tableView, int section)
		{
			return BNRItemStore.allItems.Count;
		}

		public override UITableViewCell GetCell(UITableView tableView, NSIndexPath indexPath)
		{
			// Check for a reusable cell first, use that if it exists
			UITableViewCell cell = tableView.DequeueReusableCell("UITableViewCell");

			if (cell == null)
				// Create an instance of UITableViewCell, with default appearance
				cell = new UITableViewCell(UITableViewCellStyle.Subtitle,"UITableViewCell");

			// Set the text on the cell with the description of the item
			// that is the nth index of items, where n = row this cell
			// will appear in on the tableView
			BNRItem p = BNRItemStore.allItems[indexPath.Row];

			cell.TextLabel.Text = String.Format("Item: {0}, ${1}", p.itemName, p.valueInDollars);
			cell.DetailTextLabel.Text = String.Format("SN: {0}, Added: {1}", p.serialNumber, p.dateCreated);

			return cell;
		}
	}
}

