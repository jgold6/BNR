using System;
using System.Drawing;
using MonoTouch.Foundation;
using System.Collections.Generic;

namespace Homepwner
{
	public static class BNRItemStore : object
	{
		public static List<BNRItem> allItems = new List<BNRItem>();

		public static BNRItem CreateItem()
		{
			BNRItem p = BNRItem.RandomBNRItem();
			allItems.Add(p);
			return p;
		}


	}
}

