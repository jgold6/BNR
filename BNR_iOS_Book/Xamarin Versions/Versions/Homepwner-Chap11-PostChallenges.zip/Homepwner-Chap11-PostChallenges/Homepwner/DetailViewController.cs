using System;
using System.Drawing;
using MonoTouch.Foundation;
using MonoTouch.UIKit;

namespace Homepwner
{
	public partial class DetailViewController : UIViewController, IUITextFieldDelegate
	{
		UIAlertView av;
		UIView dpSuperView;
		UIDatePicker dp;
		UIViewController dpvc;

		BNRItem item;

		public BNRItem Item {
			get {
				return item;
			} 
			set {
				item = value;
				this.NavigationItem.Title = item.itemName;
			}
		}

		public DetailViewController() : base("DetailViewController", null)
		{

		}

		public override void DidReceiveMemoryWarning()
		{
			// Releases the view if it doesn't have a superview.
			base.DidReceiveMemoryWarning();
			
			// Release any cached data, images, etc that aren't in use.
		}

		public override void ViewDidLoad()
		{
			base.ViewDidLoad();

			// Perform any additional setup after loading the view, typically from a nib.
			this.View.BackgroundColor = UIColor.GroupTableViewBackgroundColor;

			changeDate.TouchUpInside += (sender, e)  => {
				av.Show();
			};

			dpSuperView = new UIView(this.View.Frame);
			dpSuperView.BackgroundColor = UIColor.White;
			dp = new UIDatePicker();
			dp.Mode = UIDatePickerMode.Date;
			dpSuperView.Add(dp);
			dpvc = new UIViewController();
			dpvc.View = dpSuperView;
			dpvc.EdgesForExtendedLayout = UIRectEdge.None;

			av = new UIAlertView("Do you really want to change the date?", "Modifying the date of an acquired item can result in charges of insurance fraud.", null, "This is correcting an error.", null);
			av.Clicked += (object sender, UIButtonEventArgs e) => {
				dp.Date = item.dateCreated;
				NavigationController.PushViewController(dpvc, true);
			};
			dp.ValueChanged += (object sender, EventArgs e) => {
				DateTime newDate = dp.Date;
				Console.WriteLine("test dp: " +  newDate.ToLocalTime());
				item.dateCreated = newDate.ToLocalTime();
			};
			nameField.EditingChanged += (object sender, EventArgs e) => {
				this.NavigationItem.Title = nameField.Text;
			};

		}

		public override void ViewWillAppear(bool animated)
		{
			base.ViewWillAppear(animated);

			nameField.Text = item.itemName;
			serialNumberField.Text = item.serialNumber;
			valueField.Text = item.valueInDollars.ToString();
			dateLabel.Text = item.dateCreated.ToString();

			nameField.ShouldReturn += ((textField) => {
				textField.ResignFirstResponder();
				return true;
			});

			serialNumberField.ShouldReturn += ((textField) => {
				textField.ResignFirstResponder();
				return true;
			});
		}

		partial void backgroundTapped (MonoTouch.Foundation.NSObject sender)
		{
			this.View.EndEditing(true);
		}

		public override void ViewWillDisappear(bool animated)
		{
			base.ViewWillDisappear(animated);
			// Clear first responder
			this.View.EndEditing(true);

			// "Save" changes to item
			item.itemName = nameField.Text;
			item.serialNumber = serialNumberField.Text;
			item.valueInDollars = (valueField.Text != "" ? Convert.ToInt32(valueField.Text) : 0);
		}
	}
}

