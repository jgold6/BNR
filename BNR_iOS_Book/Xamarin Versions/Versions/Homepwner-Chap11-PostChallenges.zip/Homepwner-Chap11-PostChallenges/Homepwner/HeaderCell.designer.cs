// WARNING
//
// This file has been generated automatically by Xamarin Studio to store outlets and
// actions made in the UI designer. If it is removed, they will be lost.
// Manual changes to this file may not be handled correctly.
//
using MonoTouch.Foundation;
using System.CodeDom.Compiler;

namespace Homepwner
{
	partial class HeaderCell
	{
		[Outlet]
		public MonoTouch.UIKit.UIButton btnAdd { get; set; }

		[Outlet]
		public MonoTouch.UIKit.UIButton btnEdit { get; set; }
		
		void ReleaseDesignerOutlets ()
		{
			if (btnEdit != null) {
				btnEdit.Dispose ();
				btnEdit = null;
			}

			if (btnAdd != null) {
				btnAdd.Dispose ();
				btnAdd = null;
			}
		}
	}
}
