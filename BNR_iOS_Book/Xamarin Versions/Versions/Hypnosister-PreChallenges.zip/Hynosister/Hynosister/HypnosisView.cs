using System;
using System.Drawing;
using MonoTouch.UIKit;
using MonoTouch.CoreGraphics;
using MonoTouch.Foundation;

namespace Hynosister
{
	public class HypnosisView : UIView
	{
		UIColor circleColor;


		public UIColor CircleColor
		{
			get {return circleColor;}
			set {circleColor = value; SetNeedsDisplay();}
		}

		public HypnosisView() : this(new RectangleF(UIScreen.MainScreen.Bounds.Location.X,UIScreen.MainScreen.Bounds.Location.Y, UIScreen.MainScreen.Bounds.Size.Width, UIScreen.MainScreen.Bounds.Height))
		{

		}

		public HypnosisView(RectangleF frame)
		{
			Frame = frame;
			BackgroundColor = UIColor.Clear;
			circleColor = UIColor.LightGray;
		}

		public override void Draw(RectangleF rect)
		{
			base.Draw(rect);
	
			// Get current drawing context
			CGContext ctx = UIGraphics.GetCurrentContext(); 
			// Get bounds of view
			RectangleF bounds = this.Bounds;

			// Figure out the center of the bounds rectangle
			PointF center = new Point();
			center.X = (float)(bounds.Location.X + bounds.Size.Width / 2.0);
			center.Y = (float)(bounds.Location.Y + bounds.Size.Height / 2.0);

			// The radius of the circle shiuld be nearly as big as the View.
			float maxRadius = (float)Math.Sqrt(Math.Pow(bounds.Size.Width,2) + Math.Pow(bounds.Size.Height,2)) / 2.0f;

			// The thickness of the line should be 10 points wide
			ctx.SetLineWidth(10);

			// The color of the line should be grey
			//ctx.SetRGBStrokeColor(0.6f, 0.6f, 0.6f, 1.0f);
			//UIColor.FromRGB(0.6f, 0.6f, 0.6f).SetStroke();
			//UIColor.FromRGBA(0.6f, 0.6f, 0.6f, 1.0f).SetStroke();
			circleColor.SetStroke();

			// Add a shape to the context
			//ctx.AddArc(center.X, center.Y, maxRadius, 0, (float)(Math.PI * 2), true);

			// Perform the drawing operation - draw current shape with current state
			//ctx.DrawPath(CGPathDrawingMode.Stroke);

			// Draw concentric circles from the outside in
			for (float currentRadius = maxRadius; currentRadius > 0; currentRadius -= 20) {
				ctx.AddArc(center.X, center.Y, currentRadius, 0, (float)(Math.PI * 2), true);
				ctx.DrawPath(CGPathDrawingMode.Stroke);
			}

			// Create a string
			NSString text = new NSString("You are getting sleepy");

			// Get a font to draw it in
			UIFont font = UIFont.BoldSystemFontOfSize(28);

			RectangleF textRect = new RectangleF();

			// How big is the string when drawn in this font?
			//textRect.Size = text.StringSize(font);
			UIStringAttributes attribs = new UIStringAttributes {Font = font};
			textRect.Size = text.GetSizeUsingAttributes(attribs);

			// Put the string in the center
			textRect.X = (float)(center.X - textRect.Size.Width / 2.0);
			textRect.Y = (float)(center.Y - textRect.Size.Height / 2.0);

			// Set the fill color of the current context to black
			UIColor.Black.SetFill();

			// Shadow
			SizeF offset = new SizeF(4, 3);
			CGColor color = new CGColor(0.2f, 0.2f, 0.2f, 1f);

			ctx.SetShadowWithColor(offset, 2.0f, color);

			// Draw the string
			text.DrawString(textRect, font); 
		}

		public override bool CanBecomeFirstResponder{ get {return true;}}

		public override void MotionBegan(UIEventSubtype motion, UIEvent evt)
		{
			if (motion == UIEventSubtype.MotionShake) {
				Console.WriteLine("Device started shaking");
				if (CircleColor != UIColor.Red)
					CircleColor = UIColor.Red;
				else
					CircleColor = UIColor.LightGray;
			}
		}
	}
}












































