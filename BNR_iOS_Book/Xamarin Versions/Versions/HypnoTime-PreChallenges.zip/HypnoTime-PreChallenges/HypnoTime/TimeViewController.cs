using System;
using System.Drawing;
using MonoTouch.Foundation;
using MonoTouch.UIKit;

namespace HypnoTime
{
	public partial class TimeViewController : UIViewController
	{
		public TimeViewController() : base("TimeViewController", null)
		{
			UITabBarItem tbi = this.TabBarItem;
			tbi.Title = "Time";

			UIImage i = UIImage.FromFile("Time.png");
			tbi.Image = i;
		}

		public override void DidReceiveMemoryWarning()
		{
			// Releases the view if it doesn't have a superview.
			base.DidReceiveMemoryWarning();
			// Release any cached data, images, etc that aren't in use.
		}

		public override void ViewDidLoad()
		{
			base.ViewDidLoad();
			Console.WriteLine("Time View Loaded");
			// Perform any additional setup after loading the view, typically from a nib.
			btnShowTime.TouchUpInside += (sender, e) => {
				setCurrentTime();
			};


		}

		public override void ViewWillAppear(bool animated)
		{
			base.ViewWillAppear(animated);
			Console.WriteLine("Time View will appear");
			setCurrentTime();
		}

		public override void ViewWillDisappear(bool animated)
		{
			base.ViewWillDisappear(animated);
			Console.WriteLine("Time View will disappear");
		}

		public void setCurrentTime()
		{
			NSDate now = DateTime.Now;
			NSDateFormatter dateFormat = new NSDateFormatter();
			dateFormat.TimeStyle = NSDateFormatterStyle.Medium;

			lblTime.Text = dateFormat.StringFor(now);
		}
	}
}

