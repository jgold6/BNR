using System;
using System.Drawing;
using MonoTouch.UIKit;
using MonoTouch.Foundation;

namespace HypnoTime
{
	public class HypnosisViewController : UIViewController
	{
		public HypnosisViewController() : base("HypnosisViewController", null)
		{
			UITabBarItem tbi = this.TabBarItem;
			tbi.Title = "Hypnosis";

			UIImage i = UIImage.FromFile("Hypno.png");
			tbi.Image = i;
		}

		public override void LoadView()
		{
			Console.WriteLine("Load Hypnosis View");
			// Create a view
			RectangleF frame = UIScreen.MainScreen.Bounds;
			HypnosisView v = new HypnosisView(frame);

			// Set it as the view of this view controller
			this.View = v;
		}

		public override void ViewDidLoad()
		{
			base.ViewDidLoad();

			Console.WriteLine("Hypnosis View Loaded");
		}

		public override void ViewWillAppear(bool animated)
		{
			base.ViewDidAppear(animated);
			Console.WriteLine("Hypnosis View will appear");
			View.SetNeedsDisplay();
		}

		public override void WillRotate(UIInterfaceOrientation orientation, double duration)
		{
			base.WillRotate(orientation, duration);
			Console.WriteLine("Hypnosis View will rotate");
			View.SetNeedsDisplay();
		}
	}
}

