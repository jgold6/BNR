﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Xml.Linq;
using System.Linq;
using MonoTouch.UIKit;
using System.Text.RegularExpressions;

namespace Nerdfeed
{
	public class RSSChannel
	{

		public string title {get; set;}
		public string description {get; set;}
		public string link {get; set;}
		public string lastBuildDate {get; set;}
		public string generator {get; set;}

		public List<RSSItem> items {get; set;}

		public RSSChannel()
		{
			items = new List<RSSItem>();
		}

		public async void FetchEntries(UITableView tableView)
		{
			using (var wc = new WebClient()) {
				string url = "http://forums.bignerdranch.com/smartfeed.php?limit=7_DAY&count_limit=100&sort_by=standard&feed_type=RSS2.0&feed_style=COMPACT";
				try {
					string xmlData = await wc.DownloadStringTaskAsync(new Uri(url));
					//Console.WriteLine(xmlData);

					XDocument doc = XDocument.Parse(xmlData);

					var xChannel = doc.Descendants("channel");
					title = xChannel.ElementAt(0).Element("title").Value;
					description = xChannel.ElementAt(0).Element("description").Value;
					link = xChannel.ElementAt(0).Element("link").Value;
					lastBuildDate = xChannel.ElementAt(0).Element("lastBuildDate").Value;
					generator = xChannel.ElementAt(0).Element("generator").Value;

//					Console.WriteLine("\nChannel Title: {0}\nChannel Description: {1}\nChannel Link: {2}\nChannel BuildDate: {3}\nChannel Generator: {4}", 
//						title, 
//						description,
//						link,
//						lastBuildDate,
//						generator
//					);

					var allItems = doc.Descendants("item");

					int i = 0;
					foreach (XElement current in allItems) {
						RSSItem item = new RSSItem();

						Regex regex = new Regex("(.*) :: (?:Re: )?(.*) :: .*");
						var matches = regex.Split(current.Element("title").Value);
						if (matches.Length == 4) {
							item.title = matches[2];
							item.subForum = matches[1];
						} 
						else {
							regex = new Regex("(.*) :: R?e?:? ?(.*)");
							matches = regex.Split(current.Element("title").Value);
							item.title = matches[2];
							item.subForum = matches[1];
						}
						item.link = current.Element("link").Value;
						item.description = current.Element("description").Value;
						item.author = current.Element("author").Value;
						item.category = current.Element("category").Value;
						item.comments = current.Element("comments").Value;
						item.pubDate = current.Element("pubDate").Value;

						items.Add(item);

//						Console.WriteLine("\n\tItem {0} Title: {1}\n\tDescription: {2}\n\tLink: {3}\n\tAuthor: {4}\n\tCategory: {5}\n\tComments: {6}\n\tPub Date: {7}", 
//							i,
//							items[i].title,
//							items[i].description,
//							items[i].link,
//							items[i].author,
//							items[i].category,
//							items[i].comments,
//							items[i].pubDate
//						);
						i++;
					}
					tableView.ReloadData();
					// Version 1 of parsing XML document - can't seem to get array of nodes
					//					XmlReaderSettings set = new XmlReaderSettings();
					//					set.ConformanceLevel = ConformanceLevel.Fragment;
					//
					//					XPathDocument doc = new XPathDocument(XmlReader.Create(new StringReader(xmlData), set));
					//					XPathNavigator nav = doc.CreateNavigator();
					//
					//					channel.title = nav.SelectSingleNode("/rss/channel/title");
					//					channel.infoString = nav.SelectSingleNode("/rss/channel/description");
				}
				catch (WebException ex) {
					Console.WriteLine("Exception: {0}", ex.Message);
				}
			}

			// Alternate method - try/catch does not work
			//			string url = "http://forums.bignerdranch.com/smartfeed.php?limit=1_DAY&sort_by=standard&feed_type=RSS2.0&feed_style=COMPACT";
			//			try {
			//				client = new WebClient();
			//				client.DownloadStringCompleted += (object sender, DownloadStringCompletedEventArgs e) => {
			//					xmlData = e.Result;
			//					Console.WriteLine("Downloaded data: {0}", e.Result);
			//				};
			//				client.DownloadStringAsync(new Uri(url));
			//			}
			//			catch (WebException ex) {
			//				Console.WriteLine("Error: {0}", ex.Message);
			//			}
		}
	}
}

