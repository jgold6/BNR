﻿using System;
using MonoTouch.UIKit;
using MonoTouch.Foundation;
using System.Net;
using System.IO;
using System.Xml;
using System.Xml.XPath;
using System.Xml.Linq;
using System.Linq;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace Nerdfeed
{
	public class ListViewController : UITableViewController
	{
		RSSChannel channel;
		public WebViewController webViewController {get; set;}

		public ListViewController() : this(UITableViewStyle.Plain)
		{
		}

		public ListViewController(UITableViewStyle style) : base(style)
		{
			UIBarButtonItem bbi = new UIBarButtonItem();
			bbi.Title = "Info";
			bbi.Style = UIBarButtonItemStyle.Bordered;
			this.NavigationItem.SetRightBarButtonItem(bbi,true);
			bbi.Clicked += (object sender, EventArgs e) => {
				// Create the channel view controller
				ChannelViewController channelViewController = new ChannelViewController(UITableViewStyle.Grouped);

				if (this.SplitViewController != null) {
					this.transferBarButtonItem(channelViewController);
					UINavigationController nvc = new UINavigationController(channelViewController);

					// Create an array with our nav controller and this new VC's nav controller
					UINavigationController[] vcs = new UINavigationController[]{this.NavigationController, nvc};

					// Grab a pointer to the split view controller
					// and reset its view controllers array
					this.SplitViewController.ViewControllers = vcs;

					// Make detail view controller the delegate of the split view controller
					// - ignore the warning for now
					this.SplitViewController.WeakDelegate = channelViewController;

					// If a row has been selected, deselect it so that a row
					// is not selected when viewing the info
					NSIndexPath selectedRow = this.TableView.IndexPathForSelectedRow;
					if (selectedRow != null)
						this.TableView.DeselectRow(selectedRow, true);
				} else {
					this.NavigationController.PushViewController(channelViewController, true);
				}

				// Give the VC the channel object through the interface method
				channelViewController.listViewControllerHandleObject(this, channel);

			};

			channel = new RSSChannel();
			channel.FetchEntries(this.TableView);
		}

		public override int RowsInSection(UITableView tableView, int section)
		{
			if (channel.items.Count == 0)
				return 1;
			return channel.items.Count;
		}

		public override UITableViewCell GetCell(UITableView tableView, NSIndexPath indexPath )
		{
			UITableViewCell cell = tableView.DequeueReusableCell("UITableViewCell");
			if (cell == null) {
				cell = new UITableViewCell(UITableViewCellStyle.Subtitle, "UITableViewCell");
			}
			if (channel.items.Count == 0) {
				cell.TextLabel.Text = "Loading...";
				cell.DetailTextLabel.Text = "This will only take a sec...";
				cell.UserInteractionEnabled = false;
			}
			else {
				RSSItem item = channel.items[indexPath.Row];
				cell.TextLabel.Text = item.title;
				cell.DetailTextLabel.Text = item.subForum;
				cell.UserInteractionEnabled = true;
			}

			return cell;
		}

		public override void RowSelected(UITableView tableView, NSIndexPath indexPath)
		{
			if (this.SplitViewController == null) {
				// Push the web view controller onto the navigation stack
				// this implicitly creates the web view controller's view the first time through
				this.NavigationController.PushViewController(webViewController, true);
			} else {
				this.transferBarButtonItem(webViewController);
				// We have to create a new Navigation controller, as the old one
				// was only retained by the split view controller and is now gone
				UINavigationController nav = new UINavigationController(webViewController);

				UIViewController[] vcs = new UIViewController[]{this.NavigationController, nav};

				this.SplitViewController.ViewControllers = vcs;

				// Make the detail view controller the delegate of the split view controller
				// - ignore this warning
				this.SplitViewController.WeakDelegate = webViewController;
			}

			// grab the selected item
			RSSItem entry = channel.items[indexPath.Row];

//			// Load the webview with the entry link
//			webViewController.webView.LoadRequest(new NSUrlRequest(new NSUrl(entry.link)));
//
//			// Set the title of the web view controller's navigation item
//			webViewController.NavigationItem.Title = entry.title;

			webViewController.listViewControllerHandleObject(this, entry);

		}

		public override bool ShouldAutorotate()
		{
			if (UIDevice.CurrentDevice.UserInterfaceIdiom == UIUserInterfaceIdiom.Pad)
				return true;
			return InterfaceOrientation == UIInterfaceOrientation.Portrait;
		}

		public void transferBarButtonItem(UIViewController vc)
		{
			// Get the navigation controller in the detail spot of the split view controller
			UINavigationController nvc = this.SplitViewController.ViewControllers[1] as UINavigationController;

			// Get the root view controller out of that nav controller
			UIViewController currentVC = nvc.ViewControllers[0] as UIViewController;

			// If it's the same view controller, let's not do anything
			if (vc == currentVC)
				return;

			// Get that view controller's navigation item
			UINavigationItem currentVCItem = currentVC.NavigationItem;

			// Tell the new view controller to use thleft bar button item of current nav item
			vc.NavigationItem.SetLeftBarButtonItem(currentVCItem.LeftBarButtonItem, true);

			// Remove the bar button item from the current view controller's nav item
			currentVCItem.SetLeftBarButtonItem(null, true);
		}
	}

	public interface IListViewControllerDelegate
	{
		// Classes that conform to this interface must implement this method
		void listViewControllerHandleObject(ListViewController lvc, object obj);
	}
}

