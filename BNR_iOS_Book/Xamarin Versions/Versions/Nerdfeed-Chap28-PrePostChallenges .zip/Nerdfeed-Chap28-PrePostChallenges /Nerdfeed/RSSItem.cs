﻿using System;
using System.Xml.Linq;
using System.Text.RegularExpressions;
using Newtonsoft.Json.Linq;

namespace Nerdfeed
{
	public class RSSItem
	{
		public string title {get; set;}
		public string link {get; set;}
		public string description {get; set;}
		public string author {get; set;}
		public string category {get; set;}
		public string comments {get; set;}
		public string pubDate {get; set;}
		public string subForum {get; set;}

		public void parseXML(XElement current)
		{
			Regex regex = new Regex("(.*) :: (?:Re: )?(.*) :: .*");
			var matches = regex.Split(current.Element("title").Value);
			if (matches.Length == 4) {
				this.title = matches[2];
				this.subForum = matches[1];
			} 
			else {
				regex = new Regex("(.*) :: R?e?:? ?(.*)");
				matches = regex.Split(current.Element("title").Value);
				this.title = matches[2];
				this.subForum = matches[1];
			}
			this.link = current.Element("link").Value;
			this.description = current.Element("description").Value;
			this.author = current.Element("author").Value;
			this.category = current.Element("category").Value;
			this.comments = current.Element("comments").Value;
			this.pubDate = current.Element("pubDate").Value;
		}

		public void parseJSON(JToken entry)
		{
			this.title = (string)entry["im:name"]["label"];
			this.subForum = (string)entry["im:artist"]["label"];
			this.link = (string)entry["link"][1]["attributes"]["href"];
		}

	}
}

