﻿using System;
using System.Collections.Generic;
using MonoTouch.UIKit;
using System.Net;
using System.Xml.Linq;
using System.Linq;
using System.Text.RegularExpressions;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Text;

namespace Nerdfeed
{
	public static class BNRFeedStore
	{
		public delegate void Block(string error);
		public static List<RSSItem> items = new List<RSSItem>();
		public static RSSChannel channel {get; set;}
//		public static List<WebClient> webClients = new List<WebClient>();
			
		public static async void FetchRSSFeed(Block completionBlock) // UITableViewController tvc)
		{
			using (var wc = new WebClient()) {
//				webClients.Add(wc);
				string url = "http://forums.bignerdranch.com/smartfeed.php?limit=7_DAY&sort_by=standard&feed_type=RSS2.0&feed_style=COMPACT"; //count_limit=10&
				channel = new RSSChannel();
				items.Clear();
				try {
					string xmlData = await wc.DownloadStringTaskAsync(new Uri(url));

					XDocument doc = XDocument.Parse(xmlData);

					channel.parseXML(doc);

					var allItems = doc.Descendants("item");

					foreach (XElement current in allItems) {
						RSSItem item = new RSSItem();

						item.parseXML(current);

						items.Add(item);
					}
					completionBlock("success");
				}
				catch (WebException ex) {
					Console.WriteLine("Exception: {0}", ex.Message);
					completionBlock(ex.Message);
				}
//				webClients.Remove(wc);
			}
		}

		// Get Apple JSON rss feed
		public static async void FetchRSSFeedTopSongs(int count, Block completionBlock) // UITableViewController tvc)
		{
			using (var wc = new WebClient()) {
//				webClients.Add(wc);
				string url = String.Format("http://itunes.apple.com/us/rss/topsongs/limit={0}/json", count);
				channel = new RSSChannel();
				items.Clear();
				try {
					string JSONData = await wc.DownloadStringTaskAsync(new Uri(url));
					JObject parsedJSONData = JObject.Parse (JSONData);

					channel.parseJSON(parsedJSONData);

					var entries = parsedJSONData["feed"]["entry"];

					foreach (var entry in entries) {
						RSSItem item = new RSSItem();

						item.parseJSON(entry);

						items.Add(item);
					}
					completionBlock("success");
				}
				catch (WebException ex) {
					completionBlock(ex.Message);
				}
//				webClients.Remove(wc);
			}
		}
	}
}

		// Get Apple xml rss feed
//		public static async void FetchRSSFeedTopSongs(int count, Block completionBlock, UITableViewController tvc)
//		{
//			using (var wc = new WebClient()) {
//				webClients.Add(wc);
//				string url = String.Format("http://itunes.apple.com/us/rss/topsongs/limit={0}/xml", count);
//				channel = new RSSChannel();
//				items.Clear();
//				try {
//					string xmlData = await wc.DownloadStringTaskAsync(new Uri(url));
//					//Console.WriteLine(xmlData);
//
//					XDocument doc = XDocument.Parse(xmlData);
//
//					var xFeed = doc.Descendants();
//
//					channel.title = xFeed.ElementAt(0).Element("{http://www.w3.org/2005/Atom}title").Value;
//					channel.description = xFeed.ElementAt(0).Element("{http://www.w3.org/2005/Atom}rights").Value;
//
//					foreach (XElement element in xFeed) {
//						if (element.Name == "{http://www.w3.org/2005/Atom}entry") {
//							RSSItem item = new RSSItem();
//							var titleArtist = element.Element("{http://www.w3.org/2005/Atom}title").Value.Split('-');
//							item.title = titleArtist[0].Trim();
//							item.subForum = titleArtist[1].Trim();
//
//							var links = element.Descendants();
//							foreach (XElement li in links) {
//								if (li.Name == "{http://www.w3.org/2005/Atom}link" && li.FirstAttribute.Value == "Preview") {
//									item.link = li.Attribute("href").Value;
//								}
//							}
//
//							items.Add(item);
//						}
//					}
//
//					completionBlock();
//				}
//				catch (WebException ex) {
//					Console.WriteLine("Exception: {0}", ex.Message);
//					UIAlertView av = new UIAlertView("Error", ex.Message, null, "OK", null);
//					av.WeakDelegate = tvc;
//					av.Show();
//				}
//				webClients.Remove(wc);
//			}
//		}

// Version 1 of parsing XML document - can't seem to get array of nodes
//					XmlReaderSettings set = new XmlReaderSettings();
//					set.ConformanceLevel = ConformanceLevel.Fragment;
//
//					XPathDocument doc = new XPathDocument(XmlReader.Create(new StringReader(xmlData), set));
//					XPathNavigator nav = doc.CreateNavigator();
//
//					channel.title = nav.SelectSingleNode("/rss/channel/title");
//					channel.infoString = nav.SelectSingleNode("/rss/channel/description");

// Alternate method - try/catch does not work
//			string url = "http://forums.bignerdranch.com/smartfeed.php?limit=1_DAY&sort_by=standard&feed_type=RSS2.0&feed_style=COMPACT";
//			try {
//				client = new WebClient();
//				client.DownloadStringCompleted += (object sender, DownloadStringCompletedEventArgs e) => {
//					xmlData = e.Result;
//					Console.WriteLine("Downloaded data: {0}", e.Result);
//				};
//				client.DownloadStringAsync(new Uri(url));
//			}
//			catch (WebException ex) {
//				Console.WriteLine("Error: {0}", ex.Message);
//			}
