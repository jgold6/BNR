﻿using System;
using MonoTouch.UIKit;
using MonoTouch.Foundation;
using System.Net;
using System.IO;
using System.Xml;
using System.Xml.XPath;
using System.Xml.Linq;
using System.Linq;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace Nerdfeed
{
	public enum ListViewControllerRSSType {BNRFeed, Apple};

	public class ListViewController : UITableViewController
	{

		public WebViewController webViewController {get; set;}
		ListViewControllerRSSType rssType;
		int numberOfSongsToGet;

		public ListViewController() : this(UITableViewStyle.Plain)
		{
		}

		public ListViewController(UITableViewStyle style) : base(style)
		{

			numberOfSongsToGet = 20;
			UIBarButtonItem bbi = new UIBarButtonItem();
			bbi.Title = "Info";
			bbi.Style = UIBarButtonItemStyle.Bordered;
			this.NavigationItem.SetRightBarButtonItem(bbi,true);
			bbi.Clicked += (object sender, EventArgs e) => {
				// Create the channel view controller
				ChannelViewController channelViewController = new ChannelViewController(UITableViewStyle.Grouped);

				if (this.SplitViewController != null) {
					this.transferBarButtonItem(channelViewController);
					UINavigationController nvc = new UINavigationController(channelViewController);

					// Create an array with our nav controller and this new VC's nav controller
					UINavigationController[] vcs = new UINavigationController[]{this.NavigationController, nvc};

					// Grab a pointer to the split view controller
					// and reset its view controllers array
					this.SplitViewController.ViewControllers = vcs;

					// Make detail view controller the delegate of the split view controller
					// - ignore the warning for now
					this.SplitViewController.WeakDelegate = channelViewController;

					// If a row has been selected, deselect it so that a row
					// is not selected when viewing the info
					NSIndexPath selectedRow = this.TableView.IndexPathForSelectedRow;
					if (selectedRow != null)
						this.TableView.DeselectRow(selectedRow, true);
				} else {
					this.NavigationController.PushViewController(channelViewController, true);
				}

				// Give the VC the channel object through the interface method
				channelViewController.listViewControllerHandleObject(this, BNRFeedStore.channel);

			};

			UISegmentedControl rssTypeControl = new UISegmentedControl(new string[]{"BNR", "Apple"});
			rssTypeControl.SelectedSegment = 0;
			rssType = ListViewControllerRSSType.BNRFeed;
			rssTypeControl.ValueChanged += (object sender, EventArgs e) => {
				rssType = (ListViewControllerRSSType)rssTypeControl.SelectedSegment;
				if (rssType == ListViewControllerRSSType.Apple) {
					UIAlertView aiView = new UIAlertView("Get Top Songs", "Enter how many songs to get", null, "OK", null);
					aiView.AlertViewStyle = UIAlertViewStyle.PlainTextInput;
					aiView.GetTextField(0).Text = numberOfSongsToGet.ToString();
					aiView.GetTextField(0).KeyboardType = UIKeyboardType.NumberPad;
					aiView.WeakDelegate = this;
					aiView.Show();
				}
				else {
					BNRFeedStore.items.Clear();
					this.TableView.ReloadData();
					fetchEntries();
				}
			};
			this.NavigationItem.TitleView = rssTypeControl;

			fetchEntries();
		}

		void fetchEntries()
		{
			UIView currentTitleView = this.NavigationItem.TitleView;

			// Create an activity indicator and start it spinning
			UIActivityIndicatorView aiView = new UIActivityIndicatorView(UIActivityIndicatorViewStyle.Gray);
			this.NavigationItem.TitleView = aiView;
			aiView.StartAnimating();

			BNRFeedStore.Block completionBlock = delegate(string error) {
				this.NavigationItem.TitleView = currentTitleView;
				if (error == "success")
					this.TableView.ReloadData();
				else {
					UIAlertView av = new UIAlertView("Error", error, null, "OK", null);
					av.Show();
				}
			};
			if (rssType == ListViewControllerRSSType.BNRFeed) {
				BNRFeedStore.FetchRSSFeed(completionBlock);
			}
			else if (rssType == ListViewControllerRSSType.Apple) {
				BNRFeedStore.FetchRSSFeedTopSongs(numberOfSongsToGet, completionBlock);
			}
		}

		[Export ("alertView:clickedButtonAtIndex:")]
		public void AVClickedButton(UIAlertView av, int btnIndex)
		{
			string text = av.GetTextField(0).Text;
			try {
				numberOfSongsToGet = Convert.ToInt32(text);
				if (numberOfSongsToGet < 2 || numberOfSongsToGet > 400) {
					UIAlertView aView = new UIAlertView("Invalid Entry", "Please enter integer between 2 and 400\nUsing default of 10", null, "OK", null);
					aView.Show();
					numberOfSongsToGet = 10;
				}
			}
			catch {
				UIAlertView aView = new UIAlertView("Invalid Entry", "Please enter integer between 2 and 400\nUsing default of 10", null, "OK", null);
				aView.Show();
				numberOfSongsToGet = 10;
			}
			BNRFeedStore.items.Clear();
			this.TableView.ReloadData();
			fetchEntries();
		}

		public override int RowsInSection(UITableView tableView, int section)
		{
			if (BNRFeedStore.items.Count == 0)
				return 1;
			return BNRFeedStore.items.Count;
		}

		public override UITableViewCell GetCell(UITableView tableView, NSIndexPath indexPath )
		{
			UITableViewCell cell = tableView.DequeueReusableCell("UITableViewCell");
			if (cell == null) {
				cell = new UITableViewCell(UITableViewCellStyle.Subtitle, "UITableViewCell");
			}
			if (BNRFeedStore.items.Count == 0) {
				cell.TextLabel.Text = "Loading...";
				cell.DetailTextLabel.Text = "This will only take a sec...";
				cell.UserInteractionEnabled = false;
			}
			else {
				RSSItem item = BNRFeedStore.items[indexPath.Row];
				cell.TextLabel.Text = item.title;
				cell.DetailTextLabel.Text = item.subForum;
				cell.UserInteractionEnabled = true;
			}

			return cell;
		}

		public override void RowSelected(UITableView tableView, NSIndexPath indexPath)
		{
			if (this.SplitViewController == null) {
				// Push the web view controller onto the navigation stack
				// this implicitly creates the web view controller's view the first time through
				this.NavigationController.PushViewController(webViewController, true);
			} else {
				this.transferBarButtonItem(webViewController);
				// We have to create a new Navigation controller, as the old one
				// was only retained by the split view controller and is now gone
				UINavigationController nav = new UINavigationController(webViewController);

				UIViewController[] vcs = new UIViewController[]{this.NavigationController, nav};

				this.SplitViewController.ViewControllers = vcs;

				// Make the detail view controller the delegate of the split view controller
				// - ignore this warning
				this.SplitViewController.WeakDelegate = webViewController;
			}

			// grab the selected item
			RSSItem entry = BNRFeedStore.items[indexPath.Row];

			webViewController.listViewControllerHandleObject(this, entry);
		}

		public override bool ShouldAutorotate()
		{
			if (UIDevice.CurrentDevice.UserInterfaceIdiom == UIUserInterfaceIdiom.Pad)
				return true;
			return InterfaceOrientation == UIInterfaceOrientation.Portrait;
		}

		public void transferBarButtonItem(UIViewController vc)
		{
			// Get the navigation controller in the detail spot of the split view controller
			UINavigationController nvc = this.SplitViewController.ViewControllers[1] as UINavigationController;

			// Get the root view controller out of that nav controller
			UIViewController currentVC = nvc.ViewControllers[0] as UIViewController;

			// If it's the same view controller, let's not do anything
			if (vc == currentVC)
				return;

			// Get that view controller's navigation item
			UINavigationItem currentVCItem = currentVC.NavigationItem;

			// Tell the new view controller to use thleft bar button item of current nav item
			vc.NavigationItem.SetLeftBarButtonItem(currentVCItem.LeftBarButtonItem, true);

			// Remove the bar button item from the current view controller's nav item
			currentVCItem.SetLeftBarButtonItem(null, true);
		}
	}

	public interface IListViewControllerDelegate
	{
		// Classes that conform to this interface must implement this method
		void listViewControllerHandleObject(ListViewController lvc, object obj);
	}
}

