using System;
using System.Drawing;
using MonoTouch.Foundation;
using MonoTouch.UIKit;
using MonoTouch.ObjCRuntime;

namespace Homepwner
{
	public partial class ItemsViewController : UITableViewController, IUITableViewDataSource, IUITableViewDelegate
	{
//		HeaderCell headerCell {get; set;}

		public ItemsViewController() : base(UITableViewStyle.Plain)
		{
			UINavigationItem n = this.NavigationItem;
			n.Title = "Homepwner";

			// Create a new bar button item that will send
			// addNewItem to ItemsViewController
			UIBarButtonItem bbi = new UIBarButtonItem(UIBarButtonSystemItem.Add, addNewItem);

			// Set this bar button item as the right item in the navigationItem
			this.NavigationItem.RightBarButtonItem = bbi;
			this.NavigationItem.LeftBarButtonItem = this.EditButtonItem;
		}

		public override void DidReceiveMemoryWarning()
		{
			// Releases the view if it doesn't have a superview.
			base.DidReceiveMemoryWarning();
			
			// Release any cached data, images, etc that aren't in use.
		}

		public override void ViewDidLoad()
		{
			base.ViewDidLoad();
			
			// Perform any additional setup after loading the view, typically from a nib.
			UIImage image = UIImage.FromBundle("tvBgImage.png");
			TableView.BackgroundView = new UIImageView(image);
		}

		public override void ViewWillAppear(bool animated)
		{
			base.ViewWillAppear(animated);
			this.TableView.ReloadData();
		}

		public override int RowsInSection(UITableView tableView, int section)
		{
			return BNRItemStore.allItems.Count;
		}

		public override UITableViewCell GetCell(UITableView tableView, NSIndexPath indexPath)
		{
			// Check for a reusable cell first, use that if it exists
			UITableViewCell cell = tableView.DequeueReusableCell("UITableViewCell");

			if (cell == null)
				// Create an instance of UITableViewCell, with default appearance
				cell = new UITableViewCell(UITableViewCellStyle.Subtitle,"UITableViewCell");

			// Set the text on the cell with the description of the item
			// that is the nth index of items, where n = row this cell
			// will appear in on the tableView
			BNRItem p = BNRItemStore.allItems[indexPath.Row];

			cell.TextLabel.Text = String.Format("Item: {0}, ${1}", p.itemName, p.valueInDollars);
			cell.DetailTextLabel.Text = String.Format("SN: {0}, Added: {1}", p.serialNumber, p.dateCreated);
			cell.BackgroundColor = UIColor.FromRGBA(1.0f, 1.0f, 1.0f, 0.5f);

			return cell;
		}

//		public override float GetHeightForHeader(UITableView tableView, int section)
//		{
//			if (headerCell == null)
//			{
//				headerCell = new HeaderCell();
//				var views = NSBundle.MainBundle.LoadNib("HeaderView", headerCell, null);
//				headerCell = Runtime.GetNSObject(views.ValueAt(0)) as HeaderCell;
//			}
//			return headerCell.Bounds.Size.Height;
//		}
//
//		public override UIView GetViewForHeader (UITableView tableView, int section)
//		{
//			headerCell.btnEdit.TouchUpInside += (sender, e) => {
//				Console.WriteLine("BtnEdit pressed");
//				var btn = sender as UIButton;
//				if (this.Editing == true) {
//					headerCell.btnAdd.Enabled = true;
//					btn.SetTitle("Edit", UIControlState.Normal);
//					this.SetEditing(false, true);
//				} else {
//					headerCell.btnAdd.Enabled = false;
//					btn.SetTitle("Done", UIControlState.Normal);
//					this.SetEditing(true, true);
//				}
//			};
//			headerCell.btnAdd.TouchUpInside += (sender, e) => {
//				addNewItem(sender, e);
//			};
//
//			return headerCell;
//		}

		public override void MoveRow(UITableView tableView, NSIndexPath fromIndexPath, NSIndexPath toIndexPath)
		{
			Console.WriteLine("Item replaced: {0}", BNRItemStore.allItems[toIndexPath.Row].ToString());
			Console.WriteLine("Item Moved: {0}", BNRItemStore.allItems[fromIndexPath.Row].ToString());
			BNRItemStore.moveItem(fromIndexPath.Row, toIndexPath.Row);
			Console.WriteLine("Item Moved: {0}", BNRItemStore.allItems[toIndexPath.Row].ToString());
			Console.WriteLine("Item in Orginal spot: {0}", BNRItemStore.allItems[fromIndexPath.Row].ToString());
		}

		public override void CommitEditingStyle(UITableView tableView, UITableViewCellEditingStyle editingStyle, NSIndexPath indexPath)
		{
			//base.CommitEditingStyle(tableView, editingStyle, indexPath);
			if (editingStyle == UITableViewCellEditingStyle.Delete) {
				BNRItem itemToRemove = BNRItemStore.allItems[indexPath.Row];
				BNRItemStore.RemoveItem(itemToRemove);
				NSIndexPath[] indexPaths = new NSIndexPath[] {indexPath};
				TableView.DeleteRows(indexPaths, UITableViewRowAnimation.Automatic);
				Console.WriteLine("allItems: {0}, tableViewRows: {1}", BNRItemStore.allItems.Count, tableView.NumberOfRowsInSection(0));
			}
		}

		public override void RowSelected(UITableView tableView, NSIndexPath indexPath)
		{
			// Make a detail view controller
			DetailViewController detailViewController = new DetailViewController();
			detailViewController.EdgesForExtendedLayout = UIRectEdge.None;

			// Get the selected BNRItem
			var items = BNRItemStore.allItems;
			BNRItem selectedItem = items[indexPath.Row];

			// Give the detailViewController a pointer to the item object in row
			detailViewController.Item = selectedItem;

			// Push it onto the top of the navigation controller's stack
			this.NavigationController.PushViewController(detailViewController, true);

		}

		void addNewItem(object sender, EventArgs e)
		{
			Console.WriteLine("BtnAdd pressed");

			BNRItem newItem = BNRItemStore.CreateItem();

			int lastRow = BNRItemStore.allItems.IndexOf(newItem);

			NSIndexPath ip = NSIndexPath.FromRowSection(lastRow, 0);

			NSIndexPath[] indexPaths = new NSIndexPath[] {ip};
			TableView.InsertRows(indexPaths, UITableViewRowAnimation.Automatic);

			Console.WriteLine("allItems: {0}, tableViewRows: {1}", BNRItemStore.allItems.Count, TableView.NumberOfRowsInSection(0));
		}
	}
}



























