using System;
using System.Drawing;
using MonoTouch.UIKit;
using MonoTouch.CoreGraphics;
using MonoTouch.Foundation;

namespace Homepwner
{
	public class CrosshairView : UIView
	{
		UIColor crossHairColor;

		public CrosshairView() : this(new RectangleF(UIScreen.MainScreen.Bounds.Location.X,UIScreen.MainScreen.Bounds.Location.Y, UIScreen.MainScreen.Bounds.Size.Width, UIScreen.MainScreen.Bounds.Height))
		{

		}

		public CrosshairView(RectangleF frame)
		{
			Frame = frame;
			BackgroundColor = UIColor.Clear;
		}

		public override void Draw(RectangleF rect)
		{
			base.Draw(rect);
	
			// Get current drawing context
			CGContext ctx = UIGraphics.GetCurrentContext(); 
			// Get bounds of view
			RectangleF bounds = this.Bounds;

			// Figure out the center of the bounds rectangle
			PointF center = new Point();
			center.X = (float)(bounds.Location.X + bounds.Size.Width / 2.0);
			center.Y = (float)(bounds.Location.Y + bounds.Size.Height / 2.0);

			// The thickness of the line should be 10 points wide
			ctx.SetLineWidth(2);

			// Crosshair
			crossHairColor = UIColor.Green;
			crossHairColor.SetStroke();

			ctx.MoveTo(center.X -20, center.Y);
			ctx.AddLineToPoint(center.X + 20, center.Y);
			ctx.DrawPath(CGPathDrawingMode.Stroke);
			ctx.MoveTo(center.X, center.Y-20);
			ctx.AddLineToPoint(center.X, center.Y + 20);
			ctx.DrawPath(CGPathDrawingMode.Stroke);

		}
	}
}












































