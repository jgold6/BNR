using System;
using System.Drawing;
using MonoTouch.Foundation;
using MonoTouch.UIKit;

namespace Homepwner
{
	public partial class DetailViewController : UIViewController, IUITextFieldDelegate
	{
		UIImagePickerController imagePicker;
		BNRItem item;
		public BNRItem Item {
			get {
				return item;
			} 
			set {
				item = value;
				this.NavigationItem.Title = item.itemName;
			}
		}

		public DetailViewController() : base("DetailViewController", null)
		{
		}

		public override void DidReceiveMemoryWarning()
		{
			// Releases the view if it doesn't have a superview.
			base.DidReceiveMemoryWarning();
			
			// Release any cached data, images, etc that aren't in use.
		}

		public override void ViewDidLoad()
		{
			base.ViewDidLoad();

			// Perform any additional setup after loading the view, typically from a nib.
			this.View.BackgroundColor = UIColor.GroupTableViewBackgroundColor;

			imagePicker = new UIImagePickerController();
			imagePicker.WeakDelegate = this;
			imagePicker.AllowsEditing = true;
			// If device has camera, take picture, else pick from photo library
			if (UIImagePickerController.IsSourceTypeAvailable(UIImagePickerControllerSourceType.Camera)) {
				imagePicker.SourceType = UIImagePickerControllerSourceType.Camera;
				imagePicker.ShowsCameraControls = true;
				RectangleF rect = new RectangleF(this.View.Bounds.Size.Width/2 - 10, this.View.Bounds.Size.Height/2-10, 20, 20);
				CrosshairView chView = new CrosshairView(rect);
				imagePicker.CameraOverlayView = chView;
			} else
				imagePicker.SourceType = UIImagePickerControllerSourceType.PhotoLibrary;

			takePicture.Clicked += (sender, e) => {
				// Place the image picker on the screen
				this.PresentViewController(imagePicker, true, null);
			};

			nameField.ShouldReturn += ((textField) => {
				textField.ResignFirstResponder();
				return true;
			});

			serialNumberField.ShouldReturn += ((textField) => {
				textField.ResignFirstResponder();
				return true;
			});

			valueField.ShouldReturn += ((textField) => {
				textField.ResignFirstResponder();
				return true;
			});
		}


		[Export("imagePickerController:didFinishPickingMediaWithInfo:")]
		public void FinishedPickingMedia (UIImagePickerController picker, NSDictionary info) 
		{
			string oldKey = item.imageKey;

			// Did the item already have an image?
			if (oldKey != null) {
				// Delete the old image
				BNRImageStore.deleteImageForKey(oldKey);
			}


			// Get the picked picture from the event args
			UIImage image = info.ObjectForKey(UIImagePickerController.EditedImage) as UIImage;

			// Create a GUID string - it iknows how to create unique identifier strings
			string key = Guid.NewGuid().ToString();
			item.imageKey = key;

			// Store image in the BNRIMmageStore with this key
			BNRImageStore.setImage(image, item.imageKey);

			// Put that image onto the screen in our image view
			imageView.Image = image;

			// Take the image picker off the screen - 
			// You must call this dismiss method
			ParentViewController.DismissViewController(true, null);

		}



		public override void ViewWillAppear(bool animated)
		{
			base.ViewWillAppear(animated);

			nameField.Text = item.itemName;
			serialNumberField.Text = item.serialNumber;
			valueField.Text = item.valueInDollars.ToString();
			dateLabel.Text = item.dateCreated.ToString();

			string imageKey = item.imageKey;

			if (imageKey != null) {
				// Get image for image key from image store
				UIImage imageToDisplay = BNRImageStore.imageForKey(imageKey);

				// Use that image to put on the screen in imageView
				imageView.Image = imageToDisplay;
			} else {
				// Clear the imageView
				imageView.Image = null;
			}
		}

		partial void backgroundTapped (MonoTouch.Foundation.NSObject sender)
		{
			this.View.EndEditing(true);
		}

		partial void deletePicture (MonoTouch.Foundation.NSObject sender)
		{
			if (item.imageKey != null) {
				string key = item.imageKey;
				BNRImageStore.deleteImageForKey(key);
				imageView.Image = null;
				item.imageKey = null;
			}
		}

		public override void ViewWillDisappear(bool animated)
		{
			base.ViewWillDisappear(animated);

			// Clear first responder
			this.View.EndEditing(true);

			// "Save" changes to item
			item.itemName = nameField.Text;
			item.serialNumber = serialNumberField.Text;
			item.valueInDollars = Convert.ToInt32(valueField.Text);
		}
	}
}

