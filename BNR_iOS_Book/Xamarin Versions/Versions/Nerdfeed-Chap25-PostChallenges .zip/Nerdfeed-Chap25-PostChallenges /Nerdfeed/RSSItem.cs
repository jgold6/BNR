﻿using System;

namespace Nerdfeed
{
	public class RSSItem
	{
		public string title {get; set;}
		public string link {get; set;}
		public string description {get; set;}
		public string author {get; set;}
		public string category {get; set;}
		public string comments {get; set;}
		public string pubDate {get; set;}

		public RSSItem()
		{
		}
	}
}

