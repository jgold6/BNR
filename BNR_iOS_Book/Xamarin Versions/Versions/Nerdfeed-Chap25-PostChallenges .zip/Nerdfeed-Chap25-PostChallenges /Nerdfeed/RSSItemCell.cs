﻿using System;
using MonoTouch.UIKit;
using System.Drawing;
using MonoTouch.Foundation;

namespace Nerdfeed
{
	public class RSSItemCell : UITableViewCell
	{
		public UILabel titleLabel {get; set;}
		public UILabel authorLabel {get; set;}
		public UILabel categoryLabel {get; set;}

		public RSSItemCell() : base(UITableViewCellStyle.Default, "RSSItemCell")
		{
		}

		public RSSItemCell(UITableViewCellStyle style, string reuseIdentifier) : base(style, reuseIdentifier)
		{
			RectangleF msBounds = UIScreen.MainScreen.Bounds;
			titleLabel = new UILabel(new RectangleF(10.0f, 0.0f, msBounds.Size.Width/3-20, 50));
			authorLabel = new UILabel(new RectangleF(msBounds.Size.Width/3, 0.0f, msBounds.Size.Width/3-20, 50));
			categoryLabel = new UILabel(new RectangleF(2*msBounds.Size.Width/3, 0.0f, msBounds.Size.Width/3-20, 50));

			categoryLabel.AutoresizingMask = UIViewAutoresizing.FlexibleWidth;

			this.AddSubview(titleLabel);
			this.AddSubview(authorLabel);
			this.AddSubview(categoryLabel);
		}
	}
}

