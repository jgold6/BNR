﻿using System;
using MonoTouch.UIKit;
using System.Drawing;
using MonoTouch.ObjCRuntime;
using MonoTouch.Foundation;

namespace Nerdfeed
{
	public class WebViewController : UIViewController
	{
		public UIWebView webView {get {return this.View as UIWebView;}}
		UIBarButtonItem bbiBack;
		UIBarButtonItem bbiForward;

		public WebViewController()
		{
		}

		public override void LoadView()
		{
			// Create an instance of UIWebview as large as the screen
			RectangleF screenFrame = UIScreen.MainScreen.ApplicationFrame;
			UIWebView wv = new UIWebView(screenFrame);
			wv.LoadFinished += (object sender, EventArgs e) => {
				if (webView.CanGoBack)
					bbiBack.Enabled = true;
				else
					bbiBack.Enabled = false;
				if (webView.CanGoForward)
					bbiForward.Enabled = true;
				else
					bbiForward.Enabled = false;
			};
			wv.ScalesPageToFit = true;

			bbiBack = new UIBarButtonItem();
			bbiForward = new UIBarButtonItem();
			bbiBack.Title = "Back";
			bbiForward.Title = "Forward";
			bbiBack.Style = UIBarButtonItemStyle.Bordered;
			bbiForward.Style = UIBarButtonItemStyle.Bordered;
			bbiBack.Width = screenFrame.Size.Width/2;
			bbiForward.Width = screenFrame.Size.Width/2;

			bbiBack.Clicked += (object sender, EventArgs e) => {
				webView.GoBack();
			};

			bbiForward.Clicked += (object sender, EventArgs e) => {
				webView.GoForward();
			};

			UIBarButtonItem[] bbiItems = new UIBarButtonItem[]{bbiBack, bbiForward};
			this.ToolbarItems = bbiItems;

			this.View = wv;
		}

		public override void ViewWillAppear(bool animated)
		{
			this.NavigationController.ToolbarHidden = false;
		}

		public override void ViewWillDisappear(bool animated)
		{
			this.NavigationController.ToolbarHidden = true;
		}
	}
}

