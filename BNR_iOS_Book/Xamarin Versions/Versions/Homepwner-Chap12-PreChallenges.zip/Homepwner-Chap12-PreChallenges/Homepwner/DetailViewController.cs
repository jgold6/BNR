using System;
using System.Drawing;
using MonoTouch.Foundation;
using MonoTouch.UIKit;

namespace Homepwner
{
	public partial class DetailViewController : UIViewController, IUITextFieldDelegate
	{
		UIImagePickerController imagePicker;
		BNRItem item;
		public BNRItem Item {
			get {
				return item;
			} 
			set {
				item = value;
				this.NavigationItem.Title = item.itemName;
			}
		}

		public DetailViewController() : base("DetailViewController", null)
		{
		}

		public override void DidReceiveMemoryWarning()
		{
			// Releases the view if it doesn't have a superview.
			base.DidReceiveMemoryWarning();
			
			// Release any cached data, images, etc that aren't in use.
		}

		public override void ViewDidLoad()
		{
			base.ViewDidLoad();

			// Perform any additional setup after loading the view, typically from a nib.
			this.View.BackgroundColor = UIColor.GroupTableViewBackgroundColor;

			imagePicker = new UIImagePickerController();

			// If device has camera, take picture, else pick from photo library
			if (UIImagePickerController.IsSourceTypeAvailable(UIImagePickerControllerSourceType.Camera))
				imagePicker.SourceType = UIImagePickerControllerSourceType.Camera;
			else
				imagePicker.SourceType = UIImagePickerControllerSourceType.PhotoLibrary;

			takePicture.Clicked += (sender, e) => {

				// Place the image picker on the screen
				this.PresentViewController(imagePicker, true, null);
			};

			imagePicker.FinishedPickingMedia += (object sender, UIImagePickerMediaPickedEventArgs e) => {
				string oldKey = item.imageKey;

				// Did the item already have an image?
				if (oldKey != null) {
					// Delete the old image
					BNRImageStore.deleteImageForKey(oldKey);
				}


				// Get the picked picture from the event args
				UIImage image = e.OriginalImage;

				// Create a GUID string - it iknows how to create unique identifier strings
				string key = Guid.NewGuid().ToString();
				item.imageKey = key;

				// Store image in the BNRIMmageStore with this key
				BNRImageStore.setImage(image, item.imageKey);

				// Put that image onto the screen in our image view
				imageView.Image = image;

				// Take the image picker off the screen - 
				// You must call this dismiss method
				this.DismissViewController(true, null);

			};

			nameField.ShouldReturn += ((textField) => {
				textField.ResignFirstResponder();
				return true;
			});

			serialNumberField.ShouldReturn += ((textField) => {
				textField.ResignFirstResponder();
				return true;
			});

			valueField.ShouldReturn += ((textField) => {
				textField.ResignFirstResponder();
				return true;
			});
		}

		public override void ViewWillAppear(bool animated)
		{
			base.ViewWillAppear(animated);

			nameField.Text = item.itemName;
			serialNumberField.Text = item.serialNumber;
			valueField.Text = item.valueInDollars.ToString();
			dateLabel.Text = item.dateCreated.ToString();

			string imageKey = item.imageKey;

			if (imageKey != null) {
				// Get image for image key from image store
				UIImage imageToDisplay = BNRImageStore.imageForKey(imageKey);

				// Use that image to put on the screen in imageView
				imageView.Image = imageToDisplay;
			} else {
				// Clear the imageView
				imageView.Image = null;
			}
		}

		partial void backgroundTapped (MonoTouch.Foundation.NSObject sender)
		{
			this.View.EndEditing(true);
		}

		public override void ViewWillDisappear(bool animated)
		{
			base.ViewWillDisappear(animated);

			// Clear first responder
			this.View.EndEditing(true);

			// "Save" changes to item
			item.itemName = nameField.Text;
			item.serialNumber = serialNumberField.Text;
			item.valueInDollars = Convert.ToInt32(valueField.Text);
		}
	}
}

