using System;
using MonoTouch.UIKit;
using MonoTouch.Foundation;
using MonoTouch.ObjCRuntime;
using System.Collections.Generic;

namespace Homepwner
{
	public class AssetTypePicker : UITableViewController, IUITableViewDelegate, IUITableViewDataSource
	{
		public BNRItem item {get; set;}
		public UIPopoverController popoverController {get; set;}
		public DetailViewController controller {get; set;}

		public AssetTypePicker() : base(UITableViewStyle.Plain)
		{
			UINavigationItem n = this.NavigationItem;
			n.Title = "Asset Types";

			// Create a new bar button item that will send
			// addNewItem to AssetTypePicker
//			UIBarButtonItem bbi = new UIBarButtonItem(UIBarButtonSystemItem.Add, addNewItem); // Use for silver challenge
// // Use for silver challenge
//			// Set this bar button item as the right item in the navigationItem // Use for silver challenge
//			n.RightBarButtonItem = bbi; // Use for silver challenge
		}

//		void addNewItem(object sender, EventArgs e) // Use for silver challenge
//		{ // Use for silver challenge
//			UIAlertView alert = new UIAlertView("Create an Asset Type", "Please enter a new asset type", null, "Done", null); // Use for silver challenge
//			alert.AlertViewStyle = UIAlertViewStyle.PlainTextInput; // Use for silver challenge
//			UITextField alerttextField = alert.GetTextField(0); // Use for silver challenge
//			alerttextField.KeyboardType = UIKeyboardType.Default; // Use for silver challenge
//			alerttextField.Placeholder = "Enter a new asset type"; // Use for silver challenge
//			alert.Show(); // Use for silver challenge
//			alert.Clicked += (object avSender, UIButtonEventArgs ave) => { // Use for silver challenge
//				Console.WriteLine("Entered: {0}", alert.GetTextField(0).Text); // Use for silver challenge
//				BNRItemStore.addAssetType(alert.GetTextField(0).Text); // Use for silver challenge
//				TableView.ReloadData(); // Use for silver challenge
//				NSIndexPath ip = NSIndexPath.FromRowSection(BNRItemStore.allAssetTypes.Count-1, 0); // Use for silver challenge
//				this.RowSelected(TableView, ip); // Use for silver challenge
// // Use for silver challenge
//			}; // Use for silver challenge
//		} // Use for silver challenge

		public override int NumberOfSections(UITableView tableView)
		{
			return 1; // Return 2 for gold challenge
		}

		public override int RowsInSection(UITableView tableView, int section)
		{
			int rows;
//			if (section == 0) // Use for gold challenge
				rows = BNRItemStore.allAssetTypes.Count;
//			else { // Use for gold challenge
//				var assetTypeItems = getAssetTypeItems(); // Use for gold challenge
//				rows = assetTypeItems.Count; // Use for gold challenge
//			} // Use for gold challenge
			return rows;
		}

		public override string TitleForHeader(UITableView tableView, int section)
		{
//			if (section == 0) // Use for gold challenge
				return "Asset Types";
//			else // Use for gold challenge
//				return "Items with this asset Type"; // Use for gold challenge
		}

		public override UITableViewCell GetCell(UITableView tableView, NSIndexPath indexPath)
		{
			UITableViewCell cell = TableView.DequeueReusableCell("UITableViewCell");
			if (cell == null) {
				cell = new UITableViewCell(UITableViewCellStyle.Default, "UITableViewCell");
			}

//			if (indexPath.Section == 0) { // Use for gold challenge
				var at = BNRItemStore.allAssetTypes[indexPath.Row];
				cell.TextLabel.Text = at.assetType;

				if (at.assetType == item.assetType)
					cell.Accessory = UITableViewCellAccessory.Checkmark;
				else
					cell.Accessory = UITableViewCellAccessory.None;
//			} // Use for gold challenge
//			if (indexPath.Section == 1) { // Use for gold challenge
//				var assetTypeItems = getAssetTypeItems(); // Use for gold challenge
//				var at = assetTypeItems[indexPath.Row]; // Use for gold challenge
//				cell.TextLabel.Text = at.itemName; // Use for gold challenge
//			}
			return cell;
		}

		public override void RowSelected(UITableView tableView, NSIndexPath indexPath)
		{
//			if (indexPath.Section == 0) { // Use for gold challenge
				foreach (UITableViewCell c in tableView.VisibleCells)
					c.Accessory = UITableViewCellAccessory.None;

				UITableViewCell cell = TableView.CellAt(indexPath);

				cell.Accessory = UITableViewCellAccessory.Checkmark;

				var at = BNRItemStore.allAssetTypes[indexPath.Row];
				item.assetType = at.assetType;
				BNRItemStore.updateDBItem(item);
//				if (UIDevice.CurrentDevice.UserInterfaceIdiom == UIUserInterfaceIdiom.Pad) { // Bronze
//					controller.updateAssetType(); // Bronze
//					popoverController.Dismiss(true); // Bronze
//					popoverController = null; // Bronze
//				} else { // Bronze
				this.NavigationController.PopViewControllerAnimated(true);
//				} // Bronze
//			} // Use for gold challenge
		}

//		public List<BNRItem> getAssetTypeItems() // Use for gold challenge
//		{ // Use for gold challenge
//			List<BNRItem> assetTypeItems = new List<BNRItem>(); // Use for gold challenge
//			var items = BNRItemStore.allItems; // Use for gold challenge
// // Use for gold challenge
//			foreach (BNRItem i in items) { // Use for gold challenge
//				if (i.assetType == item.assetType) { // Use for gold challenge
//					assetTypeItems.Add(i); // Use for gold challenge
//				} // Use for gold challenge
//			} // Use for gold challenge
//			return assetTypeItems; // Use for gold challenge
//		} // Use for gold challenge
	}
}

