using System;
using System.Collections.Generic;

namespace Homepwner
{
	class MainClass
	{
		public static void Main(string[] args)
		{
//			List<BNRItem> items = new List<BNRItem>();
//			items.Add("One");
//			items.Add("Two");
//			items.Add("Three");
//			items.Insert(0, "Zero");
//
//			for (int i = 0; i < items.Count; i++)
//				Console.WriteLine("Item {0}: {1}", i, items[i]);

//			BNRItem p = new BNRItem();
//
//			Console.WriteLine(p.ToString());
//
//			p.itemName = "Red Sofa";
//			p.serialNumber = "A1B2C";
//			p.valueInDollars = 100;

//			BNRItem p = new BNRItem("Red Sofa", 100, "A1B2C");

//			for (int i = 0; i < 10; i++)
//			{
//				BNRItem p = BNRItem.RandomBNRItem();
//				items.Add(p);
//			}
//
//			foreach (BNRItem item in items)
//			{
//				Console.WriteLine(item.ToString());
//			}

//			items = null;

			BNRContainer container = new BNRContainer();

			for (int i = 0; i < 10; i++)
			{
				BNRItem p = BNRItem.RandomBNRItem();
				container.addBNRItem(p);
			}

			BNRContainer container2 = new BNRContainer();

			for (int i = 0; i < 5; i++)
			{
				BNRItem p = BNRItem.RandomBNRItem();
				container2.addBNRItem(p);
			}

			container.addBNRItem(container2 as BNRItem);

			container2.removeBNRItemAtIndex(0);
			container.removeBNRItemAtIndex(0);

			container.addBNRItem(BNRItem.RandomBNRItem());

			Console.WriteLine(container.ToString());

		}
	}
}
