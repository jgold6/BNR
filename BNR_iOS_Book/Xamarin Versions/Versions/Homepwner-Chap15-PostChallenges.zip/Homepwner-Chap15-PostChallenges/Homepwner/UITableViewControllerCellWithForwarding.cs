using System;
using MonoTouch.UIKit;
using MonoTouch.Foundation;
using System.Reflection;

namespace Homepwner
{
	public class UITableViewControllerCellWithForwarding : UITableViewCell
	{
		public UITableViewControllerCellWithForwarding()
		{
		}

		public UITableViewControllerCellWithForwarding(IntPtr handle) : base(handle)
		{
		}

		public void forwardMessage(UIViewController vc, string sel, NSObject obj1, NSObject obj2)
		{
			var type = vc.GetType();
			MethodInfo method = type.GetMethod(sel);
			NSObject[] array = new NSObject[]{obj1, obj2};
			if (method != null) {
				method.Invoke(vc, array);
			}
		}
	}
}

