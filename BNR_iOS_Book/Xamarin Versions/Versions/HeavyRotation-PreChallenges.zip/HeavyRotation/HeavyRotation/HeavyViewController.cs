using System;
using System.Drawing;
using MonoTouch.Foundation;
using MonoTouch.UIKit;

namespace HeavyRotation
{
	public partial class HeavyViewController : UIViewController
	{
		RectangleF imageSize;
		UIDevice device;

		public HeavyViewController() : base("HeavyViewController", null)
		{
		}

		public override void DidReceiveMemoryWarning()
		{
			// Releases the view if it doesn't have a superview.
			base.DidReceiveMemoryWarning();
			
			// Release any cached data, images, etc that aren't in use.
		}

		public override void ViewDidLoad()
		{
			base.ViewDidLoad();

			device = UIDevice.CurrentDevice;

			// Perform any additional setup after loading the view, typically from a nib.
		
			btn1.TouchUpInside += (sender, e) => {
				Console.WriteLine("Button btn1 clicked");
			};

			btn2.TouchUpInside += (sender, e) => {
				Console.WriteLine("Button btn2 clicked");
			};

			imageSize = image.Bounds;
			slider.Value = 1;	
			slider.ValueChanged += (sender, e) => {
				Console.WriteLine("slider value: {0}", slider.Value);
				if (device.Orientation == UIDeviceOrientation.LandscapeLeft || device.Orientation == UIDeviceOrientation.LandscapeRight)
					image.Bounds = new RectangleF(imageSize.X, imageSize.Y, imageSize.Width * 0.66f * slider.Value, imageSize.Height * 0.66f * slider.Value);
				else
					image.Bounds = new RectangleF(imageSize.X, imageSize.Y, imageSize.Width * slider.Value, imageSize.Height * slider.Value);
			};
		}

		public override void WillRotate(UIInterfaceOrientation orientation, double duration)
		{
			base.WillRotate(orientation, duration);
			if (orientation == UIInterfaceOrientation.LandscapeLeft || orientation == UIInterfaceOrientation.LandscapeRight) {
				image.Bounds = new RectangleF(imageSize.X, imageSize.Y, imageSize.Width * 0.66f * slider.Value, imageSize.Height * 0.66f * slider.Value);
			}
			else {
				image.Bounds = new RectangleF(imageSize.X, imageSize.Y, imageSize.Width * slider.Value, imageSize.Height * slider.Value);
			}
		}

		public override void DidRotate(UIInterfaceOrientation orientation)
		{
			base.DidRotate(orientation);
			if (orientation == UIInterfaceOrientation.LandscapeLeft || orientation == UIInterfaceOrientation.LandscapeRight) {
				image.Bounds = new RectangleF(imageSize.X, imageSize.Y, imageSize.Width * slider.Value, imageSize.Height * slider.Value);
			}
			else {
				image.Bounds = new RectangleF(imageSize.X, imageSize.Y, imageSize.Width * 0.66f * slider.Value, imageSize.Height * 0.66f * slider.Value);
			}

		}

		public override bool ShouldAutorotate()
		{
			return true;
		}

		public override UIInterfaceOrientationMask GetSupportedInterfaceOrientations()
		{
			return UIInterfaceOrientationMask.All;
		}

	}
}

